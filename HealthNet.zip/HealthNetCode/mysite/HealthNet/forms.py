from django import forms
from django.core import validators
from django.forms import EmailField, TimeInput
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms import ModelForm

from .models import Patient, Appointment, MedicalInfo, InsuranceInfo, Hospital, Doctor, BLOOD_TYPES, \
    HealthAdmin, SystemAdmin, Prescription, Nurse, INSURANCE_COMPANY_CHOICES, Test, Message, AdminRegistration, \
    HospitalStay, Image, Transfer, CSVFile


class MyRegistrationForm(UserCreationForm):
    """
    User Registration Form
    """
    email = forms.EmailField(required=True, label='Email Address')
    first_name = forms.CharField(required=True, label='First Name')
    last_name = forms.CharField(required=True, label='Last Name')

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'first_name', 'last_name')
        exclude = ('username',)

    def save(self, commit=True):
        user = super(MyRegistrationForm, self).save(commit=False)
        if commit:
            user.save()

        return user


class MyPatientForm(ModelForm):
    """
    Patient Registration Form
    """
    hospital = forms.ModelChoiceField(queryset=Hospital.objects.all())
    primaryDoc = forms.ModelChoiceField(queryset=Doctor.objects.all(), label='Primary Care Physician')
    birthDate = forms.DateField(required=True, label='Date of Birth')
    EmergContactEmail = forms.EmailField(required=True, label='Emergency Contact Email')

    class Meta:
        model = Patient
        fields = ('hospital', 'primaryDoc', 'sex', 'birthDate', 'address', 'city', 'state', 'zipcode', 'phoneNumber',
                  'EmergContactName', 'EmergContactEmail', 'EmergContactPhoneNumber')
        exclude = None

    def save(self, commit=True):
        user = super(ModelForm, self).save(commit=False)
        if commit:
            user.save()

        return user


class LogForm(forms.Form):
    """
    System Log Form
    """
    start_date = forms.DateField(widget=forms.SelectDateWidget, required=True, label="Start Date")
    start_time = forms.TimeField(input_formats=('%I:%M %p', ), required=True, label="Start Time")
    end_date = forms.DateField(widget=forms.SelectDateWidget, required=True, label="End Date")
    end_time = forms.TimeField(input_formats=('%I:%M %p',), required=True, label="End Time")


class MyMedicalRecordForm(ModelForm):
    """
    Medical Record Registration Form
    """
    bloodType = forms.ChoiceField(BLOOD_TYPES, required=False, label='Blood Type')
    height = forms.FloatField(required=False, label='Height in feet(ft)')
    weight = forms.FloatField(required=False, label='Weight in pounds(lbs)')
    lungDisease = forms.NullBooleanField(label='Lung Disease', widget=forms.NullBooleanSelect, required=False)
    highBloodPressure = forms.NullBooleanField(label='High Blood Pressure', widget=forms.NullBooleanSelect,
                                               required=False)
    heartTrouble = forms.NullBooleanField(label='Heart Trouble', widget=forms.NullBooleanSelect, required=False)
    nervousDisorder = forms.NullBooleanField(label='Nervous Disorder', widget=forms.NullBooleanSelect, required=False)
    digestiveDisease = forms.NullBooleanField(label='Digestive Disease', widget=forms.NullBooleanSelect, required=False)
    cancer = forms.NullBooleanField(label='Cancer', widget=forms.NullBooleanSelect, required=False)
    kidneyDisease = forms.NullBooleanField(label='Kidney Disease', widget=forms.NullBooleanSelect, required=False)
    diabetes = forms.NullBooleanField(label='Diabetes', widget=forms.NullBooleanSelect, required=False)
    arthritis = forms.NullBooleanField(label='Arthritis', widget=forms.NullBooleanSelect, required=False)
    hepatitis = forms.NullBooleanField(label='Hepatitis', widget=forms.NullBooleanSelect, required=False)
    malaria = forms.NullBooleanField(label='Malaria', widget=forms.NullBooleanSelect, required=False)
    bloodDisorder = forms.NullBooleanField(label='Disease or Disorder of the Blood?', widget=forms.NullBooleanSelect,
                                           required=False)
    bloodDisorderDescription = forms.CharField(widget=forms.Textarea, required=False,
                                               label='Description of Blood Disorder')
    physicalDefect = forms.NullBooleanField(label='Any Physical Defect or Deformity?', widget=forms.NullBooleanSelect,
                                            required=False)
    physicalDefectDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                label='Description of Defect/Deformity')
    visionDisorder = forms.NullBooleanField(label='Any Vision Disorder?', widget=forms.NullBooleanSelect,
                                            required=False)
    visionDisorderDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                label='Description of Vision Disorder')
    hearingDisorder = forms.NullBooleanField(label='Any Hearing Disorder?', widget=forms.NullBooleanSelect,
                                             required=False)
    hearingDisorderDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                 label='Description of Hearing Disorder')
    lifeThreateningConditions = forms.NullBooleanField(label='Any Life-Threatening Conditions?',
                                                       widget=forms.NullBooleanSelect, required=False)
    lifeThreateningConditionsDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                           label='Description of Life-Threatening Condition/s')
    contagiousDisorder = forms.NullBooleanField(label='Any Contagious Disorders?', widget=forms.NullBooleanSelect,
                                                required=False)
    contagiousDisorderDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                    label='Description of Contagious Disorder/s')
    hospitalizations = forms.CharField(widget=forms.Textarea, required=False,
                                       label='Have you been treated by a physician or been disabled or hospitalized during the last year? (describe)')
    operations = forms.CharField(widget=forms.Textarea, required=False,
                                 label='Have you had or been advised to have a surgical operation within the last five years? (describe)')
    dateLastPhysical = forms.DateField(required=False, label='Date of last physical')
    dateLastTetanusShot = forms.DateField(required=False, label='Date of last Tetanus shot')
    familyMedicalProblems = forms.CharField(required=False, widget=forms.Textarea,
                                            label='Family history — list important medical problems of your parents')
    additionalInfo = forms.CharField(required=False, widget=forms.Textarea, label='Any Additional Information')

    class Meta:
        model = MedicalInfo
        fields = (
            'bloodType', 'height', 'weight', 'lungDisease', 'highBloodPressure', 'heartTrouble',
            'nervousDisorder', 'digestiveDisease', 'cancer', 'kidneyDisease', 'diabetes', 'arthritis',
            'hepatitis', 'malaria', 'bloodDisorder', 'bloodDisorderDescription', 'physicalDefect',
            'physicalDefectDescription', 'visionDisorder', 'visionDisorderDescription', 'hearingDisorder',
            'hearingDisorderDescription', 'lifeThreateningConditions', 'lifeThreateningConditionsDescription',
            'contagiousDisorder', 'contagiousDisorderDescription', 'hospitalizations', 'operations',
            'dateLastPhysical', 'dateLastTetanusShot', 'familyMedicalProblems', 'additionalInfo')

        exclude = ('confirmed', 'admissionReason',)

    def save(self, commit=True):
        record = super(ModelForm, self).save(commit=False)
        if commit:
            record.save()

        return record


class MyRequiredMedicalRecordForm(ModelForm):
    """
    Medical Record Modification Form
    """
    bloodType = forms.ChoiceField(BLOOD_TYPES, required=True, label='Blood Type')
    height = forms.FloatField(required=True, label='Height in feet(ft)')
    weight = forms.FloatField(required=True, label='Weight in pounds(lbs)')
    lungDisease = forms.NullBooleanField(label='Lung Disease', widget=forms.NullBooleanSelect, required=True)
    highBloodPressure = forms.NullBooleanField(label='High Blood Pressure', widget=forms.NullBooleanSelect,
                                               required=True)
    heartTrouble = forms.NullBooleanField(label='Heart Trouble', widget=forms.NullBooleanSelect, required=True)
    nervousDisorder = forms.NullBooleanField(label='Nervous Disorder', widget=forms.NullBooleanSelect, required=True)
    digestiveDisease = forms.NullBooleanField(label='Digestive Disease', widget=forms.NullBooleanSelect, required=True)
    cancer = forms.NullBooleanField(label='Cancer', widget=forms.NullBooleanSelect, required=True)
    kidneyDisease = forms.NullBooleanField(label='Kidney Disease', widget=forms.NullBooleanSelect, required=True)
    diabetes = forms.NullBooleanField(label='Diabetes', widget=forms.NullBooleanSelect, required=True)
    arthritis = forms.NullBooleanField(label='Arthritis', widget=forms.NullBooleanSelect, required=True)
    hepatitis = forms.NullBooleanField(label='Hepatitis', widget=forms.NullBooleanSelect, required=True)
    malaria = forms.NullBooleanField(label='Malaria', widget=forms.NullBooleanSelect, required=True)
    bloodDisorder = forms.NullBooleanField(label='Disease or Disorder of the Blood?', widget=forms.NullBooleanSelect,
                                           required=True)
    bloodDisorderDescription = forms.CharField(widget=forms.Textarea, required=False,
                                               label='Description of Blood Disorder')
    physicalDefect = forms.NullBooleanField(label='Any Physical Defect or Deformity?', widget=forms.NullBooleanSelect,
                                            required=True)
    physicalDefectDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                label='Description of Defect/Deformity')
    visionDisorder = forms.NullBooleanField(label='Any Vision Disorder?', widget=forms.NullBooleanSelect,
                                            required=True)
    visionDisorderDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                label='Description of Vision Disorder')
    hearingDisorder = forms.NullBooleanField(label='Any Hearing Disorder?', widget=forms.NullBooleanSelect,
                                             required=True)
    hearingDisorderDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                 label='Description of Hearing Disorder')
    lifeThreateningConditions = forms.NullBooleanField(label='Any Life-Threatening Conditions?',
                                                       widget=forms.NullBooleanSelect, required=True)
    lifeThreateningConditionsDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                           label='Description of Life-Threatening Condition/s')
    contagiousDisorder = forms.NullBooleanField(label='Any Contagious Disorders?', widget=forms.NullBooleanSelect,
                                                required=True)
    contagiousDisorderDescription = forms.CharField(widget=forms.Textarea, required=False,
                                                    label='Description of Contagious Disorder/s')
    hospitalizations = forms.CharField(widget=forms.Textarea, required=False,
                                       label='Have you been treated by a physician or been disabled or hospitalized during the last year? (describe)')
    operations = forms.CharField(widget=forms.Textarea, required=False,
                                 label='Have you had or been advised to have a surgical operation within the last five years? (describe)')
    dateLastPhysical = forms.DateField(required=True, label='Date of last physical')
    dateLastTetanusShot = forms.DateField(required=True, label='Date of last Tetanus shot')
    familyMedicalProblems = forms.CharField(required=False, widget=forms.Textarea,
                                            label='Family history — list important medical problems of your parents')
    additionalInfo = forms.CharField(required=False, widget=forms.Textarea, label='Any Additional Information')

    class Meta:
        model = MedicalInfo
        fields = (
            'bloodType', 'height', 'weight', 'lungDisease', 'highBloodPressure', 'heartTrouble',
            'nervousDisorder', 'digestiveDisease', 'cancer', 'kidneyDisease', 'diabetes', 'arthritis',
            'hepatitis', 'malaria', 'bloodDisorder', 'bloodDisorderDescription', 'physicalDefect',
            'physicalDefectDescription', 'visionDisorder', 'visionDisorderDescription', 'hearingDisorder',
            'hearingDisorderDescription', 'lifeThreateningConditions', 'lifeThreateningConditionsDescription',
            'contagiousDisorder', 'contagiousDisorderDescription', 'hospitalizations', 'operations',
            'dateLastPhysical', 'dateLastTetanusShot', 'familyMedicalProblems', 'additionalInfo')

        exclude = ('confirmed', 'admissionReason',)

    def save(self, commit=True):
        record = super(ModelForm, self).save(commit=False)
        if commit:
            record.save()

        return record


class MyInsuranceForm(ModelForm):
    """
    Insurance Info Registration Form
    """
    memberID = forms.CharField(required=True, label="Member Identification Number")

    class Meta:
        model = InsuranceInfo
        fields = ('company', 'memberID',)
        exclude = None

    def save(self, commit=True):
        insurance = super(ModelForm, self).save(commit=False)
        if commit:
            insurance.save()

        return insurance


class MyAdminRegistrationForm(ModelForm):
    """
    Registration Form for Admins to pick the type of user to register
    """
    class Meta:
        model = AdminRegistration
        fields = ('registration_type',)
        exclude = None

    def save(self, commit=True):
        registration_type = super(ModelForm, self).save(commit=False)
        if commit:
            registration_type.save()

        return registration_type


class MyNurseForm(ModelForm):
    """
    Nurse Registration Form
    """
    hospital = forms.ModelChoiceField(queryset=Hospital.objects.all())

    class Meta:
        model = Nurse
        fields = ('hospital',)
        exclude = None

    def save(self, commit=True):
        nurse = super(ModelForm, self).save(commit=False)
        if commit:
            nurse.save()

        return nurse


class MyDoctorForm(ModelForm):
    """
    Doctor Registration Form
    """
    hospitals = forms.ModelMultipleChoiceField(queryset=Hospital.objects.all(), widget=forms.CheckboxSelectMultiple())

    class Meta:
        model = Doctor
        fields = ('hospitals',)
        exclude = None

    def save(self, commit=True):
        doctor = super(ModelForm, self).save(commit=False)
        if commit:
            doctor.save()

        return doctor


class MyHealthAdminForm(ModelForm):
    """
    HealthAdmin Registration Form
    """
    hospital = forms.ModelChoiceField(queryset=Hospital.objects.all())

    class Meta:
        model = HealthAdmin
        fields = ('hospital',)
        exclude = None

    def save(self, commit=True):
        admin = super(ModelForm, self).save(commit=False)
        if commit:
            admin.save()

        return admin


class DateForm(forms.Form):
    """
    Form to accept a datefield
    """
    date = forms.DateField()


class MyAppointmentForm(ModelForm):
    """
    Appointment Creation and Modification Form for Nurses
    """
    title = forms.CharField(label='Title', required=True)
    description = forms.CharField(label='Description(Optional)', widget=forms.Textarea, required=False)
    doctor = forms.ModelChoiceField(queryset=Doctor.objects.all(), required=True)
    patient = forms.ModelChoiceField(queryset=Patient.objects.all(), required=True)
    hospital = forms.ModelChoiceField(queryset=Hospital.objects.all(), required=True)
    start_date = forms.DateField(widget=forms.SelectDateWidget, required=True)
    start_time = forms.TimeField(widget=forms.TimeInput, required=True)
    end_date = forms.DateField(widget=forms.SelectDateWidget, required=True)
    end_time = forms.TimeField(widget=forms.TimeInput, required=True)

    class Meta:
        model = Appointment
        fields = ('title', 'description', 'doctor', 'patient', 'hospital', 'start_date', 'start_time',
                  'end_date', 'end_time')
        exclude = None

    def save(self, commit=True):
        appointment = super(ModelForm, self).save(commit=False)
        if commit:
            appointment.save()

        return appointment


class AdmissionForm(ModelForm):
    """
    Patient Admission to Hospital Form
    """
    # patient = forms.ModelChoiceField(queryset=Patient.objects.all(), required=True)
    # endTime = forms.TimeField(widget=forms.TimeInput, required=False)
    # endDate = forms.DateField(widget=forms.SelectDateWidget, required=False)
    reason = forms.CharField(max_length=200, required=True, widget=forms.Textarea)

    class Meta:
        model = HospitalStay
        fields = ('reason',)
        exclude = ('patient', 'active', 'startTime', 'startDate', 'endTime', 'endDate', 'hospital',)

    def save(self, commit=True):
        admission = super(ModelForm, self).save(commit=False)
        if commit:
            admission.save()
        return admission


class MyPatientTransferForm(ModelForm):
    """
    Patient Transfer Form
    """
    hospital = forms.ModelChoiceField(queryset=Hospital.objects.all(), required=True, empty_label=None)

    class Meta:
        model = Transfer
        fields = ('hospital',)

    def save(self, commit=True):
        transfer = super(ModelForm, self).save(commit=False)
        if commit:
            transfer.save()
        return transfer


class MyDoctorAppointmentForm(ModelForm):
    """
    Appointment Creation and Modification Form for Doctors
    """
    title = forms.CharField(label='Title', required=True)
    description = forms.CharField(label='Description(Optional)', widget=forms.Textarea, required=False)
    patient = forms.ModelChoiceField(queryset=Patient.objects.all(), required=True)
    hospital = forms.ModelChoiceField(queryset=Hospital.objects.all(), required=True)
    start_date = forms.DateField(widget=forms.SelectDateWidget, required=True)
    start_time = forms.TimeField(widget=forms.TimeInput, required=True)
    end_date = forms.DateField(widget=forms.SelectDateWidget, required=True)
    end_time = forms.TimeField(widget=forms.TimeInput, required=True)

    class Meta:
        model = Appointment
        fields = ('title', 'description', 'patient', 'hospital', 'start_date', 'start_time',
                  'end_date', 'end_time')
        exclude = ('doctor',)

    def save(self, commit=True):
        appointment = super(ModelForm, self).save(commit=False)
        if commit:
            appointment.save()

        return appointment


class MyPatientAppointmentForm(ModelForm):
    """
    Appointment Creation and Modification Form for Patients
    """
    title = forms.CharField(label='Title', required=True)
    description = forms.CharField(label='Description(Optional)', widget=forms.Textarea, required=False)
    start_date = forms.DateField(widget=forms.SelectDateWidget, required=True)
    start_time = forms.TimeField(widget=forms.TimeInput, required=True)
    #end_date = forms.DateField(widget=forms.SelectDateWidget, required=True)
    #end_time = forms.TimeField(widget=forms.TimeInput, required=True)

    class Meta:
        model = Appointment
        fields = ('title', 'description', 'doctor', 'hospital', 'start_date', 'start_time')
        exclude = ('patient', 'hospital', 'doctor', 'end_time', 'end_date')

    def save(self, commit=True):
        appointment = super(ModelForm, self).save(commit=False)
        if commit:
            appointment.save()

        return appointment


class MyPrescriptionForm(ModelForm):
    """
    Prescription Creation and Modification Form for Doctors
    """
    medicine = forms.CharField(label='Medicine', required=True)
    dosage = forms.CharField(label='Dosage', required=True)
    instructions = forms.CharField(label='Instructions(Optional)', widget=forms.Textarea, required=False)

    class Meta:
        model = Prescription
        fields = ('medicine', 'dosage', 'instructions',)
        exclude = ('medicalInfo', 'datePrescribed')

    def save(self, commit=True):
        prescription = super(ModelForm, self).save(commit=False)
        if commit:
            prescription.save()

        return prescription


class MyTestForm(ModelForm):
    """
    Test Creation and Modification Form for Doctors
    """
    testName = forms.CharField(label='Test Name', required=True)
    hasResults = forms.BooleanField(label="Make This Test Viewable By the Patient?", required=False)
    results = forms.CharField(label='Results', widget=forms.Textarea, required=False)

    class Meta:
        model = Test
        fields = ('testName', 'hasResults', 'results',)
        exclude = ('medicalInfo',)

    def save(self, commit=True):
        test = super(ModelForm, self).save(commit=False)
        if commit:
            test.save()

        return test


class MyImageForm(forms.ModelForm):
    """
    Image Upload Form for Doctors
    """
    title = forms.CharField(label='Title', required=True)
    description = forms.CharField(label='Description', widget=forms.Textarea, required=True)
    release = forms.BooleanField(label="Do you want to release this image now?", required=False)
    image = forms.FileField(label="Image ('.png', .jpeg', '.jpg', '.gif', '.tif', '.tiff')", required=True)

    class Meta:
        model = Image
        fields = ('title', 'description', 'release', 'image')
        exclude = ('medicalInfo', 'date')

    def save(self, commit=True):
        image = super(ModelForm, self).save(commit=False)
        if commit:
            image.save()

        return image


class MyCSVForm(forms.ModelForm):
    """
    CSV Loading Form for Admins
    """
    file = forms.FileField(label="CSV File ('.csv')", required=True)

    class Meta:
        model = CSVFile
        fields = ('file',)
        exclude = None

    def save(self, commit=True):
        file = super(ModelForm, self).save(commit=False)
        if commit:
            file.save()
        return file


class MyMessageForm(ModelForm):
    """
    Message Creation Form
    """
    subject = forms.CharField(label='Subject', required=True)
    content = forms.CharField(widget=forms.Textarea, label='Content', required=True)
    recipient = forms.EmailField(label='Send To (Email):', required=True)

    class Meta:
        model = Message
        fields = ('recipient', 'subject', 'content',)
        exclude = None

    def save(self, commit=True):
        message = super(ModelForm, self).save(commit=False)
        if commit:
            message.save()

        return message


class MyMessageReplyForm(ModelForm):
    """
    Message Reply Form
    """
    subject = forms.CharField(label='Subject', required=True)
    content = forms.CharField(widget=forms.Textarea, label='Content', required=True)

    class Meta:
        model = Message
        fields = ('subject', 'content',)
        exclude = None

    def save(self, commit=True):
        message = super(ModelForm, self).save(commit=False)
        if commit:
            message.save()

        return message


class MyHospitalForm(ModelForm):
    """
    Hospital Registration Form
    """
    name = forms.CharField(max_length=300, required=True)
    address = forms.CharField(max_length=400, required=True)
    city = forms.CharField(max_length=300, required=True)
    zipcode = forms.CharField(max_length=10, required=True)
    state = forms.CharField(max_length=100, required=True)

    class Meta:
        model = Hospital
        fields = ('name', 'address', 'city', 'state',)
        exclude = None

    def save(self, commit=True):
        hospital = super(ModelForm, self).save(commit=False)
        if commit:
            hospital.save()
        return hospital
