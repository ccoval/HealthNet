from datetime import date, datetime
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError, ObjectDoesNotExist
from django.core.validators import RegexValidator, MinLengthValidator
from django.db import models
from time import time


class Transfer(models.Model):
    """
    Model to aid in Patient Transferring
    """
    hospital = models.ForeignKey('Hospital', on_delete=models.CASCADE)


Sex_Types = (('Male', 'Male'), ('Female', 'Female'))


class Patient(models.Model):
    """
    Patient UserType Model
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='patient')
    sex = models.CharField(max_length=7, choices=Sex_Types, verbose_name='Sex', null=True)
    primaryDoc = models.ForeignKey('Doctor', on_delete=models.CASCADE, related_name='patients',
                                   verbose_name='Primary Care Physician', null=True, blank=True)
    fullName = models.CharField(max_length=700, verbose_name='Full Name', null=True, blank=True)
    address = models.CharField(max_length=700, verbose_name='Address', null=True, blank=True)
    city = models.CharField(max_length=100, verbose_name='City', null=True, blank=True)
    state = models.CharField(max_length=100, verbose_name='State', null=True, blank=True)
    zipcode = models.CharField(max_length=100, verbose_name='Zipcode', null=True, blank=True)
    phoneNumber = models.CharField(max_length=15, verbose_name='Phone Number',
                                   validators=[RegexValidator(r'^[0-9]'), MinLengthValidator(7)],null=True, blank=True)
    birthDate = models.DateField('Date of Birth in the format of YYYY-MM-DD', null=True, blank=True)
    hospital = models.ForeignKey('Hospital', on_delete=models.CASCADE, related_name='patients',
                                 verbose_name='Preferred Hospital', null=True, blank=True)
    admitted = models.BooleanField(default=False)
    healthNetEmergContact = models.OneToOneField(User, related_name='healthNetEmergContact',
                                                 verbose_name='Emergency Contact', null=True, blank=True)
    EmergContactName = models.CharField(max_length=700, verbose_name='Emergency Contact Name', null=True, blank=True)
    EmergContactEmail = models.EmailField(max_length=700, verbose_name='Emergency Contact Email', null=True, blank=True)
    EmergContactPhoneNumber = models.CharField(max_length=15, verbose_name='Emergency Contact Phone Number',
                                   validators=[RegexValidator(r'^[0-9]'), MinLengthValidator(7)],null=True, blank=True)

    def __str__(self):
        return self.user.first_name + " " + self.user.last_name

    def get_absolute_url(self):
        return self.user.email

    def contact_in_system(self):
        if (Patient.objects.filter(User.first_name == self.contactFname) != None):
            if (Patient.objects.filter(User.last_name == self.contactLname) != None):
                return True
            else:
                return False
        else:
            return False


class Doctor(models.Model):
    """
    Doctor UserType Model
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='doctor')
    hospitals = models.ManyToManyField('Hospital', related_name='doctors')
    validated = models.BooleanField('Validated', default=False)

    def __str__(self):
        return self.user.first_name + " " + self.user.last_name

    def get_absolute_url(self):
        return self.user.email


class Nurse(models.Model):
    """
    Nurse UserType Model
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='nurse')
    hospital = models.ForeignKey('Hospital', on_delete=models.CASCADE, related_name='nurses')
    validated = models.BooleanField('Validated', default=False)

    def __str__(self):
        return self.user.first_name + " " + self.user.last_name

    def get_absolute_url(self):
        return self.user.email


class HealthAdmin(models.Model):
    """
    HealthAdmin UserType Model
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='healthAdmin')
    hospital = models.ForeignKey('Hospital', on_delete=models.CASCADE, related_name='healthAdmins')
    validated = models.BooleanField('Validated', default=False)

    def __str__(self):
        return self.user.first_name + " " + self.user.last_name

    def get_absolute_url(self):
        return self.user.email


Admin_Registration_Types = (('Nurse', 'Nurse'),
                            ('Doctor', 'Doctor'),
                            ('Administrator', 'Administrator'))


class AdminRegistration(models.Model):
    """
    Model to aid in registering a new staff member as an Admin
    """
    registration_type = models.CharField(max_length=200, choices=Admin_Registration_Types, default=None,
                                         verbose_name='Type of New Staff Member')


class SystemAdmin(models.Model):
    """
    SystemAdmin UserType Model
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='sysAdmin')

    def __str__(self):
        return self.user.first_name + " " + self.user.last_name

    def get_absolute_url(self):
        return self.user.email


class Hospital(models.Model):
    """
    Hospital Model
    """
    name = models.CharField(max_length=300)
    address = models.CharField(max_length=400, null=True, blank=True)
    city = models.CharField(max_length=300, null=True, blank=True)
    zipcode = models.CharField(max_length=10, null=True, blank=True)
    state = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.name

    def is_in_system(self):
        try:
            Hospital.objects.get(name=self.name)
            return True
        except ObjectDoesNotExist:
            return False

    class Meta:
        ordering = ['name']


BLOOD_TYPES = (
    ('Unknown', 'Unknown'),
    ('O-', 'O-'),
    ('O+', 'O+'),
    ('A-', 'A-'),
    ('A+', 'A+'),
    ('B-', 'B-'),
    ('B+', 'B+'),
    ('AB-', 'AB-'),
    ('AB+', 'AB+'),
)


class MedicalInfo(models.Model):
    """
    Medical Record Model
    """
    patient = models.OneToOneField('Patient', related_name='medicalRecord')
    confirmed = models.BooleanField('Medical Record is Confirmed', default=False)
    admissionReason = models.CharField(max_length=700, verbose_name='Reason for Admission', null=True, blank=True)
    bloodType = models.CharField(max_length=7, choices=BLOOD_TYPES, verbose_name='Blood Type', null=True, blank=True)
    height = models.FloatField('Height in feet(ft)', null=True, blank=True)
    weight = models.FloatField('Weight in pounds(lbs)', null=True, blank=True)
    lungDisease = models.NullBooleanField('Diagnosed Lung Disease', null=True, default=None)
    highBloodPressure = models.NullBooleanField('Diagnosed High Blood Pressure', null=True, default=None)
    heartTrouble = models.NullBooleanField('Diagnosed Heart Trouble', null=True, default=None)
    nervousDisorder = models.NullBooleanField('Diagnosed Nervous Disorder', null=True, default=None)
    digestiveDisease = models.NullBooleanField('Diagnosed Disease or Disorder of the Digestive Tract', null=True,
                                               default=None)
    cancer = models.NullBooleanField('Any Form of Cancer', null=True, default=None)
    kidneyDisease = models.NullBooleanField('Diagnosed Disease of the Kidney', null=True, default=None)
    diabetes = models.NullBooleanField('Diabetes', null=True, default=None)
    arthritis = models.NullBooleanField('Arthritis', null=True, default=None)
    hepatitis = models.NullBooleanField('Hepatitis', null=True, default=None)
    malaria = models.NullBooleanField('Malaria', null=True, default=None)
    bloodDisorder = models.NullBooleanField('Disease or Disorder of the Blood?', null=True, default=None)
    bloodDisorderDescription = models.CharField(max_length=2000, verbose_name='Description of Blood Disorder',
                                                null=True, blank=True)
    physicalDefect = models.NullBooleanField('Any Physical Defect or Deformity?', null=True, default=None)
    physicalDefectDescription = models.CharField(max_length=2000, verbose_name='Description of Defect/Deformity',
                                                 null=True, blank=True)
    visionDisorder = models.NullBooleanField('Any Vision Disorder?', null=True, default=None)
    visionDisorderDescription = models.CharField(max_length=2000, verbose_name='Description of Vision Disorder',
                                                 null=True, blank=True)
    hearingDisorder = models.NullBooleanField('Any Hearing Disorder?', null=True, default=None)
    hearingDisorderDescription = models.CharField(max_length=2000,
                                                  verbose_name='Description of Hearing Disorder',
                                                  null=True, blank=True)
    lifeThreateningConditions = models.NullBooleanField('Any Life-Threatening Conditions?', null=True, default=None)
    lifeThreateningConditionsDescription = models.CharField(max_length=2000,
                                                            verbose_name='Description of Life-Threatening Condition/s',
                                                            null=True, blank=True)
    contagiousDisorder = models.NullBooleanField('Any Contagious Disorders?', null=True, default=None)
    contagiousDisorderDescription = models.CharField(max_length=2000,
                                                     verbose_name='Description of Contagious Disorder/s',
                                                     null=True, blank=True)
    hospitalizations = \
        models.CharField(max_length=2000,
                         verbose_name='Have you been treated by a physician or been disabled or hospitalized during the last year? (describe)',
                         null=True, blank=True)
    operations = models.CharField(max_length=2000,
                                  verbose_name='Have you had or been advised to have a surgical operation within the last five years? (describe)',
                                  null=True, blank=True)
    dateLastPhysical = models.DateField('Date of last physical', null=True, blank=True)
    dateLastTetanusShot = models.DateField('Date of last Tetanus shot', null=True, blank=True)
    familyMedicalProblems = models.CharField(max_length=2000,
                                             verbose_name='Family history — list important medical problems of your parents',
                                             null=True, blank=True)
    additionalInfo = models.CharField(max_length=2000,
                                      verbose_name='Any Additional Information',
                                      null=True, blank=True)

    def __str__(self):
        return self.patient.user.first_name + " " + self.patient.user.last_name + ": Medical Record"


INSURANCE_COMPANY_CHOICES = (
    ('Aetna (PPO-POS)', 'Aetna (PPO-POS)'),
    ('BCBS-NM (HMO Blue or Blue Net)', 'BCBS-NM (HMO Blue or Blue Net)'),
    ('BCBS-NM PPO', 'BCBS-NM PPO'),
    ('Beech Street Network', 'Beech Street Network'),
    ('Cigna Behavioral Health', 'Cigna Behavioral Health'),
    ('Cigna', 'Cigna'),
    ('Coventry (including the Mailhandlers Benefit Product)', 'Coventry (including the Mailhandlers Benefit Product)'),
    ('Evolutions Healthcare Systems Network', 'Evolutions Healthcare Systems Network'),
    ('First Health Network', 'First Health Network'),
    ('Health Management Network (HMN)', 'Health Management Network (HMN)'),
    ('Indian Health Pueblo of Isleta', 'Indian Health Pueblo of Isleta'),
    ('Indian Health Services', 'Indian Health Services'),
    ('Multiplan Network', 'Multiplan Network'),
    ('OptumHealth Transplant Solutions – URN (Kidney Transplants)',
     'OptumHealth Transplant Solutions – URN (Kidney Transplants)'),
    ('PHCS Network (Private Healthcare Systems)', 'PHCS Network (Private Healthcare Systems)'),
    ('Presbyterian Health Plan (Medical National Network)', 'Presbyterian Health Plan (Medical National Network)'),
    ('Presbyterian Health Plan (Behavioral Health National Network)',
     'Presbyterian Health Plan (Behavioral Health National Network)'),
    ('Pueblo of Sandia', 'Pueblo of Sandia'),
    ('Select Provider Network (SPN)', 'Select Provider Network (SPN)'),
    ('United Behavioral Health / OptumHealth', 'United Behavioral Health / OptumHealth'),
    ('United Healthcare', 'United Healthcare'),
    ('Aetna Medicare PPO', 'Aetna Medicare PPO'),
    ('Amerigroup Medicare (Amerivantage)', 'Amerigroup Medicare (Amerivantage)'),
    ('Care Improvement Plus', 'Care Improvement Plus'),
    ('Molina Medicare HMO (Moline Medicare Options)', 'Molina Medicare HMO (Moline Medicare Options)'),
    ('Presbyterian Medicare PPO (Presbyterian MediCare PPO)', 'Presbyterian Medicare PPO (Presbyterian MediCare PPO)'),
    ('Presbyterian Medicare PPO (Behavioral Health National Network)',
     'Presbyterian Medicare PPO (Behavioral Health National Network)'),
    ('Presbyterian Medicare PPO (Medical National Network)', 'Presbyterian Medicare PPO (Medical National Network)'),
    ('Presbyterian Medicare HMO (Presbyterian Senior Care Plan)',
     'Presbyterian Medicare HMO (Presbyterian Senior Care Plan)'),
    ('Presbyterian Medicare HMO (Behavioral Health National Network)',
     'Presbyterian Medicare HMO (Behavioral Health National Network)'),
    ('Presbyterian Medicare HMO (Medical National Network)', 'Presbyterian Medicare HMO (Medical National Network)'),
    ('UnitedHealthCare Medicare Advantage Medicare Solutions Dual Complete',
     'UnitedHealthCare Medicare Advantage Medicare Solutions Dual Complete'),
    ('UnitedHealthCare Medicare Advantage Community Plan', 'UnitedHealthCare Medicare Advantage Community Plan'),
    ('Blue Cross Centennial Care', 'Blue Cross Centennial Care'),
    ('UHC Community Plan', 'UHC Community Plan'),
    ('Molina Centennial Care', 'Molina Centennial Care'),
    ('Optum Health of NM – Behavioral (Centennial Care)', 'Optum Health of NM – Behavioral (Centennial Care)'),
    ('Presbyterian Centennial Care', 'Presbyterian Centennial Care'),
    ('Presbyterian Centennial Care (Behavioral Health National Network)',
     'Presbyterian Centennial Care (Behavioral Health National Network)'),
    ('Presbyterian Centennial Care (Medical Health National Network)',
     'Presbyterian Centennial Care (Medical Health National Network)'),
)


class InsuranceInfo(models.Model):
    """
    Insurance Information Model
    """
    patient = models.OneToOneField('Patient', related_name='insurance')
    memberID = models.CharField(max_length=30, default="")
    company = models.CharField(max_length=400, choices=INSURANCE_COMPANY_CHOICES, default=None)

    def __str__(self):
        return self.patient.user.first_name + " " + self.patient.user.last_name + ": Insurance"


class Prescription(models.Model):
    """
    Prescription Model
    """
    medicalInfo = models.ForeignKey('MedicalInfo', on_delete=models.CASCADE, related_name='prescriptions')
    medicine = models.CharField(max_length=200)
    dosage = models.CharField(max_length=50)
    instructions = models.CharField(max_length=500)
    datePrescribed = models.DateField('date prescribed')

    # isFilled = models.BooleanField(default=False, verbose_name="Has the prescription been filled.")
    # dateFilled = models.DateField('date filled', default=None)

    def __str__(self):
        return self.medicalInfo.patient.user.first_name + " " + self.medicalInfo.patient.user.last_name + ": " + self.medicine


class Appointment(models.Model):
    """
    Appointment Model
    """
    title = models.CharField(max_length=200, default="")
    description = models.CharField(max_length=3000, null=True, blank=True)
    doctor = models.ForeignKey('Doctor', on_delete=models.CASCADE, related_name='appointments')
    patient = models.ForeignKey('Patient', on_delete=models.CASCADE, related_name='appointments')
    hospital = models.ForeignKey('Hospital', on_delete=models.CASCADE, related_name='appointments')
    start_date = models.DateField('start_date')
    end_date = models.DateField('end_date')
    start_time = models.TimeField('start_time')
    end_time = models.TimeField('end_time')

    def __str__(self):
        return "Appointment for " + self.patient.user.first_name + " " + self.patient.user.last_name + \
               " with Dr. " + self.doctor.user.first_name + " " + self.doctor.user.last_name + \
               " at " + self.hospital.name

    def get_absolute_url(self):
        return self.id

    def is_correct(self):
        # apt date ends before start
        if self.end_date < self.start_date:
            return False

        # apt ends before starting on same day
        elif self.end_date == self.start_date and self.end_time < self.start_time:
            return False

        # apt starts and ends at same time
        elif self.start_date == self.end_date and self.start_time == self.end_time:
            return False

        else:
            return True


    def is_available(self):
        similarApt = Appointment.objects.all().exclude(id = self.id)

        # apt is unavailable
        for apt in similarApt:
            if self.start_date == apt.start_date and self.doctor == apt.doctor or self.start_date == apt.start_date and self.patient == apt.patient or self.end_date == apt.end_date and self.doctor == apt.doctor or self.end_date == apt.end_date and self.patient == apt.patient:
                if self.start_time > apt.start_time:
                    if self.start_time < apt.end_time:
                        return False

                elif self.start_time < apt.start_time:
                    if self.end_time > apt.start_time:
                        return False

                elif self.start_time == apt.start_time or self.end_time == apt.end_time or self.start_time == apt.end_time or self.end_time == apt.start_time:
                    return False

                else:
                    return True

        return True

    class Meta:
        ordering = ['doctor', 'start_date', 'start_time']


def validate_image_file_extension(value):
    """
    Returns whether or not the image file is an accepted file type
    :param value: image file
    """
    import os
    ext = os.path.splitext(value.name)[1]
    valid_extensions = ['.png', '.jpeg', '.jpg', '.gif', '.tif', '.tiff', '.JPG']
    if ext not in valid_extensions:
        raise ValidationError(u'Unaccepted File Type, Must be an accepted image file format. \n'
                              u'Accepted Formats: \n'
                              u'.png \n'
                              u'.jpeg \n'
                              u'.jpg \n'
                              u'.gif \n'
                              u'.tif \n'
                              u'.tiff \n')


def get_upload_file_name(instance, filename):
    """
    Returns a filename for uploaded images
    :param instance: Instance of File
    :param filename: Name of File
    :return: Filename
    """
    file_name = str(filename).replace('-', '_')
    now = datetime.now()
    return "%s_%s_%s_%s_%s_%s" % (str(now.year), str(now.month), str(now.day),
                                  str(now.hour), str(now.minute), file_name)


class Image(models.Model):
    """
    Image Model
    """
    medicalInfo = models.ForeignKey('MedicalInfo', on_delete=models.CASCADE, related_name='images')
    title = models.CharField(max_length=200, verbose_name='Title', null=True, blank=True)
    description = models.CharField(max_length=5000, verbose_name='Description', null=True, blank=True)
    release = models.BooleanField(default=False, verbose_name='Do you want to release this image now?', blank=True)
    date = models.DateTimeField(verbose_name="Date Uploaded", null=True, blank=True)
    image = models.FileField(upload_to=get_upload_file_name, null=True, blank=True,
                             validators=[validate_image_file_extension])

    def filename(self):
        import os
        return os.path.basename(self.image.name)

    def __str__(self):
        return self.title + " " + str(self.date)


def validate_csv_file_extension(value):
    """
    Checks if the file is a csv file
    :param value: file
    """
    import os
    ext = os.path.splitext(value.name)[1]
    valid_extensions = ['.csv']
    if ext not in valid_extensions:
        raise ValidationError(u'Unaccepted File Type, Must be an accepted file format. \n'
                              u'Accepted Formats: \n'
                              u'.csv \n')


class CSVFile(models.Model):
    """
    Model to act as a CSV file loader to server
    """
    file = models.FileField(null=True, blank=True,
                            validators=[validate_csv_file_extension])

    def filename(self):
        import os
        return os.path.basename(self.file.name)

    def __str__(self):
        return "Received CSV file."


class Test(models.Model):
    """
    Test Model
    """
    medicalInfo = models.ForeignKey('MedicalInfo', on_delete=models.CASCADE, related_name='tests')
    testName = models.CharField(max_length=200, verbose_name='Test Name', null=True, blank=True)
    hasResults = models.BooleanField(default=False, verbose_name='Does Test Have Results', blank=True)
    results = models.CharField(max_length=2000, verbose_name='Test Results', blank=True, null=True)

    def __str__(self):
        return self.medicalInfo.patient.user.first_name + " " + self.medicalInfo.patient.user.last_name + ": " + \
               self.testName


class Message(models.Model):
    """
    Message Model
    """
    subject = models.CharField(max_length=50, null=True, blank=True)
    content = models.TextField(max_length=5000, null=True, blank=True)
    viewed = models.BooleanField(default=False)
    recipient = models.EmailField(null=True, blank=True)
    author = models.EmailField(null=True, blank=True)
    sent_time = models.TimeField('sent_time', null=True, blank=True)
    sent_date = models.DateField('sent_date', null=True, blank=True)

    # def __str__(self):
    # return self.author + ": " + self.subject

    class Meta:
        ordering = ['sent_date', 'sent_time']


class HospitalStay(models.Model):
    """
    Model to show how long a patient has been admitted to the hospital
    """
    # will log activity as str of this
    # blank has completed his stay of $$$$$
    patient = models.ForeignKey('Patient', on_delete=models.CASCADE, null=True, blank=True)
    active = models.BooleanField()
    reason = models.CharField(max_length=200, null=True, blank=True)
    startTime = models.TimeField('start_time', null=True, blank=True)
    startDate = models.DateField('start_date', null=True, blank=True)
    hospital = models.ForeignKey('Hospital', on_delete=models.CASCADE, null=True,
                                 blank=True)
    endTime = models.TimeField('end_time', null=True, blank=True)
    endDate = models.DateField('end_date', null=True, blank=True)

    def __str__(self):
        """
        if self.active:
            return str(self.patient) + " stayed from " + str(self.startTime) + " on " + str(
                self.startDate) + " to " + str(
                self.endTime) + " on " + str(self.endDate) + " at " + str(self.hospital) + " for " + str(self.reason)
        else:
        """
        return str(self.startTime) + " on " + str(self.startDate)


"""
    def avg_value(self):
        return
"""


class Notification(models.Model):
    """
    Notification Model
    """
    content = models.TextField(max_length=500, null=True, blank=True)
    viewed = models.BooleanField(default=False)
    recipient = models.EmailField(null=True, blank=True)
    author = models.EmailField(null=True, blank=True)
    sent_time = models.TimeField('sent_time', null=True, blank=True)
    sent_date = models.DateField('sent_date', null=True, blank=True)

    def __str__(self):
        return "Notification for " + str(self.recipient) + " from " + str(self.author) + " about " + str(self.content)

    class Meta:
        ordering = ['sent_date', 'sent_time']
