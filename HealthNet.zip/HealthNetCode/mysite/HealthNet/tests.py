from django.test import TestCase
from .models import *

class AppointmentTest(TestCase):
    def setUp(self):
        #Doctor
        self.user1 = User.objects.create_user("doctor1", "doctor1@email.com", "doctorpassword")
        self.hName1 = Hospital.objects.create(name="Mercy Hospital", address="123 Good Street", city="Good City", zipcode="12345", state="NY")
        self.hList = Hospital.objects.all()
        self.doc = Doctor.objects.create(user=self.user1, validated=True)
        self.doc.hospitals = self.hList

        #Patient
        self.user2 = User.objects.create_user("patient1", "patient1@email.com", "patientpassword")
        self.Patient = Patient.objects.create(user=self.user2, sex='Male', primaryDoc=self.doc, hospital=self.hName1, admitted=False)

        #Appointment
        self.Appointment = Appointment.objects.create(title="Appointment Title", description="Appointment Description", doctor=self.doc, patient=self.Patient, hospital=self.hName1, start_date="2016-07-07", end_date="2016-07-07", start_time="10:00", end_time="12:30")

    def test_appointment(self):
        self.assertEqual(self.Appointment.title, "Appointment Title")



class TestTest(TestCase):
    def setUp(self):
        #Doctor
        self.user1 = User.objects.create_user("doctor1", "doctor1@email.com", "doctorpassword")
        self.hName1 = Hospital.objects.create(name="Mercy Hospital", address="123 Good Street", city="Good City", zipcode="12345", state="NY")
        self.hList = Hospital.objects.all()
        self.doc = Doctor.objects.create(user=self.user1, validated=True)
        self.doc.hospitals = self.hList

        #Patient
        self.user2 = User.objects.create_user("patient1", "patient1@email.com", "patientpassword")
        self.Patient = Patient.objects.create(user=self.user2, sex='Male', primaryDoc=self.doc, hospital=self.hName1, admitted=False)

        #MedicalInfo
        self.MedicalInfo = MedicalInfo.objects.create(patient=self.Patient)

        #Test
        self.Test = Test.objects.create(medicalInfo=self.MedicalInfo, testName="Test Name", hasResults=True, results="Test Results")

    def test_hosptial_name(self):
        self.assertEqual(self.Test.testName, "Test Name")


class HospitalTest(TestCase):
    def setUp(self):
        self.Hospital = Hospital.objects.create(name="Mercy Hospital", address="123 Good Street")

    def test_hosptial_name(self):
        self.assertEqual(self.Hospital.name, "Mercy Hospital")

class MessageTest(TestCase):
    def setUp(self):
        self.Message = Message.objects.create(subject="Message Subject", content="Message Content")

    def test_message_name(self):
        self.assertEqual(self.Message.subject, "Message Subject")


class NurseTest(TestCase):
    def setUp(self):
        self.User = User.objects.create_user("User1", "User1@email.com", "userpassword")
        self.Hospital = Hospital.objects.create(name="Mercy Hospital", address="123 Good Street")
        self.Nurse = Nurse.objects.create(user=self.User, hospital=self.Hospital, validated=True)

    def test_nurse_name(self):
        self.assertEqual(self.Nurse.hospital.name, "Mercy Hospital")


class DoctorTest(TestCase):
    def setUp(self):

        #Hospital
        self.hName1 = Hospital.objects.create(name="Mercy Hospital", address="123 Good Street", city="Good City", zipcode="12345", state="NY")
        self.hName2 = Hospital.objects.create(name="Strong Hospital", address="123 Better Street", city="Good City", zipcode="12345", state="NY")
        self.hList = Hospital.objects.all()

        #Doctor
        self.usr = User.objects.create_user("User1", "User1@email.com", "userpassword")
        self.doc = Doctor.objects.create(user=self.usr, validated=True)
        self.doc.hospitals = self.hList

    def test_doctor_name(self):
        self.assertEqual(self.doc.user.username, "User1")


class PatientTest(TestCase):
    def setUp(self):
        #Doctor
        self.user1 = User.objects.create_user("doctor1", "doctor1@email.com", "doctorpassword")
        self.hName1 = Hospital.objects.create(name="Mercy Hospital", address="123 Good Street", city="Good City", zipcode="12345", state="NY")
        self.hList = Hospital.objects.all()
        self.doc = Doctor.objects.create(user=self.user1, validated=True)
        self.doc.hospitals = self.hList

        #Patient
        self.user2 = User.objects.create_user("patient1", "patient1@email.com", "patientpassword")
        self.Patient = Patient.objects.create(user=self.user2, sex='Male', primaryDoc=self.doc, hospital=self.hName1, admitted=False)

    def test_patient_name(self):
        self.assertEqual(self.Patient.hospital.name, "Mercy Hospital")


class HealthAdminTest(TestCase):
    def setUp(self):
        #Doctor
        self.user1 = User.objects.create_user("admin1", "admin1@email.com", "adminpassword")
        self.hName1 = Hospital.objects.create(name="Mercy Hospital", address="123 Good Street", city="Good City", zipcode="12345", state="NY")
        self.HealthAdmin = HealthAdmin.objects.create(user=self.user1, hospital=self.hName1, validated=True)

    def test_patient_name(self):
        self.assertEqual(self.HealthAdmin.user.username, "admin1")


class PrescriptionTest(TestCase):
    def setUp(self):
        #Doctor
        self.user1 = User.objects.create_user("doctor1", "doctor1@email.com", "doctorpassword")
        self.hName1 = Hospital.objects.create(name="Mercy Hospital", address="123 Good Street", city="Good City", zipcode="12345", state="NY")
        self.hList = Hospital.objects.all()
        self.doc = Doctor.objects.create(user=self.user1, validated=True)
        self.doc.hospitals = self.hList

        #Patient
        self.user2 = User.objects.create_user("patient1", "patient1@email.com", "patientpassword")
        self.Patient = Patient.objects.create(user=self.user2, sex='Male', primaryDoc=self.doc, hospital=self.hName1, admitted=False)

        #MedicalInfo
        self.MedicalInfo = MedicalInfo.objects.create(patient=self.Patient)

        #Prescription
        self.Prescription = Prescription.objects.create(medicalInfo= self.MedicalInfo, medicine="Vicodin", dosage="100g", instructions="Take it", datePrescribed="2015-11-11")

    def test_message_name(self):
        self.assertEqual(self.Prescription.medicine, "Vicodin")

