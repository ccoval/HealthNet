from django.contrib import admin

from .models import *
admin.site.register(Doctor)
admin.site.register(Patient)
admin.site.register(Nurse)
admin.site.register(HealthAdmin)
admin.site.register(SystemAdmin)
admin.site.register(Hospital)
admin.site.register(MedicalInfo)
admin.site.register(InsuranceInfo)
admin.site.register(Prescription)
admin.site.register(Test)
admin.site.register(Appointment)
admin.site.register(Message)
admin.site.register(Image)
admin.site.register(HospitalStay)
admin.site.register(Notification)
