from django.conf.urls import url
from django.conf.urls.static import static
from django.conf import settings

from .views import admin_doctor_nurse_registration
from .views import appointment_creation
from .views import appointment_modify
from .views import appointment_view_and_cancel
from .views import calendar
from .views import csv_receiver
from .views import exporting_patient_med_record
from .views import home_pages
from .views import login
from .views import medical_edit_patient
from .views import medical_images
from .views import messages_and_notification_functions
from .views import miscellaneous_functions
from .views import modify_patients
from .views import patient_admission
from .views import patient_medical_tests
from .views import patient_profile
from .views import patient_registration
from .views import patient_searching
from .views import patient_transfer
from .views import prescriptions
from .views import system_log
from .views import system_statistics
from .views import user_validation
from .views import weekly_appointment_view

urlpatterns = [

    # views.miscellaneous
    url(r'^$',
        miscellaneous_functions.index, name='index'),
    url(r'^not_validated/$',
        miscellaneous_functions.not_validated, name='not_validated'),
    url(r'^not_logged_in/$',
        miscellaneous_functions.not_logged_in, name='not_logged_in'),
    url(r'^wrong_user_or_password/$',
        miscellaneous_functions.wrong_user_or_password, name='wrong_user_or_password'),
    url(r'^user_not_authorized/$',
        miscellaneous_functions.user_not_authorized, name='user_not_authorized'),
    url(r'^insurance_prompt/$',
        miscellaneous_functions.insurance_prompt, name='insurance_prompt'),
    url(r'^sorry/$',
        miscellaneous_functions.sorry, name='sorry'),
    url(r'^leaving/$',
        miscellaneous_functions.leaving, name='leading'),
    url(r'^reg_landing/$',
        miscellaneous_functions.reg_landing, name='reg_landing'),
    url(r'^features/$',
        miscellaneous_functions.features, name='features'),
    url(r'^add_hospital/$',
        miscellaneous_functions.add_hospital, name='add_hospital'),


    # views.home
    url(r'^home/$',
        home_pages.home, name='home'),


    # views.appointments
    url(r'^newAppointment/$',
        appointment_creation.create_appointment, name='newAppointment'),
    url(r'^modifyAppointment/(?P<appointment_id>[0-9]+)/$',
        appointment_modify.modify_appointment, name='modifyAppointment'),
    url(r'^appointment/(?P<appointment_id>[0-9]+)/$',
        appointment_view_and_cancel.appointment, name='appointment'),
    url(r'^delete_appointment_confirmation/(?P<appointment_id>[0-9]+)/$',
        appointment_view_and_cancel.delete_appointment_check, name='delete_appointment_confirmation'),
    url(r'^cancelAppointment/(?P<appointment_id>[0-9]+)/$',
        appointment_view_and_cancel.cancel_appointment, name='cancelAppointment'),


    # views.system_log
    url(r'^log/$',
        system_log.log, name='log'),
    url(r'^log_alt/$',
        system_log.log_alt, name='log_alt'),
    #url(r'^time_constricted_log/$',
    #    system_log.time_constricted_log, name='time_constricted_log'),
    url(r'^view_system_statistics/$',
        system_statistics.view_system_statistics, name='view_system_statistics'),


    # views.calendar
    url(r'^calendar/$',
        calendar.this_month, name='calendar'),
    url(r'^calendar/(?P<year>[0-9]+)/(?P<month>[0-9]+)/$',
        calendar.calendar, name='calendar'),


    # views.weekly
    url(r'^weekly/$',
        weekly_appointment_view.weekly, name='weekly'),


    # views.patient_profile
    url(r'^user/(?P<user_id>[0-9]+)/$',
        patient_profile.profile, name='profile'),
    url(r'^export_record/(?P<user_id>[0-9]+)/$',
        exporting_patient_med_record.export_medical_record, name='export_record'),
    url(r'^privacy_warning/(?P<user_id>[0-9]+)/$',
        exporting_patient_med_record.privacy_warning, name='privacy_warning'),


    # views.login
    url(r'^login/$',
        login.login, name='login'),
    url(r'^logout/$',
        login.logout, name='logout'),
    url(r'^auth/$',
        login.auth_view, name='auth_view'),
    url(r'^goodbye/$',
        login.logout, name='goodbye'),


    # views.user_validation
    url(r'^unvalidated_users/$',
        user_validation.unvalidated_users, name='unvalidated_users'),
    url(r'^validate_doctor/(?P<doctor_id>[0-9]+)/$',
        user_validation.validate_doctor, name='validate_doctor'),
    url(r'^validate_nurse/(?P<nurse_id>[0-9]+)/$',
        user_validation.validate_nurse, name='validate_nurse'),
    url(r'^validate_admin/(?P<admin_id>[0-9]+)/$',
        user_validation.validate_admin, name='validate_admin'),


    # views.admin_doctor_nurse_registration
    url(r'^admin_registration/$',
        admin_doctor_nurse_registration.admin_registration, name='admin_registration'),
    url(r'^admin_register_user/$',
        admin_doctor_nurse_registration.admin_register_user, name='admin_register_user'),
    url(r'^register_doctor_user/$',
        admin_doctor_nurse_registration.register_doctor_user, name='register_doctor_user'),
    url(r'^register_nurse_user/$',
        admin_doctor_nurse_registration.register_nurse_user, name='register_nurse_user'),
    url(r'^register_admin_user/$',
        admin_doctor_nurse_registration.register_admin_user, name='register_admin_user'),
    url(r'^register_nurse/$',
        admin_doctor_nurse_registration.register_nurse, name='register_nurse'),
    url(r'^register_doctor/$',
        admin_doctor_nurse_registration.register_doctor, name='register_doctor'),
    url(r'^register_admin/$',
        admin_doctor_nurse_registration.register_admin, name='register_admin'),
    url(r'^admin_registration_success/$',
        admin_doctor_nurse_registration.admin_registration_success, name='admin_registration_success'),
    url(r'^staff_registration_success/$',
        admin_doctor_nurse_registration.staff_registration_success, name='admin_registration_success'),


    # views.patient_registration
    url(r'^register/$',
        patient_registration.register_user, name='register'),
    url(r'^first_login/$',
        patient_registration.first_log_in, name='first_login'),
    url(r'^first_auth/$',
        patient_registration.first_auth_view, name='first_auth'),
    url(r'^first_wrong_user_or_password/$',
        patient_registration.first_wrong_user_or_password, name='first_wrong_user_or_password'),
    url(r'^register_patient/$',
        patient_registration.register_patient, name='register_patient'),
    url(r'^register_insurance/$',
        patient_registration.register_insurance, name='register_insurance'),
    url(r'^register_medical_record/$',
        patient_registration.register_medical_record, name='register_medical_record'),
    url(r'^registration_success/$',
        patient_registration.registration_success, name='registration_success'),


    # views.modify_patients
    url(r'^modify_patient/$',
        modify_patients.modify_patient, name='modify_patient'),
    url(r'^confirm_medical_record/(?P<user_id>[0-9]+)/$',
        modify_patients.confirm_medical_record, name='confirm_medical_record'),
    url(r'^medical_record_confirmed/(?P<user_id>[0-9]+)/$',
        modify_patients.medical_record_confirmed, name='medical_record_confirmed'),
    url(r'^modify_insurance/$',
        modify_patients.modify_insurance, name='modify_insurance'),
    url(r'^modify_medical_record/$',
        modify_patients.modify_medical_record, name='modify_medical_record'),
    url(r'^confirming_medical_record/$',
        modify_patients.confirming_medical_record, name='confirming_medical_record'),


    # views.medical_edit_patient
    url(r'^staff_modify_medical_record/(?P<user_id>[0-9]+)/$',
        medical_edit_patient.staff_modify_medical_record, name='staff_modify_medical_record'),
    url(r'^medical_edit_user/(?P<user_id>[0-9]+)/$',
        medical_edit_patient.medical_edit_patient_record, name='view_patient_record'),


    # views.medical_images
    url(r'^upload_medical_image/(?P<user_id>[0-9]+)/$',
        medical_images.upload_medical_image, name='upload_medical_image'),
    url(r'^view_medical_images/(?P<user_id>[0-9]+)/$',
        medical_images.view_medical_images, name='view_medical_images'),
    url(r'^media/uploaded_files/(?P<user_id>[0-9]+)/(?P<image_id>[0-9]+)/(?P<file_name>[\w.]{0,256})$',
        medical_images.show_image, name='show_image'),
    url(r'^release_image/(?P<user_id>[0-9]+)/(?P<image_id>[0-9]+)/$',
        medical_images.release_image, name='release_image'),


    # views.prescriptions
    url(r'^prescriptions/(?P<user_id>[0-9]+)/$',
        prescriptions.prescriptions, name='prescriptions'),
    url(r'^create_prescription/(?P<user_id>[0-9]+)/$',
        prescriptions.create_prescription, name='create_prescription'),
    url(r'^cancel_prescription_check/(?P<user_id>[0-9]+)/(?P<prescription_id>[0-9]+)/$',
        prescriptions.cancel_prescription_check, name='cancel_prescription check'),
    url(r'^cancel_prescription/(?P<user_id>[0-9]+)/(?P<prescription_id>[0-9]+)/$',
        prescriptions.cancel_prescription, name='cancel_prescription'),


    # views.patient_medical_tests
    url(r'^tests/(?P<user_id>[0-9]+)/$',
        patient_medical_tests.tests, name='tests'),
    url(r'^create_test/(?P<user_id>[0-9]+)/$',
        patient_medical_tests.create_test, name='create test'),
    url(r'^modify_test/(?P<test_id>[0-9]+)/$',
        patient_medical_tests.modify_test, name='modify test'),


    # views.patient_searching
    url(r'^my_patient_list/$',
        patient_searching.my_patient_list, name='my_patient_list'),
    url(r'^doctor_patient_search/$',
        patient_searching.doctor_patient_search, name='doctor_patient_search'),
    url(r'^nurse_patient_search/$',
        patient_searching.nurse_patient_search, name='nurse_patient_search'),


    # views.patient_admission
    url(r'^admitted_patients/$',
        patient_admission.admitted_patients, name='admitted_patients'),
    url(r'^unadmitted_patients/$',
        patient_admission.unadmitted_patients, name='unadmitted_patients'),
    url(r'^admit_patient/(?P<patient_id>[0-9]+)/$',
        patient_admission.admit_patient, name='admit_patient'),
    url(r'^discharge/(?P<patient_id>[0-9]+)/$',
        patient_admission.discharge, name='discharge'),
    url(r'^notify_doctor/(?P<patient_id>[0-9]+)/$',
        patient_admission.notify_doctor, name='notify_doctor'),



    # views.messages_and_notification_functions
    url(r'^messages/(?P<user_id>[0-9]+)/$',
        messages_and_notification_functions.messages, name='messages'),
    url(r'^new_message/$',
        messages_and_notification_functions.new_message, name='new_message'),
    url(r'^show_message/(?P<message_id>[0-9]+)/$',
        messages_and_notification_functions.show_message, name='show_message'),
    url(r'^reply_message/(?P<message_id>[0-9]+)/$',
        messages_and_notification_functions.reply_message, name='reply_message'),
    url(r'^delete_message/(?P<message_id>[0-9]+)/$',
        messages_and_notification_functions.delete_message, name='delete_message'),
    url(r'^notifications/(?P<user_id>[0-9]+)/$',
        messages_and_notification_functions.notifications, name='notifications'),
    url(r'^delete_notification/(?P<notification_id>[0-9]+)/$',
        messages_and_notification_functions.delete_notification, name='delete_notification'),


    # views.patient_transfer
    url(r'^admin_transferable/$',
        patient_transfer.admin_transferable, name='admin_transferable'),
    url(r'^admin_transferring/(?P<patient_id>[0-9]+)/$',
        patient_transfer.admin_transferring, name='admin_transferring'),
    url(r'^doctor_receivable/$',
        patient_transfer.doctor_receivable, name='doctor_receivable'),
    url(r'^doctor_receiving/(?P<patient_id>[0-9]+)/$',
        patient_transfer.doctor_receiving, name='doctor_receiving'),

    # views.csv_receiver
    url(r'^csv_receiver/$',
        csv_receiver.csv_input, name='csv_receiver'),


] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
