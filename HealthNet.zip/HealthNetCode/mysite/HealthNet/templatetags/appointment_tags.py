from calendar import HTMLCalendar
from time import strftime

from django import template
from datetime import date
from itertools import groupby
from django.utils.html import conditional_escape as esc

register = template.Library()


def do_appointment_calendar(parser, token):
    """
    The template tag's syntax is {% appointment_calendar year month appointment_list %}
    """

    try:
        tag_name, year, month, appointment_list = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError("%r tag requires three arguments" % token.contents.split()[0])
    return AppointmentCalendarNode(year, month, appointment_list)


class AppointmentCalendarNode(template.Node):
    """
    Process a particular node in the template. Fail silently.
    """

    def __init__(self, year, month, appointment_list):
        try:
            self.year = template.Variable(year)
            self.month = template.Variable(month)
            self.appointment_list = template.Variable(appointment_list)
        except ValueError:
            raise template.TemplateSyntaxError

    def render(self, context):
        try:
            # Get the variables from the context so the method is thread-safe.
            my_appointment_list = self.appointment_list.resolve(context)
            my_year = self.year.resolve(context)
            my_month = self.month.resolve(context)
            cal = AppointmentCalendar(my_appointment_list)
            return cal.formatmonth(int(my_year), int(my_month))
        except ValueError:
            return
        except template.VariableDoesNotExist:
            return


class AppointmentCalendar(HTMLCalendar):
    """
    Overload Python's calendar.HTMLCalendar to add the appropriate appointments to
    each day's table cell.
    """

    def __init__(self, appointments):
        super(AppointmentCalendar, self).__init__()
        self.appointments = self.group_by_day(appointments)

    def formatday(self, day, weekday):
        if day != 0:
            cssclass = self.cssclasses[weekday]
            if date.today() == date(self.year, self.month, day):
                cssclass += ' today'
            if day in self.appointments:
                cssclass += ' filled'
                body = ['<div class="scrollit" align="left"><ul>']
                for appointment in self.appointments[day]:
                    body.append('<li>')
                    body.append('<a href="http://localhost:8000/HealthNet/appointment/' +
                                str(appointment.get_absolute_url()) + '">')
                    body.append(esc('Appointment: ' + appointment.title))
                    body.append('</a></li>')
                    body.append(esc('Dr. ' +
                                    appointment.doctor.user.first_name + " " + appointment.doctor.user.last_name))
                    body.append('<br>')
                    body.append(esc('Patient: ' +
                                    appointment.patient.user.first_name + " " + appointment.patient.user.last_name))
                    body.append('<br>')
                    body.append('From ' + str(appointment.start_time) + ' to ' + str(appointment.end_time))
                    body.append('<br>Hospital: ' + str(appointment.hospital) + '</br>')

                body.append('</ul></div>')
                return self.day_cell(cssclass, '<span class="dayNumber">%d</span> %s' % (day, ''.join(body)))
            return self.day_cell(cssclass, '<span class="dayNumberNoAppointments">%d</span>' % (day))
        return self.day_cell('noday', '&nbsp;')

    def formatmonth(self, year, month):
        self.year, self.month = year, month
        return super(AppointmentCalendar, self).formatmonth(year, month)

    def group_by_day(self, appointments):
        field = lambda appointment: appointment.start_date.day
        return dict(
            [(day, list(items)) for day, items in groupby(appointments, field)]
        )

    def day_cell(self, cssclass, body):
        return '<td class="%s">%s</td>' % (cssclass, body)


# Register the template tag so it is available to templates
register.tag("appointment_calendar", do_appointment_calendar)
