from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.forms.utils import ErrorList
from django.http import HttpResponseRedirect
from django.shortcuts import render
from datetime import datetime, timedelta

from .miscellaneous_functions import setup_taskbar
from ..forms import MyAppointmentForm, MyPatientAppointmentForm, MyDoctorAppointmentForm
from ..models import *


# #####################################################################################################################
# ########################################## Appointment Modify Begin #################################################
# #####################################################################################################################


def modify_appointment(request, appointment_id):
    """
    Master View controlling modification of appointments
    :param request: Basic Server Access Info
    :param appointment_id: ID of Appointment to be Modified
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                if request.user.patient is not None:
                    return modify_appointment_patient(request, appointment_id)
            except ObjectDoesNotExist:
                pass
            try:
                if request.user.doctor is not None:
                    return modify_appointment_doctor(request, appointment_id)
            except ObjectDoesNotExist:
                pass
            try:
                if request.user.nurse is not None:
                    return modify_appointment_nurse(request, appointment_id)
            except ObjectDoesNotExist:
                pass
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def modify_appointment_patient(request, appointment_id):
    """
    View controlling modification of appointments by patients
    :param request: Basic Server Access Info
    :param appointment_id: ID of Appointment to be Modified
    """
    oldapt = Appointment.objects.get(id=appointment_id)
    if request.method == 'POST':
        newapt = MyPatientAppointmentForm(request.POST, instance=oldapt, prefix='appointment')
        if newapt.is_valid():
            patient = request.user.patient
            appointmnt = newapt.save(commit=False)
            appointmnt.patient = patient
            appointmnt.hospital = patient.hospital
            appointmnt.doctor = patient.primaryDoc
            end = datetime.combine(appointmnt.start_date, appointmnt.start_time) + timedelta(minutes = 30)
            appointmnt.end_date = end.date()
            appointmnt.end_time = end.time()
            if appointmnt.is_correct():
                if appointmnt.is_available():
                    newapt.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(appointmnt).pk,
                        object_id=appointmnt.id,
                        object_repr=appointmnt.title,
                        action_flag=CHANGE,
                        change_message="Appointment for " + appointmnt.title + " for " +
                                       appointmnt.patient.user.username + " has been modified.")
                    notification = Notification(content=patient.fullName + " has rescheduled an appointment for " +
                                                    str(appointmnt.start_date) + " at " + str(appointmnt.start_time),
                                                    viewed=False, recipient=patient.primaryDoc.user.email,
                                                    author=request.user.email, sent_time=datetime.now().time(),
                                                    sent_date=datetime.now().date())
                    notification.save()
                    return HttpResponseRedirect('/HealthNet/calendar/')

                else:
                    errors = newapt.errors.setdefault("start_time", ErrorList())
                    errors.append(u"This Appointment is Unavailable")
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/appointments/modifyAppointment.html',
                                  dict(aptform=newapt,
                                       current_user=request.user,
                                       Notifications=taskbar[1],
                                       needs_to_be_viewed=taskbar[2],
                                       user_type=taskbar[0]))

            else:
                errors = newapt.errors.setdefault("start_time", ErrorList())
                errors.append(u"This Appointment is Invalid")
                taskbar = setup_taskbar(request)
                return render(request, 'HealthNet/appointments/modifyAppointment.html',
                              dict(aptform=newapt,
                                   current_user=request.user,
                                   Notifications=taskbar[1],
                                   needs_to_be_viewed=taskbar[2],
                                   user_type=taskbar[0]))
    else:
        newapt = MyPatientAppointmentForm(instance=oldapt, prefix='appointment')
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/appointments/modifyAppointment.html', dict(aptform=newapt,
                                                                                 current_user=request.user,
                                                                                 Notifications=taskbar[1],
                                                                                 needs_to_be_viewed=taskbar[2],
                                                                                 user_type=taskbar[0]))


def modify_appointment_doctor(request, appointment_id):
    """
    View controlling modification of appointments by doctors
    :param request: Basic Server Access Info
    :param appointment_id: ID of Appointment to be Modified
    """
    oldapt = Appointment.objects.get(id=appointment_id)
    if request.method == 'POST':
        newapt = MyDoctorAppointmentForm(request.POST, instance=oldapt, prefix='appointment')
        if newapt.is_valid():
            doctor = request.user.doctor
            appointmnt = newapt.save(commit=False)
            appointmnt.doctor = doctor
            if appointmnt.is_correct():
                if appointmnt.is_available():
                    newapt.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(appointmnt).pk,
                        object_id=appointmnt.id,
                        object_repr=appointmnt.title,
                        action_flag=CHANGE,
                        change_message="Appointment for " + appointmnt.title + " for " +
                                       appointmnt.patient.user.username + " has been modified.")
                    notification = Notification(content=doctor.user.first_name + " " + doctor.user.last_name + " has rescheduled an appointment for " +
                                                    str(appointmnt.start_date) + " at " + str(appointmnt.start_time),
                                                    viewed=False, recipient=appointmnt.patient.user.email,
                                                    author=request.user.email, sent_time=datetime.now().time(),
                                                    sent_date=datetime.now().date())
                    notification.save()
                    return HttpResponseRedirect('/HealthNet/calendar/')

                else:
                    errors = newapt.errors.setdefault("start_time", ErrorList())
                    errors.append(u"This Appointment is Unavailable")
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/appointments/modifyAppointment.html',
                                  dict(aptform=newapt,
                                       current_user=request.user,
                                       Notifications=taskbar[1],
                                       needs_to_be_viewed=taskbar[2],
                                       user_type=taskbar[0]))

            else:
                errors = newapt.errors.setdefault("start_time", ErrorList())
                errors.append(u"This Appointment is Invalid")
                taskbar = setup_taskbar(request)
                return render(request, 'HealthNet/appointments/modifyAppointment.html',
                              dict(aptform=newapt,
                                   current_user=request.user,
                                   Notifications=taskbar[1],
                                   needs_to_be_viewed=taskbar[2],
                                   user_type=taskbar[0]))
    else:
        newapt = MyDoctorAppointmentForm(instance=oldapt, prefix='appointment')
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/appointments/modifyAppointment.html', dict(aptform=newapt,
                                                                                 current_user=request.user,
                                                                                 Notifications=taskbar[1],
                                                                                 needs_to_be_viewed=taskbar[2],
                                                                                 user_type=taskbar[0]))


def modify_appointment_nurse(request, appointment_id):
    """
    View controlling modification of appointments by nurses
    :param request: Basic Server Access Info
    :param appointment_id: ID of Appointment to be Modified
    """
    oldapt = Appointment.objects.get(id=appointment_id)
    if request.method == 'POST':
        newapt = MyAppointmentForm(request.POST, instance=oldapt, prefix='appointment')
        if newapt.is_valid():
            appointmnt = newapt.save(commit=False)
            if appointmnt.is_correct():
                if appointmnt.is_available():
                    newapt.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(appointmnt).pk,
                        object_id=appointmnt.id,
                        object_repr=appointmnt.title,
                        action_flag=CHANGE,
                        change_message="Appointment for " + appointmnt.title + " for " +
                                       appointmnt.patient.user.username + " has been modified.")
                    notification = Notification(content=request.user.first_name + " " + request.user.last_name + " has rescheduled an appointment for " +
                                                    str(appointmnt.start_date) + " at " + str(appointmnt.start_time),
                                                    viewed=False, recipient=appointmnt.patient.user.email,
                                                    author=request.user.email, sent_time=datetime.now().time(),
                                                    sent_date=datetime.now().date())
                    notification.save()
                    return HttpResponseRedirect('/HealthNet/calendar/')

                else:
                    errors = newapt.errors.setdefault("start_time", ErrorList())
                    errors.append(u"This Appointment is Unavailable")
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/appointments/modifyAppointment.html',
                                  dict(aptform=newapt,
                                       current_user=request.user,
                                       Notifications=taskbar[1],
                                       needs_to_be_viewed=taskbar[2],
                                       user_type=taskbar[0]))

            else:
                errors = newapt.errors.setdefault("start_time", ErrorList())
                errors.append(u"This Appointment is Invalid")
                taskbar = setup_taskbar(request)
                return render(request, 'HealthNet/appointments/modifyAppointment.html',
                              dict(aptform=newapt,
                                   current_user=request.user,
                                   Notifications=taskbar[1],
                                   needs_to_be_viewed=taskbar[2],
                                   user_type=taskbar[0]))
    else:
        newapt = MyAppointmentForm(instance=oldapt, prefix='appointment')
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/appointments/modifyAppointment.html', dict(aptform=newapt,
                                                                                 current_user=request.user,
                                                                                 Notifications=taskbar[1],
                                                                                 needs_to_be_viewed=taskbar[2],
                                                                                 user_type=taskbar[0]))


# #####################################################################################################################
# ########################################## Appointment Modify End ###################################################
# #####################################################################################################################
