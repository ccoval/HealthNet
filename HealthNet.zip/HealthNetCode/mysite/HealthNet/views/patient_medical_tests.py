from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import setup_taskbar
from ..forms import MyTestForm
from ..models import *


# #####################################################################################################################
# ########################################## Tests Begins #############################################################
# #####################################################################################################################


def tests(request, user_id):
    """
    View controlling the view of all tests related to a specific patient
    :param request: Basic Server Access Info
    :param user_id: ID of Patient to View Tests of
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            usr = User.objects.get(pk=user_id).patient
            medinfo = usr.medicalRecord
            tsts = Test.objects.filter(medicalInfo=medinfo)
            try:
                if request.user.doctor is not None:
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/tests/tests_doctor.html', {'Patient': usr,
                                                                                 'Tests': tsts,
                                                                                 'current_user': request.user,
                                                                                 'Notifications': taskbar[1],
                                                                                 'needs_to_be_viewed': taskbar[2],
                                                                                 'user_type': taskbar[0]})
            except ObjectDoesNotExist:
                pass
            try:
                tsts = Test.objects.filter(medicalInfo=medinfo, hasResults=True)
                pat = False
                try:
                    if request.user.patient is not None:
                        pat = True
                except ObjectDoesNotExist:
                    pass

                taskbar = setup_taskbar(request)
                return render(request, 'HealthNet/tests/tests.html', {'Patient': usr,
                                                                      'Tests': tsts,
                                                                      'current_user': request.user,
                                                                      'is_Patient': pat,
                                                                      'Notifications': taskbar[1],
                                                                      'needs_to_be_viewed': taskbar[2],
                                                                      'user_type': taskbar[0]})
            except ObjectDoesNotExist:
                pass
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def create_test(request, user_id):
    """
    View controlling the creation of a test for a specific patient
    :param request: Basic Server Access Info
    :param user_id: ID of Patient to Create Test for
    """
    if 'user_id' in request.session:
        usr = request.user
        if usr.is_authenticated():
            try:
                if request.user.doctor is not None:
                    usr = User.objects.get(pk=user_id)
                    medinfo = usr.patient.medicalRecord
                    if request.method == 'POST':
                        tst = MyTestForm(request.POST, prefix='test')
                        if tst.is_valid():
                            test = tst.save(commit=False)
                            test.medicalInfo = medinfo
                            test.save()
                            if test.hasResults:
                                notification = Notification(content="You have new released test results.",
                                viewed=False,
                                recipient=usr.email, author=request.user.email, sent_time=datetime.now().time(),
                                sent_date=datetime.now().date())
                                notification.save()
                            return HttpResponseRedirect('/HealthNet/tests/' + user_id + '/')

                    else:
                        tst = MyTestForm(prefix='test')
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/tests/create_test.html', dict(tstform=tst,
                                                                                    current_user=request.user,
                                                                                    patient=user_id,
                                                                                    Notifications=taskbar[1],
                                                                                    needs_to_be_viewed=taskbar[2],
                                                                                    user_type=taskbar[0]))

            except ObjectDoesNotExist:
                pass

            return HttpResponseRedirect('/HealthNet/user_not_authorized/')
    else:
        return HttpResponseRedirect('/HealthNet/user_not_authorized/')


def modify_test(request, test_id):
    """
    View controlling the modification of a test for a specific patient
    :param request: Basic Server Access Info
    :param test_id: ID of Test to Modify
    """
    if 'user_id' in request.session:
        usr = request.user
        if usr.is_authenticated():
            try:
                oldtst = Test.objects.get(id=test_id)
                pat = oldtst.medicalInfo.patient.user.id
                if request.method == 'POST':
                    newtst = MyTestForm(request.POST, instance=oldtst, prefix='test')
                    if newtst.is_valid:
                        test = newtst.save(commit=False)
                        newtst.save()
                        if test.hasResults:
                            notification = Notification(content="You have new released test results.",
                            viewed=False,
                            recipient=test.medicalInfo.patient.user.email, author=request.user.email,
                            sent_time=datetime.now().time(), sent_date=datetime.now().date())
                            notification.save()
                        return HttpResponseRedirect('/HealthNet/tests/' + str(int(pat)) + '/')
                    else:
                        return HttpResponseRedirect('/HealthNet/modify_test/' +
                                                    str(int(test_id)) + '/')
                else:
                    newtst = MyTestForm(instance=oldtst, prefix='test')
                taskbar = setup_taskbar(request)
                return render(request, 'HealthNet/tests/modify_test.html', dict(tstform=newtst,
                                                                                current_user=request.user,
                                                                                patient=pat,
                                                                                Notifications=taskbar[1],
                                                                                needs_to_be_viewed=taskbar[2],
                                                                                user_type=taskbar[0]))
            except ObjectDoesNotExist:
                pass

            return HttpResponseRedirect('/HealthNet/user_not_authorized/')
    else:
        return HttpResponseRedirect('/HealthNet/user_not_authorized/')


# #####################################################################################################################
# ########################################## Tests Ends ###############################################################
# #####################################################################################################################
