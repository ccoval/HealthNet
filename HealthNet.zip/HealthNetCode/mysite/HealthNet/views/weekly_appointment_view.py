from datetime import timedelta

from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import setup_taskbar
from ..models import *

# #####################################################################################################################
# ########################################## Weekly Appointment View Begin ############################################
# #####################################################################################################################


def weekly(request):
    """
    Displays a weekly view of the logged-in user's appointments
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            if int(str(date.today().weekday())) == 0:
                my_weekday = "Monday"
            elif int(str(date.today().weekday())) == 1:
                my_weekday = "Tuesday"
            elif int(str(date.today().weekday())) == 2:
                my_weekday = "Wednesday"
            elif int(str(date.today().weekday())) == 3:
                my_weekday = "Thursday"
            elif int(str(date.today().weekday())) == 4:
                my_weekday = "Friday"
            elif int(str(date.today().weekday())) == 5:
                my_weekday = "Saturday"
            else:
                my_weekday = "Sunday"
            args = {'today': date.today(),
                    'weekday': my_weekday}
            start_week = args['today'] - timedelta(datetime.now().weekday())
            end_week = start_week + timedelta(7)
            appointments = None
            try:
                if user.patient is not None:
                    appointments = user.patient.appointments.all().filter(
                        start_date__range=[start_week, end_week])
                    args['appointment'] = appointments
            except ObjectDoesNotExist:
                pass
            try:
                if user.doctor is not None:
                    appointments = user.doctor.appointments.all().filter(
                        start_date__range=[start_week, end_week])
                    args['appointment'] = appointments
            except ObjectDoesNotExist:
                pass
            try:
                if user.nurse is not None:
                    try:
                        if user.nurse.hospital.appointments is not None:
                            appointments = user.nurse.hospital.appointments.all().filter(
                                start_date__range=[start_week, end_week])
                            args['appointment'] = appointments
                    except ObjectDoesNotExist:
                        pass
            except ObjectDoesNotExist:
                pass
            args['Monday'] = appointments.filter(
                start_date__range=[start_week, start_week + timedelta(days=1, seconds=-1)])
            args['Tuesday'] = appointments.filter(
                start_date__range=[start_week + timedelta(days=1), start_week + timedelta(days=2, seconds=-1)])
            args['Wednesday'] = appointments.filter(
                start_date__range=[start_week + timedelta(days=2), start_week + timedelta(days=3, seconds=-1)])
            args['Thursday'] = appointments.filter(
                start_date__range=[start_week + timedelta(days=3), start_week + timedelta(days=4, seconds=-1)])
            args['Friday'] = appointments.filter(
                start_date__range=[start_week + timedelta(days=4), start_week + timedelta(days=5, seconds=-1)])
            args['Saturday'] = appointments.filter(
                start_date__range=[start_week + timedelta(days=5), start_week + timedelta(days=6, seconds=-1)])
            args['Sunday'] = appointments.filter(
                start_date__range=[start_week + timedelta(days=6), start_week + timedelta(days=7, seconds=-1)])
            args['days'] = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            args['current_user'] = request.user
            taskbar = setup_taskbar(request)
            args['Notifications'] = taskbar[1]
            args['needs_to_be_viewed'] = taskbar[2]
            args['user_type'] = taskbar[0]
            return render(request, 'HealthNet/calendar/weekly.html', args)
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


# #####################################################################################################################
# ########################################## Weekly Appointment View End ##############################################
# #####################################################################################################################
