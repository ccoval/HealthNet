from calendar import monthrange
from datetime import timedelta

from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import setup_taskbar
from .modify_patients import medical_record_not_confirmed
from ..models import *


# #####################################################################################################################
# ########################################## Calendar Begin ###########################################################
# #####################################################################################################################


def named_month(month_number):
    """
    Function to receive the name of a month
    :param month_number: number of the month
    """
    return date(1900, month_number, 1).strftime("%B")


def this_month(request):
    """
    View sending the request to produce a calendar with the current month as a start point
    :param request: Basic Server Access Info
    """
    today = datetime.now()
    return calendar(request, today.year, today.month)


def calendar(request, year, month, series_id=None):
    """
    View controlling the setup of a calendar with the given start month and year. Serves as its own master view,
    filtering user types to produce the proper calendar
    :param request: Basic Server Access Info
    :param year: Starting Year
    :param month: Start Month
    :param series_id: Sorting Filter for Events
    :return:
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                if user.patient is not None:
                    if user.patient.medicalRecord.confirmed is not True:
                        return medical_record_not_confirmed(request)
            except ObjectDoesNotExist:
                pass
            my_year = int(year)
            my_month = int(month)
            my_calendar_from_month = datetime(my_year, my_month, 1)
            my_calendar_to_month = datetime(my_year, my_month, monthrange(my_year, my_month)[1])
            my_appointments = None
            try:
                if user.patient is not None:
                    my_appointments = user.patient.appointments.all().filter(
                        start_date__gte=my_calendar_from_month).filter(
                        start_date__lte=my_calendar_to_month)
            except ObjectDoesNotExist:
                pass

            try:
                if user.doctor is not None:
                    my_appointments = user.doctor.appointments.all().filter(
                        start_date__gte=my_calendar_from_month).filter(
                        start_date__lte=my_calendar_to_month)
            except ObjectDoesNotExist:
                pass

            try:
                if user.nurse is not None:
                    try:
                        if user.nurse.hospital.appointments is not None:
                            if int(str(date.today().weekday())) == 0:
                                my_weekday = "Monday"
                            elif int(str(date.today().weekday())) == 1:
                                my_weekday = "Tuesday"
                            elif int(str(date.today().weekday())) == 2:
                                my_weekday = "Wednesday"
                            elif int(str(date.today().weekday())) == 3:
                                my_weekday = "Thursday"
                            elif int(str(date.today().weekday())) == 4:
                                my_weekday = "Friday"
                            elif int(str(date.today().weekday())) == 5:
                                my_weekday = "Saturday"
                            else:
                                my_weekday = "Sunday"
                            args = {'today': date.today(),
                                    'weekday': my_weekday}
                            start_week = args['today'] - timedelta(datetime.now().weekday())
                            end_week = start_week + timedelta(7)
                            args['appointment'] = user.nurse.hospital.appointments.all().filter(
                                start_date__range=[start_week, end_week])
                            args['Monday'] = Appointment.objects.filter(
                                start_date__range=[start_week, start_week + timedelta(days=1, seconds=-1)])
                            args['Tuesday'] = Appointment.objects.filter(
                                start_date__range=[start_week +
                                                   timedelta(days=1), start_week + timedelta(days=2, seconds=-1)])
                            args['Wednesday'] = Appointment.objects.filter(
                                start_date__range=[start_week +
                                                   timedelta(days=2), start_week + timedelta(days=3, seconds=-1)])
                            args['Thursday'] = Appointment.objects.filter(
                                start_date__range=[start_week +
                                                   timedelta(days=3), start_week + timedelta(days=4, seconds=-1)])
                            args['Friday'] = Appointment.objects.filter(
                                start_date__range=[start_week +
                                                   timedelta(days=4), start_week + timedelta(days=5, seconds=-1)])
                            args['Saturday'] = Appointment.objects.filter(
                                start_date__range=[start_week +
                                                   timedelta(days=5), start_week + timedelta(days=6, seconds=-1)])
                            args['Sunday'] = Appointment.objects.filter(
                                start_date__range=[start_week +
                                                   timedelta(days=6), start_week + timedelta(days=7, seconds=-1)])
                            args['days'] = ["Monday", "Tuesday", "Wednesday",
                                            "Thursday", "Friday", "Saturday", "Sunday"]
                            args['current_user'] = request.user
                            taskbar = setup_taskbar(request)
                            args['Notifications'] = taskbar[1]
                            args['needs_to_be_viewed'] = taskbar[2]
                            args['user_type'] = taskbar[0]
                            return render(request, 'HealthNet/calendar/nurse_weekly.html', args)

                    except ObjectDoesNotExist:
                        pass
            except ObjectDoesNotExist:
                pass

            if series_id:
                my_appointments = my_appointments.filter(series=series_id)

            # Calculate values for the calendar controls. 1-indexed (Jan = 1)
            my_previous_year = my_year
            my_previous_month = my_month - 1
            if my_previous_month == 0:
                my_previous_year = my_year - 1
                my_previous_month = 12
            my_next_year = my_year
            my_next_month = my_month + 1
            if my_next_month == 13:
                my_next_year = my_year + 1
                my_next_month = 1
            my_year_after_this = my_year + 1
            my_year_before_this = my_year - 1
            taskbar = setup_taskbar(request)
            return render(request, "HealthNet/calendar/appointment_calendar.html",
                          {'appointment_list': my_appointments,
                           'month': my_month,
                           'month_name': named_month(my_month),
                           'year': my_year,
                           'previous_month': my_previous_month,
                           'previous_month_name': named_month(
                               my_previous_month),
                           'previous_year': my_previous_year,
                           'next_month': my_next_month,
                           'next_month_name': named_month(
                               my_next_month),
                           'next_year': my_next_year,
                           'year_before_this': my_year_before_this,
                           'year_after_this': my_year_after_this,
                           'current_user': request.user,
                           'Notifications': taskbar[1],
                           'needs_to_be_viewed': taskbar[2],
                           'user_type': taskbar[0]})

    return HttpResponseRedirect('/HealthNet/not_logged_in/')


# #####################################################################################################################
# ########################################## Calendar End #############################################################
# #####################################################################################################################
