from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import user_not_authorized, setup_taskbar
from ..forms import MyPatientForm, MyInsuranceForm, MyRequiredMedicalRecordForm
from ..models import *


# #####################################################################################################################
# ########################################## Modify Patients Begin ####################################################
# #####################################################################################################################


def modify_patient(request):
    """
    View controlling the modification by a patient of their basic information (Patient Model)
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            oldpt = Patient.objects.get(id=request.user.patient.id)
            if request.method == 'POST':
                newpt = MyPatientForm(request.POST, instance=oldpt, prefix='userprofile')
                if newpt.is_valid():
                    oldpt = newpt.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(oldpt).pk,
                        object_id=request.user.patient.id,
                        object_repr=request.user.first_name,
                        action_flag=CHANGE, change_message="Profile Info of, " + request.user.first_name + " " +
                                                           request.user.last_name + ", was modified.")
                    return HttpResponseRedirect(
                        '/HealthNet/user/' + str(int(request.user.id)) + '/')
                else:
                    return HttpResponseRedirect('/HealthNet/modify_patient/')
            else:
                newpt = MyPatientForm(instance=oldpt, prefix='userprofile')
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/patient_profile/modify_patient.html',
                          dict(userprofileform=newpt,
                               current_user=request.user,
                               Notifications=taskbar[1],
                               needs_to_be_viewed=taskbar[2],
                               user_type=taskbar[0]))
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def modify_insurance(request):
    """
    View controlling the modification by a patient of their insurance information (InsuranceInfo Model)
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            oldir = InsuranceInfo.objects.get(id=request.user.patient.insurance.id)
            if request.method == 'POST':
                newir = MyInsuranceForm(request.POST, instance=oldir, prefix='insurance')
                if newir.is_valid():
                    oldir = newir.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(oldir).pk,
                        object_id=request.user.patient.insurance.id,
                        object_repr=request.user.first_name,
                        action_flag=CHANGE, change_message="Insurance of, " + request.user.first_name + " " +
                                                           request.user.last_name + ", was modified.")
                    return HttpResponseRedirect(
                        '/HealthNet/user/' + str(int(request.user.id)) + '/')
            else:
                newir = MyInsuranceForm(instance=oldir, prefix='insurance')
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/patient_profile/modify_insurance.html',
                          dict(insuranceform=newir,
                               current_user=request.user,
                               Notifications=taskbar[1],
                               needs_to_be_viewed=taskbar[2],
                               user_type=taskbar[0]))
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def modify_medical_record(request):
    """
    View controlling the modification by a patient of their medical record (MedicalInfo Model)
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            oldmr = MedicalInfo.objects.get(id=request.user.patient.medicalRecord.id)
            if request.method == 'POST':
                newmr = MyRequiredMedicalRecordForm(request.POST, instance=oldmr, prefix='medical_record')
                if newmr.is_valid():
                    oldmr = newmr.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(oldmr).pk,
                        object_id=request.user.patient.medicalRecord.id,
                        object_repr=request.user.first_name,
                        action_flag=CHANGE, change_message="Medical Record of, " + request.user.first_name + " " +
                                                           request.user.last_name + ", was modified.")
                    return HttpResponseRedirect(
                        '/HealthNet/user/' + str(int(request.user.id)) + '/')
            else:
                newmr = MyRequiredMedicalRecordForm(instance=oldmr, prefix='medical_record')
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/patient_profile/patient_modify_medical_record.html',
                          dict(medicalrecordform=newmr,
                               current_user=request.user,
                               Notifications=taskbar[1],
                               needs_to_be_viewed=taskbar[2],
                               user_type=taskbar[0]))
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def confirm_medical_record(request, user_id):
    """
    View controlling the confirmation of a medical record's information by that patient
    :param request: Basic Server Access Info
    :param user_id: User ID of the Patient Confirming Their Record
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    try:
                        user = User.objects.get(pk=user_id)
                    except User.DoesNotExist:
                        raise Http404("This HealthNet User does not exist")
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/patient_profile/confirm_medical_record_check.html',
                                  {'User': user,
                                   'current_user': request.user,
                                   'Notifications': taskbar[1],
                                   'needs_to_be_viewed': taskbar[2],
                                   'user_type': taskbar[0]})
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def medical_record_confirmed(request, user_id):
    """
    View controlling the actual confirmation of a medical record by a patient
    :param request: Basic Server Access Info
    :param user_id: User ID of the Patient Confirming Their Record
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                user = User.objects.get(pk=user_id)
                mr = user.patient.medicalRecord
                mr.confirmed = True
                mr.save()
                LogEntry.objects.log_action(
                    content_type_id=ContentType.objects.get_for_model(mr).pk,
                    object_id=mr.id,
                    object_repr=str(mr),
                    user_id=request.user.id,
                    action_flag=CHANGE,
                    change_message="Medical Record of " + user.patient.fullName + ", was confirmed")
            except User.DoesNotExist:
                raise Http404("This HealthNet User does not exist")
            return HttpResponseRedirect('/HealthNet/user/' + user_id + "/")
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def medical_record_not_confirmed(request):
    return render(request, 'HealthNet/patient_profile/medical_record_not_confirmed.html',
                  {'current_user': request.user})


def confirming_medical_record(request):
    """
    View controlling the modification by a patient of their medical record (Medical Info Model)
    prior to confirming the information as correct
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            oldmr = MedicalInfo.objects.get(id=request.user.patient.medicalRecord.id)
            if request.method == 'POST':
                newmr = MyRequiredMedicalRecordForm(request.POST, instance=oldmr, prefix='medical_record')
                if newmr.is_valid():
                    oldmr = newmr.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(oldmr).pk,
                        object_id=request.user.patient.medicalRecord.id,
                        object_repr=request.user.first_name,
                        action_flag=CHANGE, change_message="Medical Record of, " + request.user.first_name + " " +
                                                           request.user.last_name + ", was modified.")
                    return HttpResponseRedirect(
                        '/HealthNet/confirm_medical_record/' + str(int(request.user.id)) + '/')
            else:
                newmr = MyRequiredMedicalRecordForm(instance=oldmr, prefix='medical_record')
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/patient_profile/confirming_medical_record.html',
                          dict(medicalrecordform=newmr,
                               current_user=request.user,
                               Notifications=taskbar[1],
                               needs_to_be_viewed=taskbar[2],
                               user_type=taskbar[0]))
    return HttpResponseRedirect('/HealthNet/not_logged_in/')

# #####################################################################################################################
# ########################################## Modify Patients End ######################################################
# #####################################################################################################################
