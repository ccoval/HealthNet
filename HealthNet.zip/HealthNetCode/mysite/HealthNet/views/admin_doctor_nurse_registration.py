from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.db import IntegrityError
from django.forms.utils import ErrorList
from django.http import HttpResponseRedirect
from django.shortcuts import render, render_to_response
from django.template import RequestContext

from ..forms import MyRegistrationForm, MyNurseForm, MyAdminRegistrationForm, \
    MyDoctorForm, MyHealthAdminForm
from ..models import *
from .miscellaneous_functions import setup_taskbar


# #####################################################################################################################
# ########################################## Admin, Doctor, and Nurse Registration Begin ##############################
# #####################################################################################################################


def admin_registration(request):
    """
    View to setup Health Administrator's ability to register new staff members in the HealthNet System
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        tf = MyAdminRegistrationForm(request.POST)
        if tf.is_valid():
            registration_type = tf.cleaned_data['registration_type']
            request.session['registration_type'] = registration_type
            request.session['admin_registration'] = True
            return HttpResponseRedirect('/HealthNet/admin_register_user/')
    else:
        tf = MyAdminRegistrationForm
    taskbar = setup_taskbar(request)
    return render_to_response('HealthNet/doc_nurse_admin_registration/admin_registration.html',
                              dict(typeform=tf,
                                   current_user=request.user,
                                   Notifications=taskbar[1],
                                   needs_to_be_viewed=taskbar[2],
                                   user_type=taskbar[0]
                                   ),
                              context_instance=RequestContext(request))


def admin_register_user(request):
    """
    View controlling Health Administrator user registration setup
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        uf = MyRegistrationForm(request.POST, prefix='user')
        if uf.is_valid():
            user = uf.save(commit=False)
            user.username = user.email
            request.session['registrant_username'] = user.username
            if request.session['registration_type'] == 'Nurse':
                try:
                    user.save()
                except IntegrityError:
                    errors = uf.errors.setdefault("email", ErrorList())
                    errors.append(u"Email already exists in our system")
                    taskbar = setup_taskbar(request)
                    return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   Notifications=taskbar[1],
                                   needs_to_be_viewed=taskbar[2],
                                   user_type=taskbar[0]
                                   ),
                              context_instance=RequestContext(request))
                return HttpResponseRedirect('/HealthNet/register_nurse/')
            if request.session['registration_type'] == 'Doctor':
                try:
                    user.save()
                except IntegrityError:
                    errors = uf.errors.setdefault("email", ErrorList())
                    errors.append(u"Email already exists in our system")
                    taskbar = setup_taskbar(request)
                    return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   Notifications=taskbar[1],
                                   needs_to_be_viewed=taskbar[2],
                                   user_type=taskbar[0]
                                   ),
                              context_instance=RequestContext(request))
                return HttpResponseRedirect('/HealthNet/register_doctor/')
            if request.session['registration_type'] == 'Administrator':
                try:
                    user.save()
                except IntegrityError:
                    errors = uf.errors.setdefault("email", ErrorList())
                    errors.append(u"Email already exists in our system")
                    taskbar = setup_taskbar(request)
                    return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   Notifications=taskbar[1],
                                   needs_to_be_viewed=taskbar[2],
                                   user_type=taskbar[0]
                                   ),
                              context_instance=RequestContext(request))
                return HttpResponseRedirect('/HealthNet/register_admin/')
    else:
        uf = MyRegistrationForm(prefix='user')

    taskbar = setup_taskbar(request)
    return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   Notifications=taskbar[1],
                                   needs_to_be_viewed=taskbar[2],
                                   user_type=taskbar[0]
                                   ),
                              context_instance=RequestContext(request))


def register_doctor_user(request):
    """
    View controlling Health Administrator user registration of doctors
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        uf = MyRegistrationForm(request.POST, prefix='user')
        if uf.is_valid():
            user = uf.save(commit=False)
            user.username = user.email
            request.session['registrant_username'] = user.username
            request.session['admin_registration'] = False
            try:
                user.save()
            except IntegrityError:
                errors = uf.errors.setdefault("email", ErrorList())
                errors.append(u"Email already exists in our system")
                return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   ),
                              context_instance=RequestContext(request))
            return HttpResponseRedirect('/HealthNet/register_doctor/')

    else:
        uf = MyRegistrationForm(prefix='user')

    return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   ),
                              context_instance=RequestContext(request))


def register_nurse_user(request):
    """
    View controlling Health Administrator user registration of nurses
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        uf = MyRegistrationForm(request.POST, prefix='user')
        if uf.is_valid():
            user = uf.save(commit=False)
            user.username = user.email
            request.session['registrant_username'] = user.username
            request.session['admin_registration'] = False
            try:
                user.save()
            except IntegrityError:
                errors = uf.errors.setdefault("email", ErrorList())
                errors.append(u"Email already exists in our system")
                return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   ),
                              context_instance=RequestContext(request))
            return HttpResponseRedirect('/HealthNet/register_nurse/')
    else:
        uf = MyRegistrationForm(prefix='user')

    return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   ),
                              context_instance=RequestContext(request))


def register_admin_user(request):
    """
    View controlling Health Administrator user registration of admins
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        uf = MyRegistrationForm(request.POST, prefix='user')
        if uf.is_valid():
            user = uf.save(commit=False)
            user.username = user.email
            request.session['registrant_username'] = user.username
            request.session['admin_registration'] = False
            try:
                user.save()
            except IntegrityError:
                errors = uf.errors.setdefault("email", ErrorList())
                errors.append(u"Email already exists in our system")
                return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   ),
                              context_instance=RequestContext(request))
            return HttpResponseRedirect('/HealthNet/register_admin/')
    else:
        uf = MyRegistrationForm(prefix='user')

    return render_to_response('HealthNet/doc_nurse_admin_registration/admin_register_user.html',
                              dict(userform=uf,
                                   current_user=request.user,
                                   ),
                              context_instance=RequestContext(request))


def register_nurse(request):
    """
    View controlling registration of nurses
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session or request.session['admin_registration'] == False:
        user = request.user
        if user.is_authenticated() or request.session['admin_registration'] == False:
            if request.method == 'POST':
                npf = MyNurseForm(request.POST, prefix='nurseprofile')
                if npf.is_valid():
                    nurse_user = User.objects.get(username=request.session['registrant_username'])
                    nurseprofile = npf.save(commit=False)
                    nurseprofile.user = nurse_user

                    if request.session['admin_registration']:
                        if request.session['admin_registration'] is True:
                            nurseprofile.validated = True
                            nurseprofile.save()
                            LogEntry.objects.log_action(
                                user_id=request.user.id,
                                content_type_id=ContentType.objects.get_for_model(request.user).pk,
                                object_id=request.user.id,
                                object_repr=request.user.username,
                                action_flag=CHANGE,
                                change_message="Nurse, " + nurseprofile.user.first_name + " " + nurseprofile.user.last_name + ", has been registered by " + request.user.first_name + " " + request.user.last_name + ".")

                    else:
                        nurseprofile.save()

                        for each in HealthAdmin.objects.filter(hospital=nurseprofile.hospital):
                            notification = Notification(content="New not validated nurse: " +
                                                                nurseprofile.user.first_name + " " +
                                                                nurseprofile.user.last_name, viewed=False,
                                                        recipient=each.user.email, author=nurseprofile.user.email,
                                                        sent_time=datetime.now().time(),
                                                        sent_date=datetime.now().date())
                            notification.save()
                    if user.is_authenticated():
                        return HttpResponseRedirect('/HealthNet/admin_registration_success/')
                    else:
                        return HttpResponseRedirect('/HealthNet/staff_registration_success/')
            else:
                npf = MyNurseForm(prefix='nurseprofile')

            return render(request, 'HealthNet/doc_nurse_admin_registration/register_nurse.html',
                          dict(nurseprofileform=npf,
                               current_user=request.user,))
    return HttpResponseRedirect('/HealthNet/not_logged_in')


def register_doctor(request):
    """
    View controlling registration of doctors
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session or request.session['admin_registration'] == False:
        user = request.user
        if user.is_authenticated() or request.session['admin_registration'] == False:
            if request.method == 'POST':
                dpf = MyDoctorForm(request.POST, prefix='doctorprofile')
                if dpf.is_valid():
                    doctor_user = User.objects.get(username=request.session['registrant_username'])
                    doctorprofile = dpf.save(commit=False)
                    doctorprofile.user = doctor_user
                    if request.session['admin_registration']:
                        if request.session['admin_registration'] is True:
                            doctorprofile.validated = True
                            doctorprofile.save()
                            LogEntry.objects.log_action(
                                user_id=request.user.id,
                                content_type_id=ContentType.objects.get_for_model(request.user).pk,
                                object_id=request.user.id,
                                object_repr=request.user.username,
                                action_flag=CHANGE,
                                change_message="Doctor, " + doctorprofile.user.first_name + " " + doctorprofile.user.last_name + ", has been registered by " + request.user.first_name + " " + request.user.last_name + ".")

                    else:
                        doctorprofile.save()
                    for each in request.POST.getlist('doctorprofile-hospitals'):
                        hospital = Hospital.objects.get(pk=each)
                        doctorprofile.hospitals.add(hospital)
                        for admin in HealthAdmin.objects.filter(hospital=hospital):
                            notification = Notification(content="New not validated doctor: " +
                                                                doctorprofile.user.first_name + " "
                                                                + doctorprofile.user.last_name, viewed=False,
                                                        recipient=admin.user.email, author=doctorprofile.user.email,
                                                        sent_time=datetime.now().time(),
                                                        sent_date=datetime.now().date())
                            notification.save()
                    if user.is_authenticated():
                        return HttpResponseRedirect('/HealthNet/admin_registration_success/')
                    else:
                        return HttpResponseRedirect('/HealthNet/staff_registration_success/')
            else:
                dpf = MyDoctorForm(prefix='doctorprofile')
            return render(request, 'HealthNet/doc_nurse_admin_registration/register_doctor.html',
                          dict(doctorprofileform=dpf,
                               current_user=request.user,
                               ))
    return HttpResponseRedirect('/HealthNet/not_logged_in')


def register_admin(request):
    """
    View controlling registration of admins
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session or request.session['admin_registration'] == False:
        user = request.user
        if user.is_authenticated() or request.session['admin_registration'] == False:
            if request.method == 'POST':
                apf = MyHealthAdminForm(request.POST)
                if apf.is_valid():
                    admin_user = User.objects.get(username=request.session['registrant_username'])
                    adminprofile = apf.save(commit=False)
                    adminprofile.user = admin_user
                    if request.session['admin_registration']:
                        if request.session['admin_registration'] is True:
                            adminprofile.validated = True
                            adminprofile.save()
                            LogEntry.objects.log_action(
                                user_id=request.user.id,
                                content_type_id=ContentType.objects.get_for_model(request.user).pk,
                                object_id=request.user.id,
                                object_repr=request.user.username,
                                action_flag=CHANGE,
                                change_message="Admin, " + adminprofile.user.first_name + " " + adminprofile.user.last_name + ", has been registered by " + request.user.first_name + " " + request.user.last_name + ".")

                    else:
                        adminprofile.save()

                        for each in HealthAdmin.objects.filter(hospital=adminprofile.hospital):
                            notification = Notification(content="New not validated health admin: " +
                                                                adminprofile.user.first_name + " " +
                                                                adminprofile.user.last_name, viewed=False,
                                                        recipient=each.user.email, author=adminprofile.user.email,
                                                        sent_time=datetime.now().time(),
                                                        sent_date=datetime.now().date())
                            notification.save()
                    if user.is_authenticated():
                        return HttpResponseRedirect('/HealthNet/admin_registration_success/')
                    else:
                        return HttpResponseRedirect('/HealthNet/staff_registration_success/')
            else:
                apf = MyHealthAdminForm()
            return render(request, 'HealthNet/doc_nurse_admin_registration/register_admin.html',
                          dict(adminprofileform=apf,
                               current_user=request.user,
                               ))
    return HttpResponseRedirect('/HealthNet/not_logged_in')


def admin_registration_success(request):
    """
    View controlling HealthNet Administrator success of registering a new staff member
    :param request: Basic Server Access Info
    """
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/doc_nurse_admin_registration/admin_registration_success.html',
                  {'current_user': request.user,
                   'Notifications': taskbar[1],
                   'needs_to_be_viewed': taskbar[2],
                   'user_type': taskbar[0]})


def staff_registration_success(request):
    """
    View controlling success of registering a new staff member
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/doc_nurse_admin_registration/staff_registration_success.html',
                  {'current_user': request.user})

# #####################################################################################################################
# ########################################## Admin Registration of Users End ##########################################
# #####################################################################################################################
