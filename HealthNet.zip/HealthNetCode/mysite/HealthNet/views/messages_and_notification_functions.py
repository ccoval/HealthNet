from django.forms.utils import ErrorList
from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import setup_taskbar
from ..forms import MyMessageForm, MyMessageReplyForm
from ..models import *


# #####################################################################################################################
# ########################################## Messages/Notifications Functions Begin ###################################
# #####################################################################################################################


def messages(request, user_id):
    """
    View controlling the viewing of all messages by all users
    :param request: Basic Server Access Info
    :param user_id: User ID of User's Messages to be Viewed
    """
    try:
        user = User.objects.get(pk=user_id)
        msgs = Message.objects.filter(recipient=user.email)
    except User.DoesNotExist:
        raise Http404("This HealthNet User does not exist")
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/messages/messages.html', {'User': user,
                                                                'Messages': msgs,
                                                                'current_user': request.user,
                                                                'Notifications': taskbar[1],
                                                                'needs_to_be_viewed': taskbar[2],
                                                                'user_type': taskbar[0]})


def new_message(request):
    """
    View controlling the creation of messages by all users
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            if request.method == 'POST':
                mf = MyMessageForm(request.POST, prefix='message')
                if mf.is_valid():
                    message = mf.save(commit=False)
                    try:
                        recipient = User.objects.get(email=message.recipient)
                    except User.DoesNotExist:
                        errors = mf.errors.setdefault("recipient", ErrorList())
                        errors.append(u"The recipient you entered does not match any existing users in our system.")
                        taskbar = setup_taskbar(request)
                        return render(request, 'HealthNet/messages/new_message.html',
                                      dict(messageform=mf,
                                           User=user,
                                           current_user=request.user,
                                           Notifications=taskbar[1],
                                           needs_to_be_viewed=taskbar[2],
                                           user_type=taskbar[0]))
                    try:
                        if user.patient is not None:
                            try:
                                if recipient.patient is not None:
                                    pass
                            except ObjectDoesNotExist:
                                errors = mf.errors.setdefault("recipient", ErrorList())
                                errors.append(
                                    u"As a patient you do not have permission to send a message to HealthNet"
                                    u" Staff Member unless you are replying to a received message.")
                                taskbar = setup_taskbar(request)
                                return render(request, 'HealthNet/messages/new_message.html',
                                              dict(messageform=mf,
                                                   User=user,
                                                   current_user=request.user,
                                                   Notifications=taskbar[1],
                                                   needs_to_be_viewed=taskbar[2],
                                                   user_type=taskbar[0]))

                    except ObjectDoesNotExist:
                        pass
                    message.sent_time = datetime.now().time()
                    message.sent_date = datetime.now().date()
                    message.author = user.email
                    message.save()
                    return HttpResponseRedirect('/HealthNet/messages/' + str(user.id) + '/')
            else:
                mf = MyMessageForm(prefix='message')
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/messages/new_message.html',
                          dict(messageform=mf,
                               User=user,
                               current_user=request.user,
                               Notifications=taskbar[1],
                               needs_to_be_viewed=taskbar[2],
                               user_type=taskbar[0]))
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def show_message(request, message_id):
    """
    View controlling the viewing of an individual message by all users
    :param request: Basic Server Access Info
    :param message_id: ID of Message to be Viewed
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                message = Message.objects.get(pk=message_id)
                message.viewed = True
                message.save()
            except ObjectDoesNotExist:
                raise Http404("This Message does not exist")
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/messages/show_message.html', {'Message': message, 'User': user,
                                                                            'current_user': request.user,
                                                                            'Notifications': taskbar[1],
                                                                            'needs_to_be_viewed': taskbar[2],
                                                                            'user_type': taskbar[0]})
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def reply_message(request, message_id):
    """
    View controlling the replies of an individual message by all users
    :param request: Basic Server Access Info
    :param message_id: ID of Message to be Replied to
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            if request.method == 'POST':
                mrf = MyMessageReplyForm(request.POST, prefix='messagereply')
                if mrf.is_valid():
                    reply_msg = mrf.save(commit=False)
                    try:
                        message = Message.objects.get(pk=message_id)
                        recipient = message.author
                    except ObjectDoesNotExist:
                        errors = mrf.errors.setdefault("subject", ErrorList())
                        errors.append(u"The message you are trying to reply to no longer seems to exist.")
                        taskbar = setup_taskbar(request)
                        return render(request, 'HealthNet/messages/message_reply.html',
                                      dict(messagereplyform=mrf,
                                           User=user,
                                           current_user=request.user,
                                           Notifications=taskbar[1],
                                           needs_to_be_viewed=taskbar[2],
                                           user_type=taskbar[0]))
                    reply_msg.recipient = recipient
                    reply_msg.author = user.email
                    reply_msg.sent_time = datetime.now().time()
                    reply_msg.sent_date = datetime.now().date()
                    reply_msg.save()
                    return HttpResponseRedirect('/HealthNet/messages/' + str(user.id) + '/')
            else:
                mrf = MyMessageReplyForm(prefix='message')
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/messages/message_reply.html',
                          dict(messagereplyform=mrf,
                               User=user,
                               current_user=request.user,
                               Notifications=taskbar[1],
                               needs_to_be_viewed=taskbar[2],
                               user_type=taskbar[0]))
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def delete_message(request, message_id):
    """
    View controlling the deletion of an individual message by all users
    :param request: Basic Server Access Info
    :param message_id: ID of Message to be Deleted
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                message = Message.objects.get(pk=message_id)
                message.delete()
            except ObjectDoesNotExist:
                raise Http404("This message does not exist")
            return HttpResponseRedirect('/HealthNet/messages/' + str(user.id) + '/')
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def notifications(request, user_id):
    """
    View controlling the viewing of all notifications by all users
    :param request: Basic Server Access Info
    :param user_id: User ID of User's Notifications to be Viewed
    """
    try:
        user = User.objects.get(pk=user_id)
        nfns = Notification.objects.filter(recipient=user.email)
        for x in nfns:
            x.viewed = True
            x.save()
    except User.DoesNotExist:
        raise Http404("This HealthNet User does not exist")
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/miscellaneous/notifications.html', {'User': user, 'Notifications': nfns,
                                                                          'current_user': request.user,
                                                                          'needs_to_be_viewed': taskbar[2],
                                                                          'user_type': taskbar[0]})


def delete_notification(request, notification_id):
    """
    View controlling the deletion of an individual notification by all users
    :param request: Basic Server Access Info
    :param notification_id: ID of Notification to be Deleted
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                notification = Notification.objects.get(pk=notification_id)
                notification.delete()
            except ObjectDoesNotExist:
                raise Http404("This notfication does not exist")
            return HttpResponseRedirect('/HealthNet/notifications/' + str(user.id) + '/')
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')

# #####################################################################################################################
# ########################################## Messages/Notifications Functions End #####################################
# #####################################################################################################################
