from datetime import datetime

from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ObjectDoesNotExist
from django.forms.utils import ErrorList
from django.http import HttpResponseRedirect
from django.shortcuts import render
from datetime import datetime, timedelta

from ..models import Notification
from ..forms import MyAppointmentForm, MyPatientAppointmentForm, MyDoctorAppointmentForm
from .miscellaneous_functions import setup_taskbar


# #####################################################################################################################
# ########################################## Appointment Creation Begin ###############################################
# #####################################################################################################################


def create_appointment(request):
    """
    Master View controlling creation of appointments
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                if request.user.patient is not None:
                    return new_appointment_patient(request)
            except ObjectDoesNotExist:
                pass
            try:
                if request.user.doctor is not None:
                    return new_appointment_doctor(request)
            except ObjectDoesNotExist:
                pass
            try:
                if request.user.nurse is not None:
                    return new_appointment_nurse(request)
            except ObjectDoesNotExist:
                pass
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def new_appointment_patient(request):
    """
    View controlling creation of appointments by patients
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        apt = MyPatientAppointmentForm(request.POST, prefix='appointment')
        if apt.is_valid():
            patient = request.user.patient
            appointmnt = apt.save(commit=False)
            appointmnt.patient = patient
            appointmnt.hospital = patient.hospital
            appointmnt.doctor = patient.primaryDoc
            end = datetime.combine(appointmnt.start_date, appointmnt.start_time) + timedelta(minutes = 30)
            appointmnt.end_date = end.date()
            appointmnt.end_time = end.time()



            if appointmnt.is_correct():
                if appointmnt.is_available():
                    appointmnt.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(appointmnt).pk,
                        object_id=appointmnt.id,
                        object_repr=appointmnt.title,
                        action_flag=CHANGE,
                        change_message="Appointment for " + appointmnt.title + " has been created for " +
                                       appointmnt.patient.user.username + ".")
                    notification = Notification(content=patient.fullName + " has scheduled an appointment for " +
                                                    str(appointmnt.start_date) + " at " + str(appointmnt.start_time),
                                                    viewed=False, recipient=patient.primaryDoc.user.email,
                                                    author=request.user.email, sent_time=datetime.now().time(),
                                                    sent_date=datetime.now().date())
                    notification.save()
                    return HttpResponseRedirect('/HealthNet/calendar/')
                else:
                    errors = apt.errors.setdefault("start_time", ErrorList())
                    errors.append(u"This Appointment Time is Unavailable")
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/appointments/newAppointment.html', dict(aptform=apt,
                                                                                              current_user=request.user,
                                                                                              Notifications=taskbar[1],
                                                                                              needs_to_be_viewed=taskbar[2],
                                                                                              user_type=taskbar[0]))

            else:
                errors = apt.errors.setdefault("start_time", ErrorList())
                errors.append(u"This Appointment is Invalid")
                taskbar = setup_taskbar(request)
                return render(request, 'HealthNet/appointments/newAppointment.html', dict(aptform=apt,
                                                                                          current_user=request.user,
                                                                                          Notifications=taskbar[1],
                                                                                          needs_to_be_viewed=taskbar[2],
                                                                                          user_type=taskbar[0]))

    else:
        apt = MyPatientAppointmentForm(prefix='appointment')
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/appointments/newAppointment.html', dict(aptform=apt,
                                                                              current_user=request.user,
                                                                              Notifications=taskbar[1],
                                                                              needs_to_be_viewed=taskbar[2],
                                                                              user_type=taskbar[0]))


def new_appointment_doctor(request):
    """
    View controlling creation of appointments by doctors
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        apt = MyDoctorAppointmentForm(request.POST, prefix='appointment')
        if apt.is_valid():
            doctor = request.user.doctor
            appointmnt = apt.save(commit=False)
            appointmnt.doctor = doctor
            if appointmnt.is_correct():
                if appointmnt.is_available():
                    appointmnt.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(appointmnt).pk,
                        object_id=appointmnt.id,
                        object_repr=appointmnt.title,
                        action_flag=CHANGE,
                        change_message="Appointment for " + appointmnt.title + " has been created for " +
                                       appointmnt.patient.user.username + ".")
                    notification = Notification(content=doctor.user.first_name + " " + doctor.user.last_name + " has scheduled an appointment for " +
                                                    str(appointmnt.start_date) + " at " + str(appointmnt.start_time),
                                                    viewed=False, recipient=appointmnt.patient.user.email,
                                                    author=request.user.email, sent_time=datetime.now().time(),
                                                    sent_date=datetime.now().date())
                    notification.save()
                    return HttpResponseRedirect('/HealthNet/calendar/')
                else:
                    errors = apt.errors.setdefault("start_time", ErrorList())
                    errors.append(u"This Appointment Time is Unavailable")
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/appointments/newAppointment.html', dict(aptform=apt,
                                                                                              current_user=request.user,
                                                                                              Notifications=taskbar[1],
                                                                                              needs_to_be_viewed=taskbar[2],
                                                                                              user_type=taskbar[0]))
            else:
                errors = apt.errors.setdefault("start_time", ErrorList())
                errors.append(u"This Appointment is Invalid")
                taskbar = setup_taskbar(request)
                return render(request, 'HealthNet/appointments/newAppointment.html', dict(aptform=apt,
                                                                                          current_user=request.user,
                                                                                          Notifications=taskbar[1],
                                                                                          needs_to_be_viewed=taskbar[2],
                                                                                          user_type=taskbar[0]))
    else:
        apt = MyDoctorAppointmentForm(prefix='appointment')
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/appointments/newAppointment.html', dict(aptform=apt,
                                                                              current_user=request.user,
                                                                              Notifications=taskbar[1],
                                                                              needs_to_be_viewed=taskbar[2],
                                                                              user_type=taskbar[0]))


def new_appointment_nurse(request):
    """
    View controlling creation of appointments by nurses
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        apt = MyAppointmentForm(request.POST, prefix='appointment')
        if apt.is_valid():
            appointmnt = apt.save(commit=False)
            if appointmnt.is_correct():
                if appointmnt.is_available():
                    appointmnt = apt.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(appointmnt).pk,
                        object_id=appointmnt.id,
                        object_repr=appointmnt.title,
                        action_flag=CHANGE,
                        change_message="Appointment for " + appointmnt.title + " has been created for " +
                                       appointmnt.patient.user.username + ".")
                    return HttpResponseRedirect('/HealthNet/calendar/')

                else:
                    errors = apt.errors.setdefault("start_time", ErrorList())
                    errors.append(u"This Appointment is Unavailable")
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/appointments/newAppointment.html', dict(aptform=apt,
                                                                                              current_user=request.user,
                                                                                              Notifications=taskbar[1],
                                                                                              needs_to_be_viewed=taskbar[2],
                                                                                              user_type=taskbar[0]))

            else:
                errors = apt.errors.setdefault("start_time", ErrorList())
                errors.append(u"This Appointment is Invalid")
                taskbar = setup_taskbar(request)
                return render(request, 'HealthNet/appointments/newAppointment.html', dict(aptform=apt,
                                                                                          current_user=request.user,
                                                                                          Notifications=taskbar[1],
                                                                                          needs_to_be_viewed=taskbar[2],
                                                                                          user_type=taskbar[0]))
    else:
        apt = MyAppointmentForm(prefix='appointment')
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/appointments/newAppointment.html', dict(aptform=apt,
                                                                              current_user=request.user,
                                                                              Notifications=taskbar[1],
                                                                              needs_to_be_viewed=taskbar[2],
                                                                              user_type=taskbar[0]))


# #####################################################################################################################
# ########################################## Appointment Creation End #################################################
# #####################################################################################################################
