from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponseRedirect
from .miscellaneous_functions import user_not_authorized

# #####################################################################################################################
# ########################################## Master View Template Begin ###############################################
# #####################################################################################################################


def master_view_template(request):
    """
    Master View template to determine type of user
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


# #####################################################################################################################
# ########################################## Master View Template End #################################################
# #####################################################################################################################
