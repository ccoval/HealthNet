from django.core.exceptions import ObjectDoesNotExist
from django.forms.forms import ErrorList
from django.http import HttpResponseRedirect
from django.shortcuts import render, render_to_response
from django.template import RequestContext

from ..forms import MyHospitalForm
from ..models import Notification

# #####################################################################################################################
# ########################################## Site Miscellaneous Functions Begin #######################################
# #####################################################################################################################


def index(request):
    """
    View controlling the landing page
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/miscellaneous/landing_page.html')


def user_not_authorized(request):
    """
    View controlling the place you are brought if your user type is unauthorized to access a particular feature
    :param request: Basic Server Access Info
    """
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/miscellaneous/user_not_authorized.html', {'current_user': request.user,
                                                                                'Notifications': taskbar[1],
                                                                                'needs_to_be_viewed': taskbar[2],
                                                                                'user_type': taskbar[0]})


def not_validated(request):
    """
    View controlling the place you are brought if your account has not yet been validated
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/miscellaneous/not_validated.html')


def wrong_user_or_password(request):
    """
    View controlling the place you are brought if you enter the wrong username or password
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/miscellaneous/wrong_user_or_password.html')


def not_logged_in(request):
    """
    View controlling the place you are brought if you try to access the site features without logging in
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/miscellaneous/not_logged_in.html')


def leaving(request):
    """
    View controlling the place you are brought if you are leaving the site
    :param request: Basic Server Access Info
    """
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/miscellaneous/leaving.html', {'current_user': request.user,
                                                                    'Notifications': taskbar[1],
                                                                    'needs_to_be_viewed': taskbar[2],
                                                                    'user_type': taskbar[0]})


def insurance_prompt(request):
    """
    View controlling the place you are brought to ask if you have insurance
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/miscellaneous/insurance_prompt.html')


def sorry(request):
    """
    View controlling the place you are brought if you say you don't have insurance and want to register as a patient
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/miscellaneous/sorry.html')


def reg_landing(request):
    """
    View controlling the place you are brought if you go to register a new account
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/miscellaneous/registration_landing.html')


def features(request):
    """
    View controlling the features list on our landing page
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/miscellaneous/features.html')


def is_patient(request):
    """
    Returns whether or not the current user is a patient.
    :param request:
    :return: Boolean
    """
    try:
        if request.user.patient is not None:
            return True
    except ObjectDoesNotExist:
        pass
    return False


def is_doctor(request):
    """
    Returns whether or not the current user is a doctor.
    :param request:
    :return: Boolean
    """
    try:
        if request.user.doctor is not None:
            return True
    except ObjectDoesNotExist:
        pass
    return False


def is_nurse(request):
    """
    Returns whether or not the current user is a nurse.
    :param request:
    :return: Boolean
    """
    try:
        if request.user.nurse is not None:
            return True
    except ObjectDoesNotExist:
        pass
    return False


def is_health_admin(request):
    """
    Returns whether or not the current user is a healthAdmin.
    :param request:
    :return: Boolean
    """
    try:
        if request.user.healthAdmin is not None:
            return True
    except ObjectDoesNotExist:
        pass
    return False


def is_sys_admin(request):
    """
    Returns whether or not the current user is a sysAdmin.
    :param request:
    :return: Boolean
    """
    try:
        if request.user.sysAdmin is not None:
            return True
    except ObjectDoesNotExist:
        pass
    return False


def setup_taskbar(request):
    """
    Returns the setup for the navigation bar on any view it is used in
    :param request: Basic Server Access Info
    :return: User Type, Notifications of that User, and If Any Notifications Haven't Been Seen
    """
    usr_typ = ""
    if is_patient(request):
        usr_typ = "patient"
    if is_nurse(request):
        usr_typ = "nurse"
    if is_doctor(request):
        usr_typ = "doctor"
    if is_health_admin(request):
        usr_typ = "healthAdmin"
    if is_sys_admin(request):
        usr_typ = "sysAdmin"

    nfns = None
    need_to_be_viewed = False
    try:
        noti_user = request.user
        nfns = Notification.objects.filter(recipient=noti_user.email)
        nfns = nfns[:5]
        for x in nfns:
            if x.viewed is False:
                need_to_be_viewed = True
    except ObjectDoesNotExist:
        pass
    return usr_typ, nfns, need_to_be_viewed


def add_hospital(request):
    """
    View controlling the registration of new hospitals into the system
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        hf = MyHospitalForm(request.POST)
        if hf.is_valid():
            hospital = hf.save(commit=False)
            if hospital.is_in_system():
                errors = hf.errors.setdefault("name", ErrorList())
                errors.append(u"That hospital name already exists in our system")
                taskbar = setup_taskbar(request)
                return render_to_response('HealthNet/miscellaneous/add_hospital.html',
                                          dict(hospitalform=hf,
                                               Notifications=taskbar[1],
                                               needs_to_be_viewed=taskbar[2],
                                               user_type=taskbar[0]),
                                          context_instance=RequestContext(request))
            else:
                hospital.save()
            return HttpResponseRedirect('/HealthNet/home/')
    else:
        hf = MyHospitalForm()

    taskbar = setup_taskbar(request)
    return render_to_response('HealthNet/miscellaneous/add_hospital.html',
                              dict(hospitalform=hf,
                                   Notifications=taskbar[1],
                                   needs_to_be_viewed=taskbar[2],
                                   user_type=taskbar[0]
                                   ),
                              context_instance=RequestContext(request))

# #####################################################################################################################
# ########################################## Site Miscellaneous Functions End #########################################
# #####################################################################################################################
