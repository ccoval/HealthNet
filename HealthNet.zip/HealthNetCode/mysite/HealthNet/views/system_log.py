from django.contrib.admin.models import LogEntry
from django.contrib.contenttypes.models import ContentType
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template.context_processors import csrf
from django.template.defaultfilters import register

from .miscellaneous_functions import user_not_authorized, setup_taskbar
from ..forms import LogForm
from ..models import *


# #####################################################################################################################
# ########################################## System Log Begin #########################################################
# #####################################################################################################################

def log(request):
    """
    View controlling the view of all system activity in the system log
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    args = {}
                    args.update(csrf(request))
                    args['log'] = LogEntry.objects.all()
                    args['current_user'] = request.user
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    if request.method == 'POST':
                        print("post")
                        form = LogForm(request.POST)
                        if form.is_valid():
                            print("valid")
                            cd = form.cleaned_data
                            start_time = cd['start_time']
                            start_date = cd['start_date']
                            end_date = cd['end_date']
                            end_time = cd['end_time']
                            start = datetime.combine(start_date, start_time)
                            end = datetime.combine(end_date, end_time)
                            args['start'] = start
                            args['end'] = end
                            if args['end'] < args['start']:
                                args['form'] = LogForm()
                                args['incorrect'] = True
                                return render(request, "HealthNet/system_log/log.html", args)
                            args['log'] = LogEntry.objects.filter(action_time__range=(args['start'], args['end']))
                            args['form'] = LogForm()
                            return render(request, "HealthNet/system_log/log.html", args)
                    else:
                        form = LogForm()
                    args['log'] = LogEntry.objects.all()
                    args['form'] = form
                    return render(request, 'HealthNet/system_log/log.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    args = {}
                    args.update(csrf(request))
                    args['log'] = LogEntry.objects.all()
                    args['current_user'] = request.user
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    if request.method == 'POST':
                        print("post")
                        form = LogForm(request.POST)
                        if form.is_valid():
                            print("valid")
                            cd = form.cleaned_data
                            start_time = cd['start_time']
                            start_date = cd['start_date']
                            end_date = cd['end_date']
                            end_time = cd['end_time']
                            print(cd['start_time'])
                            print(cd['start_date'])
                            print(cd['end_date'])
                            print(cd['end_time'])
                            start = datetime.combine(start_date, start_time)
                            end = datetime.combine(end_date, end_time)
                            args['start'] = start
                            args['end'] = end
                            if args['end'] < args['start']:
                                print("bad")
                                return HttpResponseRedirect('/HealthNet/system_log/log.html/')
                            args['log'] = LogEntry.objects.filter(action_time__range=(args['start'], args['end']))
                            args['form'] = LogForm()
                            return render(request, "HealthNet/system_log/log.html", args)
                    else:
                        form = LogForm()
                    args['log'] = LogEntry.objects.all()
                    args['form'] = form
                    return render(request, 'HealthNet/system_log/log.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


"""
def log(request):
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    args = {}
                    args.update(csrf(request))
                    args['log'] = LogEntry.objects.all()
                    args['current_user'] = request.user
                    return render(request, 'HealthNet/system_log/log.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    args = {}
                    args.update(csrf(request))
                    args['log'] = LogEntry.objects.all()
                    args['current_user'] = request.user
                    return render(request, 'HealthNet/system_log/log.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('http://localhost:8000/HealthNet/not_logged_in/')
"""


@register.filter
def which_table(value):
    return ContentType.objects.get(id=value.content_type_id).name


@register.filter
def to_entry_log_flag(value):
    if value.action_flag == 1:
        return " was added to "
    if value.action_flag == 2:
        return " was changed in "
    if value.action_flag == 3:
        return " was deleted from"


"""
def time_constricted_log(request):
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    args = {}
                    args.update(csrf(request))
                    if request.method == 'GET':
                        args['current_user'] = request.user
                        taskbar = setup_taskbar(request)
                        args['Notifications'] = taskbar[1]
                        args['needs_to_be_viewed'] = taskbar[2]
                        args['user_type'] = taskbar[0]
                        return render(request, 'HealthNet/system_log/log.html', args)
                    else:
                        args['start_time'] = request.POST.get('start_time', '')
                        start_time = request.POST.get('start_time', '')
                        args['start_date'] = request.POST.get('start_date', '')
                        start_date = request.POST.get('start_date', '')
                        args['end_time'] = request.POST.get('end_time', '')
                        end_time = request.POST.get('end_time', '')
                        args['end_date'] = request.POST.get('end_date', '')
                        end_date = request.POST.get('end_date', '')
                        print(start_time + " " + start_date + " " + end_time + " " + end_date)
                        if (len(args['start_date']) == 0) or (len(args['start_time']) == 0) or \
                                (len(args['end_date']) == 0) or (
                                    len(
                                        args['end_time']) == 0):
                            return HttpResponseRedirect('/HealthNet/log_alt/')
                        args['start'] = datetime(int(start_date[0:4]), int(start_date[5:7]), int(start_date[8:10]),
                                                 int(start_time[0:2]), int(start_time[3:5]))
                        args['end'] = datetime(int(end_date[0:4]), int(end_date[5:7]), int(end_date[8:10]),
                            #return HttpResponseRedirect('http://localhost:8000/HealthNet/log_alt/')
                        args['start'] = datetime(int(start_date[4:9]), int(start_date[0:2]), int(start_date[3:5]),
                                                 int(start_time[0:2]), int(start_time[3:5]), 0)
                        args['end'] = datetime(int(end_date[4:9]), int(end_date[0:2]), int(end_date[3:5]),
                                               int(end_time[0:2]),
                                               int(end_time[3:5]), 0)
                        if args['end'] < args['start']:
                            return HttpResponseRedirect('/HealthNet/log_alt/')
                        args['log'] = LogEntry.objects.filter(action_time__range=(args['start'], args['end']))
                        args['current_user'] = request.user
                        taskbar = setup_taskbar(request)
                        args['Notifications'] = taskbar[1]
                        args['needs_to_be_viewed'] = taskbar[2]
                        args['user_type'] = taskbar[0]
                        return render(request, 'HealthNet/system_log/time_constricted_log.html', args)
                        # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    args = {}
                    args.update(csrf(request))
                    if request.method == 'GET':
                        args['current_user'] = request.user
                        taskbar = setup_taskbar(request)
                        args['Notifications'] = taskbar[1]
                        args['needs_to_be_viewed'] = taskbar[2]
                        args['user_type'] = taskbar[0]
                        return render(request, 'HealthNet/system_log/log.html', args)
                    else:
                        args['start_time'] = request.POST.get('start_time', '')
                        start_time = request.POST.get('start_time', '')
                        args['start_date'] = request.POST.get('start_date', '')
                        start_date = request.POST.get('start_date', '')
                        args['end_time'] = request.POST.get('end_time', '')
                        end_time = request.POST.get('end_time', '')
                        args['end_date'] = request.POST.get('end_date', '')
                        end_date = request.POST.get('end_date', '')
                        if (len(args['start_date']) == 0) or (len(args['start_time']) == 0) or \
                                (len(args['end_date']) == 0) or (
                                    len(
                                        args['end_time']) == 0):
                            return HttpResponseRedirect('/HealthNet/log_alt/')
                        args['start'] = datetime(int(start_date[0:4]), int(start_date[5:7]), int(start_date[8:10]),
                                                 int(start_time[0:2]), int(start_time[3:5]))
                        args['end'] = datetime(int(end_date[0:4]), int(end_date[5:7]), int(end_date[8:10]),
                                               int(end_time[0:2]),
                                               int(end_time[3:5]))
                        if args['end'] < args['start']:
                            return HttpResponseRedirect('/HealthNet/log_alt/')
                        args['log'] = LogEntry.objects.filter(action_time__range=(args['start'], args['end']))
                        args['current_user'] = request.user
                        taskbar = setup_taskbar(request)
                        args['Notifications'] = taskbar[1]
                        args['needs_to_be_viewed'] = taskbar[2]
                        args['user_type'] = taskbar[0]
                        return render(request, 'HealthNet/system_log/time_constricted_log.html', args)
                        # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')

"""


def log_alt(request):
    """
    View controlling the view of all system activity in the system log when you have entered a
    wrong time input for the search
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    args = {}
                    args.update(csrf(request))
                    args['log'] = LogEntry.objects.all()
                    args['current_user'] = request.user
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    return render(request, 'HealthNet/system_log/log_alt.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    args = {}
                    args.update(csrf(request))
                    args['log'] = LogEntry.objects.all()
                    args['current_user'] = request.user
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    return render(request, 'HealthNet/system_log/log_alt.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


@register.filter
def toString(value):
    return value.__str__()


@register.filter
def change_message(value):
    return value.change_message


def datesAreValid(start, end):
    if end < start:
        return False
    else:
        return True

# #####################################################################################################################
# ########################################## System Log End ###########################################################
# #####################################################################################################################
