from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import user_not_authorized, setup_taskbar
from ..forms import MyImageForm
from ..models import *


# #####################################################################################################################
# ##################################### Uploading Images to Patient MedRecords Begin ##################################
# #####################################################################################################################


def upload_medical_image(request, user_id):
    """
    Master View controlling uploading of a medical image by doctors
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to Upload Image To
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return doctor_upload_medical_image(request, user_id)
            except ObjectDoesNotExist:
                pass
        return user_not_authorized(request)
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def doctor_upload_medical_image(request, user_id):
    """
    View controlling the actual server access of uploading medical images by doctors
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to Upload Image To
    """
    usr = User.objects.get(pk=user_id)
    medinfo = usr.patient.medicalRecord
    if request.method == 'POST':
        img = MyImageForm(request.POST, request.FILES, prefix='image')
        if img.is_valid():
            image = img.save(commit=False)
            image.medicalInfo = medinfo
            image.date = datetime.now()
            image.save()
            if image.release is True:
                notification = Notification(content="Dr. " + request.user.first_name + " " + request.user.last_name +
                                                    " has released a new image on your medical record: " + image.title,
                                            viewed=False,
                                            recipient=usr.email, author=request.user.email,
                                            sent_time=datetime.now().time(),
                                            sent_date=datetime.now().date())
                notification.save()
            LogEntry.objects.log_action(
                content_type_id=ContentType.objects.get_for_model(image).pk,
                object_id=image.id,
                object_repr=image.title,
                user_id=request.user.id,
                action_flag=CHANGE,
                change_message="Medical Image: " + image.title + ", was uploaded by Dr. " +
                               request.user.first_name + " " + request.user.last_name)
            return HttpResponseRedirect('/HealthNet/view_medical_images/' + user_id + '/')
    else:
        img = MyImageForm(prefix='image')
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/medical_images/doctor_upload_medical_image.html',
                  dict(imgform=img,
                       patient=usr,
                       current_user=request.user,
                       Notifications=taskbar[1],
                       needs_to_be_viewed=taskbar[2],
                       user_type=taskbar[0]))


def view_medical_images(request, user_id):
    """
    Master View controlling the viewing of Medical Images by users
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to be Viewed
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return standard_view_medical_images(request, user_id)
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return standard_view_medical_images(request, user_id)
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return standard_view_medical_images(request, user_id)
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def standard_view_medical_images(request, user_id):
    """
    View controlling the viewing of Medical Images by doctors and nurses
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to be Viewed
    """
    images = None
    try:
        user = User.objects.get(pk=user_id)
        try:
            patient = user.patient
            try:
                mr = patient.medicalRecord
                try:
                    images = mr.images.all().order_by('-date')
                except ObjectDoesNotExist:
                    pass
            except ObjectDoesNotExist:
                raise Http404("This HealthNet User does not have a Medical Record")
        except ObjectDoesNotExist:
            raise Http404("The HealthNet User you are looking for is not a Patient")
    except User.DoesNotExist:
        raise Http404("This HealthNet User does not exist")

    staff = False
    doctor = False

    try:
        if request.user.doctor is not None:
            staff = True
            doctor = True
    except ObjectDoesNotExist:
        pass

    try:
        if request.user.nurse is not None:
            staff = True
    except ObjectDoesNotExist:
        pass

    if images.count() == 0:
        none_text = "No Medical Images on File"
    else:
        none_text = ""

    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/medical_images/view_medical_images.html', {'patient': user,
                                                                                 'images': images,
                                                                                 'none': none_text,
                                                                                 'mr': mr,
                                                                                 'staff': staff,
                                                                                 'doctor': doctor,
                                                                                 'current_user': request.user,
                                                                                 'Notifications': taskbar[1],
                                                                                 'needs_to_be_viewed': taskbar[2],
                                                                                 'user_type': taskbar[0]})


def show_image(request, user_id, image_id, file_name):
    """
    View controlling the viewing of Medical Images by all users
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to be Viewed
    :param image_id: Image ID of Image to be Viewed
    :param file_name: File Name of Image Being Viewed
    """
    import os
    file = str(file_name)
    directory = os.getcwd()
    directory = directory.replace('\\', '/')
    file_path = 'file://' + directory + '/HealthNet/media/HealthNet/uploaded_files/' + file
    try:
        image = Image.objects.get(pk=image_id)
    except ObjectDoesNotExist:
        raise Http404("The Image you are looking for does not exist in the system.")
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/medical_images/show_image.html', dict(file_path=file_path,
                                                                            file_name=file,
                                                                            image=image,
                                                                            patient=user_id,
                                                                            current_user=request.user,
                                                                            Notifications=taskbar[1],
                                                                            needs_to_be_viewed=taskbar[2],
                                                                            user_type=taskbar[0]))


def release_image(request, user_id, image_id):
    """
    View controlling the releasing of Medical Images by doctors
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient
    :param image_id: Image ID of Image to be Released
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    image = Image.objects.get(pk=image_id)
                    image.release = True
                    image.save()
                    LogEntry.objects.log_action(
                        content_type_id=ContentType.objects.get_for_model(image).pk,
                        object_id=image.id,
                        object_repr=image.title,
                        user_id=request.user.id,
                        action_flag=CHANGE,
                        change_message="Medical Image: " + image.title + ", was released by Dr. " +
                                       request.user.first_name + " " + request.user.last_name)
                    notification = Notification(content="Dr. " + request.user.first_name + " " + request.user.last_name +
                                                    " has released a new image on your medical record: " + image.title,
                                            viewed=False,
                                            recipient=image.medicalInfo.patient.user.email, author=request.user.email,
                                            sent_time=datetime.now().time(),
                                            sent_date=datetime.now().date())
                    notification.save()
                    return HttpResponseRedirect('/HealthNet/view_medical_images/' + user_id + '/')
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


# #####################################################################################################################
# ##################################### Uploading Images to Patient MedRecords End ####################################
# #####################################################################################################################
