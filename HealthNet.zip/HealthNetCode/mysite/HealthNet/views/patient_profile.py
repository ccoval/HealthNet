from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render

from ..models import *
from .miscellaneous_functions import setup_taskbar

# #####################################################################################################################
# ########################################## Patient Profile Begin ####################################################
# #####################################################################################################################


def profile(request, user_id):
    """
    View controlling the view of a patient profile by that patient
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to View
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                user = User.objects.get(pk=user_id)
            except User.DoesNotExist:
                raise Http404("This HealthNet User does not exist")
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/patient_profile/patient_profile.html', {'User': user,
                                                                                      'current_user': request.user,
                                                                                      'Notifications': taskbar[1],
                                                                                      'needs_to_be_viewed': taskbar[2],
                                                                                      'user_type': taskbar[0]})
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


# #####################################################################################################################
# ########################################## Patient Profile End ######################################################
# #####################################################################################################################
