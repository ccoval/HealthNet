from django.contrib.admin.models import CHANGE, LogEntry
from django.contrib.contenttypes.models import ContentType
from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import setup_taskbar
from ..forms import MyPrescriptionForm
from ..models import *


# #####################################################################################################################
# ########################################## Prescriptions Begin ######################################################
# #####################################################################################################################


def prescriptions(request, user_id):
    """
    View controlling the view of all prescriptions related to a specific patient
    :param request: Basic Server Access Info
    :param user_id: ID of Patient to View Prescriptions of
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            user = User.objects.get(pk=user_id)
            medinfo = user.patient.medicalRecord
            prescript = Prescription.objects.filter(medicalInfo=medinfo).order_by('datePrescribed')
            is_nurse = False
            try:
                if request.user.doctor is not None:
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/prescriptions/prescriptions_doctor.html',
                                  {'User': user,
                                   'Prescriptions': prescript,
                                   'current_user': request.user,
                                   'Notifications': taskbar[1],
                                   'needs_to_be_viewed': taskbar[2],
                                   'user_type': taskbar[0]})
            except ObjectDoesNotExist:
                pass
            try:
                if request.user.nurse is not None:
                    is_nurse = True
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/prescriptions/prescriptions.html',
                                  {'User': user, 'Prescriptions': prescript, 'current_user': request.user,
                                   "is_nurse": is_nurse,
                                   'Notifications': taskbar[1],
                                   'needs_to_be_viewed': taskbar[2],
                                   'user_type': taskbar[0]})
            except ObjectDoesNotExist:
                pass
            try:
                if request.user.patient is not None:
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/prescriptions/prescriptions.html',
                                  {'User': user, 'Prescriptions': prescript, 'current_user': request.user,
                                   "is_nurse": is_nurse,
                                   'Notifications': taskbar[1],
                                   'needs_to_be_viewed': taskbar[2],
                                   'user_type': taskbar[0]})
            except ObjectDoesNotExist:
                pass

            return HttpResponseRedirect('/HealthNet/user_not_authorized/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def create_prescription(request, user_id):
    """
    View controlling the creation of a prescription for a specific patient
    :param request: Basic Server Access Info
    :param user_id: ID of Patient to Create a Prescription for
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                if request.user.doctor is not None:
                    user = User.objects.get(pk=user_id)
                    medinfo = user.patient.medicalRecord
                    if request.method == 'POST':
                        pre = MyPrescriptionForm(request.POST, prefix='prescription')
                        if pre.is_valid():
                            prescription = pre.save(commit=False)
                            prescription.medicalInfo = medinfo
                            prescription.datePrescribed = datetime.today()
                            prescription.save()
                            notification = Notification(
                                content="You have a new prescription for " + prescription.medicine,
                                viewed=False,
                                recipient=prescription.medicalInfo.patient.user.email, author=request.user.email,
                                sent_time=datetime.now().time(),
                                sent_date=datetime.now().date())
                            notification.save()
                            LogEntry.objects.log_action(
                                user_id=request.user.id,
                                content_type_id=ContentType.objects.get_for_model(request.user).pk,
                                object_id=request.user.id,
                                object_repr=request.user.username,
                                action_flag=CHANGE,
                                change_message=prescription.medicine + " was prescribed to " + prescription.medicalInfo.patient.fullName + " by " + prescription.medicalInfo.patient.primaryDoc.user.first_name + " " + prescription.medicalInfo.patient.primaryDoc.user.last_name + ".")
                            return HttpResponseRedirect('/HealthNet/prescriptions/' + user_id + '/')

                    else:
                        pre = MyPrescriptionForm(prefix='prescription')
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/prescriptions/create_prescription.html',
                                  dict(aptform=pre,
                                       current_user=request.user,
                                       patient=user_id,
                                       Notifications=taskbar[1],
                                       needs_to_be_viewed=taskbar[2],
                                       user_type=taskbar[0]))

            except ObjectDoesNotExist:
                pass

            return HttpResponseRedirect('/HealthNet/user_not_authorized/')
    else:
        return HttpResponseRedirect('/HealthNet/user_not_authorized/')


def cancel_prescription_check(request, user_id, prescription_id):
    """
    View controlling the cancellation check of a prescription
    :param request: Basic Server Access Info
    :param user_id: ID of Patient to Cancel a Prescription for
    :param prescription_id: ID of Prescription to Cancel
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                if request.user.doctor is not None:
                    try:
                        prescription = Prescription.objects.get(pk=prescription_id)
                        iden = prescription_id
                    except ObjectDoesNotExist:
                        raise Http404("This Prescription does not exist")
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/prescriptions/cancel_prescription_check.html',
                                  {'Prescription': prescription,
                                   'ID': iden,
                                   'current_user': request.user,
                                   'patient': user_id,
                                   'Notifications': taskbar[1],
                                   'needs_to_be_viewed': taskbar[2],
                                   'user_type': taskbar[0]})

            except ObjectDoesNotExist:
                pass

            return HttpResponseRedirect('/HealthNet/user_not_authorized/')
    else:
        return HttpResponseRedirect('/HealthNet/user_not_authorized/')


def cancel_prescription(request, user_id, prescription_id):
    """
    View controlling the actual cancellation of a prescription for a specific patient
    :param request: Basic Server Access Info
    :param user_id: ID of Patient to Cancel a Prescription for
    :param prescription_id: ID of Prescription to Cancel
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                if request.user.doctor is not None:
                    prescription = Prescription.objects.get(pk=prescription_id)
                    Prescription.objects.get(pk=prescription_id).delete()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(request.user).pk,
                        object_id=request.user.id,
                        object_repr=request.user.username,
                        action_flag=CHANGE,
                        change_message=prescription.medicine + " was cancelled for " + prescription.medicalInfo.patient.fullName + " by " + prescription.medicalInfo.patient.primaryDoc.user.first_name + " " + prescription.medicalInfo.patient.primaryDoc.user.last_name + ".")
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/prescriptions/cancel_prescription.html',
                                  {'current_user': request.user,
                                   'patient': user_id,
                                   'Notifications': taskbar[1],
                                   'needs_to_be_viewed': taskbar[2],
                                   'user_type': taskbar[0]})

            except ObjectDoesNotExist:
                pass

            return HttpResponseRedirect('/HealthNet/user_not_authorized/')
    else:
        return HttpResponseRedirect('/HealthNet/user_not_authorized/')

# #####################################################################################################################
# ########################################## Prescriptions End ########################################################
# #####################################################################################################################
