from django.contrib import auth
from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponseRedirect
from django.shortcuts import render, render_to_response
from django.template.context_processors import csrf

from .home_pages import home


# #####################################################################################################################
# ########################################## Login Begin ##############################################################
# #####################################################################################################################


def login(request):
    """
    View controlling login page
    :param request: Basic Server Access Info
    """
    arg = {}
    arg.update(csrf(request))
    return render_to_response('HealthNet/miscellaneous/login.html', arg)


def auth_view(request):
    """
    View controlling actual login of a user to redirect to their home page
    :param request: Basic Server Access Info
    """
    try:
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            iden = user.id
            request.session['user_id'] = iden
            # here
            LogEntry.objects.log_action(
                user_id=request.user.id,
                content_type_id=ContentType.objects.get_for_model(request.user).pk,
                object_id=request.user.id,
                object_repr=request.user.username,
                action_flag=CHANGE,
                change_message="User, " + request.user.username + ", logged in.")
            return home(request)

        return render(request, 'HealthNet/miscellaneous/wrong_user_or_password.html')

    except ValueError:
        return render(request, 'HealthNet/miscellaneous/wrong_user_or_password.html')


def logout(request):
    """
    View controlling actual logout of a user to redirect to the goodbye page
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            LogEntry.objects.log_action(
                user_id=request.user.id,
                content_type_id=ContentType.objects.get_for_model(request.user).pk,
                object_id=request.user.id,
                object_repr=request.user.username,
                action_flag=CHANGE,
                change_message="User, " + request.user.username + ", logged out.")
            auth.logout(request)
            request.session['user_id'] = 'Not logged in'
            return render_to_response('HealthNet/miscellaneous/goodbye.html', request.session)
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


# #####################################################################################################################
# ########################################## Login End ################################################################
# #####################################################################################################################
