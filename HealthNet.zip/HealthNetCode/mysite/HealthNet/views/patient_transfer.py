from django.contrib.admin.models import CHANGE, LogEntry
from django.contrib.contenttypes.models import ContentType
from django.forms import ModelChoiceField
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import user_not_authorized, setup_taskbar
from ..forms import MyPatientTransferForm
from ..models import *


# #####################################################################################################################
# ########################################## Patient Transfer Start ###################################################
# #####################################################################################################################


def admin_transferable(request):
    """
    View controlling the view of all patients to transfer by an admin
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    args = dict()
                    args['patients'] = Patient.objects.all()
                    args['patients'] = args['patients'].order_by("fullName")
                    args['current_user'] = request.user
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    return render(request, 'HealthNet/patient_transfer/admin_transferable.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    args = dict()
                    args['patients'] = Patient.objects.all()
                    args['patients'] = args['patients'].order_by("fullName")
                    args['current_user'] = request.user
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    return render(request, 'HealthNet/patient_transfer/admin_transferable.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def admin_transferring(request, patient_id):
    """
    View controlling the transfer of a patient by an admin
    :param request: Basic Server Access Info
    :param patient_id: ID of Patient to Transfer
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)

                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    if request.method == "POST":
                        frm = MyPatientTransferForm(data=request.POST, prefix='MyPatientTransferForm')
                        if frm.is_valid():
                            patient = Patient.objects.get(id=patient_id)
                            firstHospital = patient.hospital
                            transfer = frm.save(commit=False)
                            patient.hospital = transfer.hospital
                            patient.save()
                            LogEntry.objects.log_action(
                                user_id=request.user.id,
                                content_type_id=ContentType.objects.get_for_model(request.user).pk,
                                object_id=request.user.id,
                                object_repr=request.user.username,
                                action_flag=CHANGE,
                                change_message=patient.fullName + " was transferred to " + str(transfer.hospital) + " by " + user.first_name + " " + user.last_name + ".")
                            return HttpResponseRedirect('/HealthNet/admin_transferable/')
                    else:
                        frm = MyPatientTransferForm(prefix='MyPatientTransferForm')
                        patient = Patient.objects.get(id=patient_id)
                        queryset = Hospital.objects.all()
                        hospital = patient.hospital

                        queryset = queryset.exclude(pk=hospital.pk)
                        frm.fields['hospital'] = ModelChoiceField(queryset=queryset, empty_label=None)
                        if Hospital.objects.all().exclude(pk=hospital.pk).count() == 0:
                            no_hospitals = True
                            taskbar = setup_taskbar(request)
                            return render(request, 'HealthNet/patient_transfer/admin_transferring.html',
                                          dict(no_hospitals=no_hospitals,
                                               frm=frm,
                                               hospital=hospital,
                                               patient=patient,
                                               current_user=request.user,
                                               Notifications=taskbar[1],
                                               needs_to_be_viewed=taskbar[2],
                                               user_type=taskbar[0]))

                        taskbar = setup_taskbar(request)
                        return render(request, 'HealthNet/patient_transfer/admin_transferring.html',
                                      dict(frm=frm,
                                           hospital=hospital,
                                           patient=patient,
                                           current_user=request.user,
                                           Notifications=taskbar[1],
                                           needs_to_be_viewed=taskbar[2],
                                           user_type=taskbar[0]))
                    return HttpResponseRedirect('/HealthNet/admin_transferable/')
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    if request.method == "POST":
                        frm = MyPatientTransferForm(data=request.POST, prefix='MyPatientTransferForm')
                        if frm.is_valid():
                            patient = Patient.objects.get(id=patient_id)
                            transfer = frm.save(commit=False)
                            patient.hospital = transfer.hospital
                            patient.save()
                            return HttpResponseRedirect('/HealthNet/admin_transferable/')
                    else:
                        frm = MyPatientTransferForm(prefix='MyPatientTransferForm')
                        patient = Patient.objects.get(id=patient_id)
                        hospital = patient.hospital
                        queryset = Hospital.objects.filter()
                        queryset = queryset.exclude(pk=hospital.pk)
                        frm.fields['hospital'] = ModelChoiceField(queryset=queryset, empty_label=None)
                        taskbar = setup_taskbar(request)
                        return render(request, 'HealthNet/patient_transfer/admin_transferring.html',
                                      dict(frm=frm,
                                           hospital=hospital,
                                           patient=patient,
                                           current_user=request.user,
                                           Notifications=taskbar[1],
                                           needs_to_be_viewed=taskbar[2],
                                           user_type=taskbar[0]))
                    return HttpResponseRedirect('/HealthNet/admin_transferable/')
            except ObjectDoesNotExist:
                pass
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def doctor_receivable(request):
    """
    View controlling the view of all patients to receive by a doctor
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    args = dict()
                    args['patients'] = Patient.objects.filter(primaryDoc=user.doctor)
                    args['patients'] = args['patients'].order_by("fullName")
                    args['current_user'] = request.user
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    return render(request, 'HealthNet/patient_transfer/doctor_receivable.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def doctor_receiving(request, patient_id):
    """
    View controlling the transfer of a patient by a doctor
    :param request: Basic Server Access Info
    :param patient_id: ID of Patient to Transfer
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    #  args = dict()
                    if request.method == "POST":
                        frm = MyPatientTransferForm(data=request.POST, prefix='MyPatientTransferForm')
                        if frm.is_valid():
                            patient = Patient.objects.get(id=patient_id)
                            transfer = frm.save(commit=False)
                            patient.hospital = transfer.hospital
                            patient.save()
                            return HttpResponseRedirect('/HealthNet/doctor_receivable/')
                    else:
                        frm = MyPatientTransferForm(prefix='MyPatientTransferForm')
                        patient = Patient.objects.get(id=patient_id)
                        hospital = patient.hospital
                        frm.fields['hospital'] = ModelChoiceField(
                            queryset=user.doctor.hospitals.exclude(pk=hospital.pk), empty_label=None)
                        if user.doctor.hospitals.exclude(pk=hospital.pk).count() == 0:
                            no_hospitals = True
                            taskbar = setup_taskbar(request)
                            return render(request, 'HealthNet/patient_transfer/doctor_receiving.html',
                                          dict(no_hospitals=no_hospitals,
                                               frm=frm,
                                               hospital=hospital,
                                               patient=patient,
                                               current_user=request.user,
                                               Notifications=taskbar[1],
                                               needs_to_be_viewed=taskbar[2],
                                               user_type=taskbar[0]))
                        taskbar = setup_taskbar(request)
                        return render(request, 'HealthNet/patient_transfer/doctor_receiving.html',
                                      dict(frm=frm,
                                           hospital=hospital,
                                           patient=patient,
                                           current_user=request.user,
                                           Notifications=taskbar[1],
                                           needs_to_be_viewed=taskbar[2],
                                           user_type=taskbar[0]))
                return HttpResponseRedirect('/HealthNet/doctor_receivable/')
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')

# #####################################################################################################################
# ########################################## Patient Transfer End #####################################################
# #####################################################################################################################
