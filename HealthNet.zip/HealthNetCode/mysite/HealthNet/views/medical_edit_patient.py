from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import user_not_authorized, setup_taskbar
from ..forms import MyMedicalRecordForm
from ..models import *


# #####################################################################################################################
# ########################################## Medical Edit Patient Begin ###############################################
# #####################################################################################################################


def medical_edit_patient_record(request, user_id):
    """
    Master View controlling access to patient medical records by doctors and nurses
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to Access
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return nurse_medical_edit_patient_record(request, user_id)
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return doctor_medical_edit_patient_record(request, user_id)
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def nurse_medical_edit_patient_record(request, user_id):
    """
    View controlling access to patient medical records by nurses
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to Access
    """
    try:
        patient = User.objects.get(pk=user_id)
    except User.DoesNotExist:
        raise Http404("This HealthNet User does not exist")
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/medical_edit_profile/nurse_medical_edit_patient_record.html',
                  {'User': patient,
                   'current_user': request.user,
                   'Notifications': taskbar[1],
                   'needs_to_be_viewed': taskbar[2],
                   'user_type': taskbar[0]})


def doctor_medical_edit_patient_record(request, user_id):
    """
    View controlling access to patient medical records by doctors
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to Access
    """
    try:
        patient = User.objects.get(pk=user_id)
        try:
            med_record = patient.patient.medicalRecord
        except ObjectDoesNotExist:
            raise Http404("This HealthNet User does not have a medical record")
    except User.DoesNotExist:
        raise Http404("This HealthNet User does not exist")
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/medical_edit_profile/doctor_medical_edit_patient_record.html',
                  {'User': patient,
                   'MedRecord': med_record,
                   'current_user': request.user,
                   'Notifications': taskbar[1],
                   'needs_to_be_viewed': taskbar[2],
                   'user_type': taskbar[0]})


def staff_modify_medical_record(request, user_id):
    """
    Master View controlling modification of a patient medical record by doctors and nurses
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to Modify
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return nurse_modify_medical_record(request, user_id)
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return doctor_modify_medical_record(request, user_id)
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def nurse_modify_medical_record(request, user_id):
    """
    View controlling modification of a patient medical record by nurses
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to Modify
    """
    patient = User.objects.get(id=user_id)
    oldmr = MedicalInfo.objects.get(id=patient.patient.medicalRecord.id)
    if request.method == 'POST':
        newmr = MyMedicalRecordForm(request.POST, instance=oldmr, prefix='medical_record')
        if newmr.is_valid():
            oldmr = newmr.save()
            LogEntry.objects.log_action(
                user_id=request.user.id,
                content_type_id=ContentType.objects.get_for_model(oldmr).pk,
                object_id=patient.patient.medicalRecord.id,
                object_repr=patient.first_name,
                action_flag=CHANGE, change_message="Medical Record of, " + patient.first_name + " " +
                                                   patient.last_name + ", was modified.")
            return HttpResponseRedirect(
                '/HealthNet/medical_edit_user/' + str(int(patient.id)) + '/')
    else:
        newmr = MyMedicalRecordForm(instance=oldmr, prefix='medical_record')
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/medical_edit_profile/staff_modify_medical_record.html',
                  dict(medicalrecordform=newmr,
                       patient=patient,
                       current_user=request.user,
                       Notifications=taskbar[1],
                       needs_to_be_viewed=taskbar[2],
                       user_type=taskbar[0]))


def doctor_modify_medical_record(request, user_id):
    """
    View controlling modification of a patient medical record by doctors
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient to Modify
    """
    patient = User.objects.get(id=user_id)
    oldmr = MedicalInfo.objects.get(id=patient.patient.medicalRecord.id)
    if request.method == 'POST':
        newmr = MyMedicalRecordForm(request.POST, instance=oldmr, prefix='medical_record')
        if newmr.is_valid():
            oldmr = newmr.save()
            LogEntry.objects.log_action(
                user_id=request.user.id,
                content_type_id=ContentType.objects.get_for_model(oldmr).pk,
                object_id=patient.patient.medicalRecord.id,
                object_repr=patient.first_name,
                action_flag=CHANGE, change_message="Medical Record of, " + patient.first_name + " " +
                                                   patient.last_name + ", was modified.")
            return HttpResponseRedirect(
                '/HealthNet/medical_edit_user/' + str(int(patient.id)) + '/')
    else:
        newmr = MyMedicalRecordForm(instance=oldmr, prefix='medical_record')
    taskbar = setup_taskbar(request)
    return render(request, 'HealthNet/medical_edit_profile/staff_modify_medical_record.html',
                  dict(medicalrecordform=newmr,
                       patient=patient,
                       current_user=request.user,
                       Notifications=taskbar[1],
                       needs_to_be_viewed=taskbar[2],
                       user_type=taskbar[0]))


# #####################################################################################################################
# ########################################## Medical Edit Patient End #################################################
# #####################################################################################################################
