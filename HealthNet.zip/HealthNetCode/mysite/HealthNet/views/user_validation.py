from django.contrib.admin.models import CHANGE, LogEntry
from django.contrib.contenttypes.models import ContentType
from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import user_not_authorized, setup_taskbar
from ..models import *


# #####################################################################################################################
# ########################################## User Validation Begin ####################################################
# #####################################################################################################################


def is_validated_user(request):
    """
    Master View controlling the redirect if you are not a validated user yet
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return True
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    if user.nurse.validated is True:
                        return True
                    return HttpResponseRedirect('/HealthNet/not_validated/')
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    if user.doctor.validated is True:
                        return True
                    return HttpResponseRedirect('/HealthNet/not_validated/')
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    if user.healthAdmin.validated is True:
                        return True
                    return HttpResponseRedirect('/HealthNet/not_validated/')
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return True
            except ObjectDoesNotExist:
                pass
            return False
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def unvalidated_users(request):
    """
    View controlling the view of all users waiting to be validated by an admin
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session and is_validated_user(request):
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    args = dict()
                    args['unvalidated_doctors'] = Doctor.objects.filter(validated=False,
                                                                        hospitals=request.user.healthAdmin.hospital)
                    args['unvalidated_nurses'] = Nurse.objects.filter(validated=False,
                                                                      hospital=request.user.healthAdmin.hospital)
                    args['unvalidated_admins'] = HealthAdmin.objects.filter(validated=False,
                                                                            hospital=request.user.healthAdmin.hospital)
                    args['current_user'] = request.user
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    return render(request, 'HealthNet/doc_nurse_admin_registration/unvalidated_users.html', args)
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def validate_doctor(request, doctor_id):
    """
    View controlling the validation of a new doctor
    :param request: Basic Server Access Info
    :param doctor_id: ID of Doctor to be Validated
    """
    if 'user_id' in request.session and is_validated_user(request):
        user = request.user
        if user.is_authenticated():
            try:
                if user.healthAdmin is not None:
                    try:
                        doctor = Doctor.objects.get(pk=doctor_id)
                    except ObjectDoesNotExist:
                        raise Http404("This doctor does not exist")
                    doctor.validated = True
                    doctor.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(request.user).pk,
                        object_id=request.user.id,
                        object_repr=request.user.username,
                        action_flag=CHANGE,
                        change_message="Doctor, " + doctor.user.first_name + " " + doctor.user.last_name + ", has been verified by " + request.user.first_name + " " + request.user.last_name + ".")
                    return unvalidated_users(request)
            except ObjectDoesNotExist:
                return user_not_authorized(request)
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def validate_nurse(request, nurse_id):
    """
    View controlling the validation of a new nurse
    :param request: Basic Server Access Info
    :param nurse_id: ID of Nurse to be Validated
    """
    if 'user_id' in request.session and is_validated_user(request):
        user = request.user
        if user.is_authenticated():
            try:
                if user.healthAdmin is not None:
                    try:
                        nurse = Nurse.objects.get(pk=nurse_id)
                    except ObjectDoesNotExist:
                        raise Http404("This nurse does not exist")
                    nurse.validated = True
                    nurse.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(request.user).pk,
                        object_id=request.user.id,
                        object_repr=request.user.username,
                        action_flag=CHANGE,
                        change_message="Nurse, " + nurse.user.first_name + " " + nurse.user.last_name + ", has been verified by " + request.user.first_name + " " + request.user.last_name + ".")

                    return unvalidated_users(request)
            except ObjectDoesNotExist:
                return user_not_authorized(request)
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def validate_admin(request, admin_id):
    """
    View controlling the validation of a new admin
    :param request: Basic Server Access Info
    :param admin_id: ID of Admin to be Validated
    """
    if 'user_id' in request.session and is_validated_user(request):
        user = request.user
        if user.is_authenticated():
            try:
                if user.healthAdmin is not None:
                    try:
                        admin = HealthAdmin.objects.get(pk=admin_id)
                    except ObjectDoesNotExist:
                        raise Http404("This admin does not exist")
                    admin.validated = True
                    admin.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(request.user).pk,
                        object_id=request.user.id,
                        object_repr=request.user.username,
                        action_flag=CHANGE,
                        change_message="Administrator, " + admin.user.first_name + " " + admin.user.last_name + ", has been verified by " + request.user.first_name + " " + request.user.last_name + ".")

                    return unvalidated_users(request)
            except ObjectDoesNotExist:
                return user_not_authorized(request)
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')

# #####################################################################################################################
# ########################################## User Validation Begin End ################################################
# #####################################################################################################################
