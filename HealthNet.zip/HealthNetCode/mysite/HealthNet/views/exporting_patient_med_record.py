from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponseRedirect
from .miscellaneous_functions import user_not_authorized
from .miscellaneous_functions import setup_taskbar
from django.http import Http404
from ..models import User
from django.shortcuts import render

# #####################################################################################################################
# ##################################### Exporting Patient Medical Record Begin ########################################
# #####################################################################################################################


def export_medical_record(request, user_id):
    """
    Master View controlling exporting of patient medical record
    :param request: Basic Server Access Info
    :param user_id: User Id of Patient to Export Info of
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                if user.patient is not None:
                    return export(request, user_id)
            except ObjectDoesNotExist:
                pass
        else:
            return user_not_authorized(request)
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def export(request, user_id):
    """
    View controlling the place you are brought if you are exporting a medical record
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient
    """
    try:
        user = User.objects.get(pk=user_id)
        taskbar = setup_taskbar(request)
        images = None
        tsts = None
        prescriptions = None
        try:
            patient = user.patient
            try:
                mr = patient.medicalRecord
                try:
                    images = mr.images.all().order_by('-date')
                except ObjectDoesNotExist:
                    pass
            except ObjectDoesNotExist:
                raise Http404("This HealthNet User does not have a Medical Record")
        except ObjectDoesNotExist:
            raise Http404("The HealthNet User you are looking for is not a Patient")
        try:
            patient = user.patient
            try:
                mr = patient.medicalRecord
                try:
                    tsts = mr.tests.all().filter(hasResults=True)
                except ObjectDoesNotExist:
                    pass
            except ObjectDoesNotExist:
                raise Http404("This HealthNet User does not have a Medical Record")
        except ObjectDoesNotExist:
            raise Http404("The HealthNet User you are looking for is not a Patient")
        try:
            patient = user.patient
            try:
                mr = patient.medicalRecord
                try:
                    prescriptions = mr.prescriptions.all().order_by('-datePrescribed')
                except ObjectDoesNotExist:
                    pass
            except ObjectDoesNotExist:
                raise Http404("This HealthNet User does not have a Medical Record")
        except ObjectDoesNotExist:
            raise Http404("The HealthNet User you are looking for is not a Patient")
        return render(request, 'HealthNet/exporting_information/print_view.html', {'User': user,
                                                                                   'current_user': request.user,
                                                                                   'Notifications': taskbar[1],
                                                                                   'needs_to_be_viewed': taskbar[2],
                                                                                   'user_type': taskbar[0],
                                                                                   'images': images,
                                                                                   'tests': tsts,
                                                                                   'prescriptions': prescriptions})
    except User.DoesNotExist:
        raise Http404("This HealthNet User does not exist")


def privacy_warning(request, user_id):
    """
    View controlling the place you are brought if you are about to export a medical record, a privacy warning
    :param request: Basic Server Access Info
    :param user_id: User ID of Patient
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                if user.patient is not None:
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/exporting_information/privacy_warning.html',
                                  {'current_user': request.user,
                                   'Notifications': taskbar[1],
                                   'needs_to_be_viewed': taskbar[2],
                                   'user_type': taskbar[0],
                                   'User': user_id})
            except ObjectDoesNotExist:
                pass
        else:
            return user_not_authorized(request)
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')

# #####################################################################################################################
# ##################################### Exporting Patient Medical Record End ##########################################
# #####################################################################################################################
