from django.http import HttpResponseRedirect
from django.shortcuts import render, render_to_response
from django.template.context_processors import csrf

from .miscellaneous_functions import user_not_authorized, setup_taskbar
from ..models import *


# #####################################################################################################################
# ########################################## Patient Searching Begin ##################################################
# #####################################################################################################################


def my_patient_list(request):
    """
    Master View controlling the view of a list of patients
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return nurse_patient_list(request)
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return doctor_patient_list(request)
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def nurse_patient_list(request):
    """
    View controlling the view of a list of patients at a nurse's hospital
    :param request: Basic Server Access Info
    """
    try:
        args = {}
        args.update(csrf(request))
        args['Patients'] = User.objects.get(pk=request.user.id).nurse.hospital.patients.all().order_by("fullName")
        args['current_user'] = request.user
        taskbar = setup_taskbar(request)
        args['Notifications'] = taskbar[1]
        args['needs_to_be_viewed'] = taskbar[2]
        args['user_type'] = taskbar[0]
        return render(request, 'HealthNet/patient_list_searching/nurse_patient_list.html', args)
    except ObjectDoesNotExist:
        args = {}
        args.update(csrf(request))
        args['Patients'] = "This Hospital currently has no Patients"
        args['current_user'] = request.user
        taskbar = setup_taskbar(request)
        args['Notifications'] = taskbar[1]
        args['needs_to_be_viewed'] = taskbar[2]
        args['user_type'] = taskbar[0]
        return render(request, 'HealthNet/patient_list_searching/nurse_patient_list.html', args)


def doctor_patient_list(request):
    """
    View controlling the view of a list of patients registered to a doctor
    :param request: Basic Server Access Info
    """
    try:
        args = {}
        args.update(csrf(request))
        args['Patients'] = User.objects.get(pk=request.user.id).doctor.patients.all().order_by("fullName")
        args['current_user'] = request.user
        taskbar = setup_taskbar(request)
        args['Notifications'] = taskbar[1]
        args['needs_to_be_viewed'] = taskbar[2]
        args['user_type'] = taskbar[0]
        return render(request, 'HealthNet/patient_list_searching/doctor_patient_list.html', args)
    except ObjectDoesNotExist:
        args = {}
        args.update(csrf(request))
        args['Patients'] = "You currently have no Patients"
        args['current_user'] = request.user
        taskbar = setup_taskbar(request)
        args['Notifications'] = taskbar[1]
        args['needs_to_be_viewed'] = taskbar[2]
        args['user_type'] = taskbar[0]
        return render(request, 'HealthNet/patient_list_searching/doctor_patient_list.html', args)


def doctor_patient_search(request):
    """
    View controlling the port over to the javascript to search a patient list of a doctor
    :param request: Basic Server Access Info
    """
    if request.method == "POST":
        search_patient = request.POST.get('search_patient', False)
    else:
        search_patient = ''

    patients = User.objects.get(pk=request.user.id).doctor.patients.filter(
        fullName__contains=search_patient).order_by("fullName")
    taskbar = setup_taskbar(request)
    return render_to_response('HealthNet/patient_list_searching/patient_search.html', {'Patients': patients,
                                                                                       'current_user': request.user,
                                                                                       'Notifications': taskbar[1],
                                                                                       'needs_to_be_viewed': taskbar[2],
                                                                                       'user_type': taskbar[0]})


def nurse_patient_search(request):
    """
    View controlling the port over to the javascript to search a patient list of a nurse
    :param request: Basic Server Access Info
    """
    if request.method == "POST":
        search_patient = request.POST.get('search_patient', False)
    else:
        search_patient = ''

    patients = User.objects.get(pk=request.user.id).nurse.hospital.patients.filter(
        fullName__contains=search_patient).order_by("fullName")
    taskbar = setup_taskbar(request)
    return render_to_response('HealthNet/patient_list_searching/patient_search.html', {'Patients': patients,
                                                                                       'current_user': request.user,
                                                                                       'Notifications': taskbar[1],
                                                                                       'needs_to_be_viewed': taskbar[2],
                                                                                       'user_type': taskbar[0]})


# #####################################################################################################################
# ########################################## Patient Searching End ####################################################
# #####################################################################################################################
