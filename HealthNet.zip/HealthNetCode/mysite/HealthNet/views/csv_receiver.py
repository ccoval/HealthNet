from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponseRedirect
from django.shortcuts import render
import csv
from django.forms.utils import ErrorList

from ..models import *
from ..forms import MyCSVForm
from .miscellaneous_functions import user_not_authorized, setup_taskbar


def csv_input(request):
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return csv_import(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return csv_import(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def csv_import(request):
    args = dict()
    taskbar = setup_taskbar(request)
    args['current_user'] = request.user
    args['Notifications'] = taskbar[1]
    args['needs_to_be_viewed'] = taskbar[2]
    args['user_type'] = taskbar[0]
    if request.method == "POST":
        form = MyCSVForm(request.POST, request.FILES, prefix='form')
        if form.is_valid():
            fl = form.save(commit=False)
            fl.save()
            import os
            file = str(fl.file)
            directory = os.getcwd()
            directory = directory.replace('\\', '/')
            file_path = directory + '/HealthNet/media/HealthNet/uploaded_files/' + file
            try:
                read_file(file_path)
            except:
                form = MyCSVForm(prefix='form')
                errors = form.errors.setdefault("file", ErrorList())
                errors.append(u"The provided .csv was in the wrong format.")
                args['form'] = form
                return render(request, 'HealthNet/csv_receiver/csv_receiver.html', args)

            args['form'] = MyCSVForm(prefix='form')
            args['success'] = 1
            return render(request, 'HealthNet/csv_receiver/csv_receiver.html', args)
        else:
            form = MyCSVForm(prefix='form')
            errors = form.errors.setdefault("file", ErrorList())
            errors.append(u"This File Type is Unaccepted, Must be a '.csv' file.")
            args['form'] = form
    else:
        args['form'] = MyCSVForm(prefix='form')
    return render(request, 'HealthNet/csv_receiver/csv_receiver.html', args)


def read_file(file):
    with open(file) as csv_file:
        reader = csv.reader(csv_file)
        rowNum = 0
        for line in reader:
            rowNum += 1
            emptiesExist = False
            counter = 0
            for each in line:
                if each == "":
                    break
                counter += 1
            line = line[:counter]
            for each in line:
                if each == "":
                    emptiesExist = True
                    break
            if not emptiesExist:
                if line[0] == "Hospital" and len(line) == 6:
                    name = line[1]
                    street = line[2]
                    city = line[3]
                    state = line[4]
                    zip = line[5]
                    hospitals = Hospital.objects.filter(name=name)
                    if hospitals.count() == 0:
                        Hospital.objects.create(name=name, address=street, city=city, zipcode=zip, state=state)
                elif line[0] == "Hospital Admin" and len(line) == 6:
                    email = line[1]
                    first = line[2]
                    last = line[3]
                    password = line[4]
                    hospitalName = line[5]
                    if User.objects.filter(email=email, username=email).count() == 0:
                        usr = User.objects.create_user(email, email, password, first_name=first, last_name=last)
                        if Hospital.objects.filter(name=hospitalName).exists():
                            hospital = Hospital.objects.get(name=hospitalName)
                            HealthAdmin.objects.create(hospital=hospital, user=usr, validated=True)
                elif line[0] == "Doctor" and len(line) == 7:
                    email = line[1]
                    first = line[2]
                    last = line[3]
                    password = line[4]
                    hospitalNames = line[5]
                    hospitalNames = hospitalNames.split("$")
                    verified = str(line[6])
                    if str(verified) == "TRUE" or str(verified) == "True":
                        verified = 1
                    elif str(verified) == "FALSE" or str(verified) == "False":
                        verified = 0
                    if User.objects.filter(email=email, username=email).count() > 0:
                        pass
                    else:
                        User.objects.create_user(email, email, password, first_name=first, last_name=last)
                        usrs = User.objects.all().filter(email=email, username=email)
                        usr_id = None
                        for each in usrs:
                            usr_id = each.id
                        usr = User.objects.get(pk=usr_id)
                        hospital_list = list()
                        for each in hospitalNames:
                            temp = Hospital.objects.filter(name=each)
                            if temp.count() == 1:
                                temp = Hospital.objects.get(name=each)
                                hospital_list.append(temp)
                        Doctor.objects.create(user=usr, validated=verified)
                        entry = Doctor.objects.get(user=usr, validated=verified)
                        entry.hospitals = hospital_list
                        entry.validated = verified
                        entry.save()
                elif line[0] == "Nurse" and len(line) == 7:
                    email = line[1]
                    first = line[2]
                    last = line[3]
                    password = line[4]
                    hospitalName = line[5]
                    verified = line[6]
                    if str(verified) == "TRUE" or str(verified) == "True":
                        verified = 1
                    elif str(verified) == "FALSE" or str(verified) == "False":
                        verified = 0
                    if User.objects.filter(email=email, username=email).count() == 0:
                        hospitals = Hospital.objects.filter(name=hospitalName)
                        if hospitals.count() is 1:
                            usr = User.objects.create_user(email, email, password)
                            usr.first_name = first
                            usr.last_name = last
                            usr.save()
                            hospital = Hospital.objects.get(name=hospitalName)
                            Nurse.objects.create(user=usr, hospital=hospital, validated=verified)
                elif line[0] == "Patient" and len(line) == 18:
                    email = line[1]
                    first = line[2]
                    last = line[3]
                    password = line[4]
                    sex = line[5]
                    insurance = line[6]
                    street = line[7]
                    city = line[8]
                    state = line[9]
                    zipcode = line[10]
                    phone = line[11]
                    hospital = line[12]
                    birth = line[13]
                    emergencyName = line[14]
                    emergencyEmail = line[15]
                    emergencyPhone = line[16]
                    doctor = line[17]
                    if User.objects.filter(email=email, username=email).count() == 0:
                        doctorExists = False
                        for each in Doctor.objects.all():
                            if str(each.user.email) == str(doctor) and str(each.user.username) == str(doctor):
                                doctorExists = True
                        if doctorExists and Hospital.objects.filter(name=hospital).count() == 1:
                            User.objects.create_user(email, email, password)
                            usr = User.objects.get(email=email, username=email)
                            usr.first_name = first
                            usr.last_name = last
                            usr.save()
                            doctor = Doctor.objects.get(user__email=doctor)
                            hospital = Hospital.objects.get(name=hospital)
                            Patient.objects.create(user=usr)
                            pt = Patient.objects.get(user=usr)
                            pt.sex = sex
                            pt.primaryDoc = doctor
                            pt.fullName = first + " " + last
                            pt.address = street
                            pt.city = city
                            pt.state = state
                            pt.zipcode = zipcode
                            pt.phoneNumber = phone
                            pt.birthDate = datetime.strptime(birth, "%Y-%m-%d")
                            pt.hospital = hospital
                            pt.admitted = False
                            pt.EmergContactName = emergencyName
                            pt.EmergContactEmail = emergencyEmail
                            pt.EmergContactPhoneNumber = emergencyPhone
                            pt.save()
                            MedicalInfo.objects.create(patient=pt)
                elif line[0] == "Prescription" and len(line) == 7:
                    name = line[1]
                    dosage = line[2]
                    instructions = line[3]
                    doctorEmail = line[4]
                    dateTime = line[5]
                    dateTime = dateTime.split(" ")
                    date = dateTime[0]
                    time = dateTime[1]
                    date = date.split("-")
                    time = time.split(":")
                    year = int(date[0])
                    month = int(date[1])
                    day = int(date[2])
                    hour = time[0]
                    minute = time[1]
                    patientEmail = line[6]
                    patient_usrs = User.objects.all().filter(email=patientEmail)
                    usr_id = None
                    for each in patient_usrs:
                        usr_id = each.id
                    userPatient = User.objects.get(pk=usr_id)
                    doctor_usrs = User.objects.all().filter(email=doctorEmail)
                    usr_id = None
                    for each in doctor_usrs:
                        usr_id = each.id
                    userDoctor = User.objects.get(pk=usr_id)
                    patient = Patient.objects.get(user=userPatient)
                    doctor = Doctor.objects.get(user=userDoctor)
                    medicalInfo = MedicalInfo.objects.get(patient=patient)
                    Prescription.objects.create(medicalInfo=medicalInfo, medicine=name, dosage=dosage,
                                                instructions=instructions,
                                                datePrescribed=datetime(year, month, day))

                elif (line[0] == "Appointment" or line[0] == "Appointments") and len(line) == 10:
                    description = line[1]
                    startDate = line[2]
                    startDate = datetime.strptime(startDate, "%Y-%m-%d")
                    endDate = line[3]
                    endDate = datetime.strptime(endDate, "%Y-%m-%d")
                    startTime = line[4]
                    startTime = datetime.strptime(startTime, "%H:%M")
                    endTime = line[5]
                    endTime = datetime.strptime(endTime, "%H:%M")
                    doctorEmail = line[6]
                    patientEmail = line[7]
                    hospital = line[8]
                    recurring = line[9]
                    if str(recurring) == "TRUE" or str(verified) == "True":
                        recurring = 1
                    elif str(recurring) == "FALSE" or str(verified) == "False":
                        recurring = 0
                    hospital = Hospital.objects.get(name=hospital)
                    userDoctor = User.objects.get(email=doctorEmail)
                    doctor = Doctor.objects.get(user=userDoctor)
                    userPatient = User.objects.get(email=patientEmail)
                    patient = Patient.objects.get(user=userPatient)
                    Appointment.objects.create(title=description[:20], description=description, doctor=doctor,
                                               start_date=startDate, start_time=startTime, end_date=endDate,
                                               end_time=endTime, hospital=hospital, patient=patient)
                elif line[0] == "Message" and len(line) == 7:
                    recipientEmail = line[1]
                    senderEmail = line[2]
                    viewed = line[3]
                    if str(viewed) == "TRUE" or str(viewed) == "True":
                        viewed = 1
                    elif str(viewed) == "FALSE" or str(viewed) == "False":
                        viewed = 0
                    subject = line[4]
                    message = line[5]
                    dateTime = line[6]  # hopefully YYYY-MM-DD HH:MM:SS
                    dateTime = dateTime.split()
                    date = str(dateTime[0])
                    time = str(dateTime[1])
                    date = date.split("-")
                    year = int(date[0])
                    month = int(date[1])
                    day = int(date[2])
                    date = datetime(year, month, day)
                    time = time.split(":")
                    hour = int(time[0])
                    minutes = int(time[1])
                    time = datetime(1, 1, 1, hour, minutes).time()
                    Message.objects.create(subject=subject, content=message, viewed=viewed,
                                           recipient=recipientEmail,
                                           author=senderEmail,
                                           sent_time=time,
                                           sent_date=date)
