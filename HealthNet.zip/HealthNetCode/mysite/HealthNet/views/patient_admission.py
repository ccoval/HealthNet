from datetime import datetime

from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import is_nurse, is_doctor, user_not_authorized, setup_taskbar
from ..forms import AdmissionForm
from ..models import HospitalStay, Patient, Message, Notification


# #####################################################################################################################
# ########################################## Patient Admission Begin ##################################################
# #####################################################################################################################


def admitted_patients(request):
    """
    View controlling the view of all patients admitted to the current user's hospital
    :param request: Basic Server Access Info
    """

    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    args = dict()
                    args['active_stays'] = HospitalStay.objects.filter(
                        active=True, hospital=user.nurse.hospital).order_by('patient__fullName')
                    args['admitted_patients'] = Patient.objects.filter(
                        admitted=True, hospital=user.nurse.hospital).order_by('fullName')
                    args['is_doctor'] = False
                    # if request.user.is_authenticated():
                    #    args['is_doctor'] = is_doctor(request)
                    args['is_nurse'] = True
                    args['current_user'] = request.user
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    return render(request, 'HealthNet/hospital_admission_discharge/admitted_patients.html', args)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    args = dict()
                    args['active_stays'] = HospitalStay.objects.filter(active=True).order_by('patient__fullName')

                    args['admitted_patients'] = Patient.objects.filter(admitted=True,
                                                                       primaryDoc=user.doctor).order_by('fullName')
                    args['is_doctor'] = True
                    args['current_user'] = request.user
                    if request.user.is_authenticated():
                        args['is_doctor'] = is_doctor(request)
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    return render(request, 'HealthNet/hospital_admission_discharge/admitted_patients.html', args)
                    # return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def notify_doctor(request, patient_id):
    """
    View controlling the notification by a nurse to a doctor that a patient needs to be discharged
    :param request: Basic Server Access Info
    :param patient_id: ID of Patient to Discharge
    """
    patient = Patient.objects.get(id=patient_id)
    doctor = patient.primaryDoc
    notification = Notification(content=patient.fullName + " is now ready to be discharged.",
                                viewed=False,
                                recipient=doctor.user.email, author=request.user.email, sent_time=datetime.now().time(),
                                sent_date=datetime.now().date())
    notification.save()
    return HttpResponseRedirect('/HealthNet/admitted_patients/')


def unadmitted_patients(request):
    """
    View controlling the view of all patients that are not currently admitted to the current user's hospital
    :param request: Basic Server Access Info
    """
    args = dict()
    args['current_user'] = request.user
    if request.user.is_authenticated:
        if is_nurse(request):
            args['patients'] = Patient.objects.filter(hospital=request.user.nurse.hospital,
                                                      admitted=False).order_by('fullName')
        if is_doctor(request):
            args['patients'] = Patient.objects.filter(primaryDoc=request.user.doctor,
                                                      admitted=False).order_by('fullName')
    taskbar = setup_taskbar(request)
    args['Notifications'] = taskbar[1]
    args['needs_to_be_viewed'] = taskbar[2]
    args['user_type'] = taskbar[0]
    return render(request, 'HealthNet/hospital_admission_discharge/unadmitted_patients.html', args)


def discharge(request, patient_id):
    """
    View controlling the discharging of a patient by a doctor
    :param request: Basic Server Access Info
    :param patient_id: ID of Patient to Discharge
    """
    patient = Patient.objects.get(id=patient_id)
    patient.admitted = False
    patient.save()
    hospitalStay = HospitalStay.objects.get(patient=patient, active=True)
    hospitalStay.endTime = datetime.now().time()
    hospitalStay.endDate = datetime.now().date()
    hospitalStay.active = False
    hospitalStay.save()
    LogEntry.objects.log_action(
        user_id=request.user.id,
        content_type_id=ContentType.objects.get_for_model(request.user).pk,
        object_id=request.user.id,
        object_repr=request.user.username,
        action_flag=CHANGE,
        change_message=patient.fullName + " was discharged from " + str(
            hospitalStay.hospital) + " by " + request.user.first_name + " " + request.user.last_name + ".")

    return HttpResponseRedirect('/HealthNet/admitted_patients/')

    # return render(request, 'HealthNet/admitted_patients.html', args)


def admission_reason(request, patient_id):
    """
    View controlling the actual admission of a patient
    :param request: Basic Server Access Info
    :param patient_id: ID of Patient to Admit
    """
    if request.method == 'POST':
        admtform = AdmissionForm(request.POST, prefix='AdmissionForm')

        taskbar = setup_taskbar(request)
        return render(request, 'HealthNet/hospital_admission_discharge/admitting_patient.html',
                      dict(admtform=admtform,
                           current_user=request.user,
                           Notifications=taskbar[1],
                           needs_to_be_viewed=taskbar[2],
                           user_type=taskbar[0]))


def admit_patient(request, patient_id):
    """
    View controlling the admission of a patient by a nurse or doctor
    :param request: Basic Server Access Info
    :param patient_id: ID of Patient to Admit
    """
    if request.method == 'POST':
        admtform = AdmissionForm(request.POST, prefix='AdmissionForm')
        if admtform.is_valid():
            patient = Patient.objects.get(id=patient_id)
            patient.admitted = True
            patient.save()
            admission = admtform.save(commit=False)
            admission.patient = Patient.objects.get(id=patient_id)
            admission.active = True
            admission.startTime = datetime.now().time()
            admission.startDate = datetime.now().date()
            admission.hospital = patient.hospital
            admission.save()
            LogEntry.objects.log_action(
                user_id=request.user.id,
                content_type_id=ContentType.objects.get_for_model(request.user).pk,
                object_id=request.user.id,
                object_repr=request.user.username,
                action_flag=CHANGE,
                change_message=patient.fullName + " was admitted to " + str(
                    admission.hospital) + " by " + request.user.first_name + " " + request.user.last_name + " for " + admission.reason + ".")

            return HttpResponseRedirect('/HealthNet/admitted_patients/')
    else:
        admtform = AdmissionForm(prefix='AdmissionForm')
    taskbar = setup_taskbar(request)
    patient = Patient.objects.get(id=patient_id)
    return render(request, 'HealthNet/hospital_admission_discharge/admitting_patient.html',
                  dict(admtform=admtform,
                       current_user=request.user,
                       Notifications=taskbar[1],
                       needs_to_be_viewed=taskbar[2],
                       user_type=taskbar[0]))

# #####################################################################################################################
# ########################################## Patient Admission End ####################################################
# #####################################################################################################################
