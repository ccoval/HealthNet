from django.http import HttpResponseRedirect
from django.shortcuts import render, render_to_response
from django.template import RequestContext

from .miscellaneous_functions import setup_taskbar
from ..models import *


# #####################################################################################################################
# ########################################## Home Page Begin ##########################################################
# #####################################################################################################################


def home(request):
    """
    Master View controlling home page access
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return patient_home(request)
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    if user.nurse.validated is False:
                        return HttpResponseRedirect('/HealthNet/not_validated/')
                    return nurse_home(request)
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    if user.doctor.validated is False:
                        return HttpResponseRedirect('/HealthNet/not_validated/')
                    return doctor_home(request)
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    if user.healthAdmin.validated is False:
                        return HttpResponseRedirect('/HealthNet/not_validated/')
                    return health_admin_home(request)
            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return sys_admin_home(request)
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def patient_home(request):
    """
    View controlling home page access of patients
    :param request: Basic Server Access Info
    """
    my_appointments = None
    try:
        if request.user.patient.appointments is not None:
            if request.user.patient.appointments.count() > 0:
                my_appointments = request.user.patient.appointments.all()
                my_appointments = my_appointments.filter(
                    start_date__range=[datetime.today().date(), my_appointments.last().start_date])
                my_appointments = my_appointments[:3]
    except ObjectDoesNotExist:
        pass
    if my_appointments is None:
        none_text = "No Upcoming Appointments"
    else:
        none_text = ""
    can_view_admitted = False

    taskbar = setup_taskbar(request)

    return render_to_response("HealthNet/home_pages/home.html", {'my_user': request.user,
                                                                 'id': request.user.id,
                                                                 'my_appointments': my_appointments,
                                                                 'none': none_text,
                                                                 'can_view_admitted': can_view_admitted,
                                                                 'current_user': request.user,
                                                                 'Notifications': taskbar[1],
                                                                 'needs_to_be_viewed': taskbar[2],
                                                                 'user_type': taskbar[0]},
                              context_instance=RequestContext(request))


def nurse_home(request):
    """
    View controlling home page access of nurses
    :param request: Basic Server Access Info
    """
    my_appointments = None
    try:
        if request.user.nurse.hospital is not None:
            try:
                if request.user.nurse.hospital.appointments is not None:
                    if request.user.nurse.hospital.appointments.count() > 0:
                        my_appointments = request.user.nurse.hospital.appointments.all()
                        my_appointments = my_appointments.filter(
                            start_date__range=[datetime.today().date(), my_appointments.last().start_date])
                        my_appointments = my_appointments[:3]
            except ObjectDoesNotExist:
                pass
    except ObjectDoesNotExist:
        pass
    if my_appointments is None:
        none_text = "No Upcoming Appointments"
    else:
        none_text = ""
    can_view_admitted = True

    taskbar = setup_taskbar(request)

    return render_to_response("HealthNet/home_pages/nurse_home.html", {'my_user': request.user,
                                                                       'id': request.user.id,
                                                                       'my_appointments': my_appointments,
                                                                       'none': none_text,
                                                                       'can_view_admitted': can_view_admitted,
                                                                       'current_user': request.user,
                                                                       'Notifications': taskbar[1],
                                                                       'needs_to_be_viewed': taskbar[2],
                                                                       'user_type': taskbar[0]},
                              context_instance=RequestContext(request))


def doctor_home(request):
    """
    View controlling home page access of doctors
    :param request: Basic Server Access Info
    """
    my_appointments = None
    try:
        if request.user.doctor.appointments is not None:
            if request.user.doctor.appointments.count() > 0:
                my_appointments = request.user.doctor.appointments.all()
                my_appointments = my_appointments.filter(
                    start_date__range=[datetime.today().date(), my_appointments.last().start_date])
                my_appointments = my_appointments[:3]
    except ObjectDoesNotExist:
        pass
    if my_appointments is None:
        none_text = "No Upcoming Appointments"
    else:
        none_text = ""
    can_view_admitted = True

    taskbar = setup_taskbar(request)

    return render_to_response("HealthNet/home_pages/doctor_home.html", {'my_user': request.user,
                                                                        'id': request.user.id,
                                                                        'my_appointments': my_appointments,
                                                                        'none': none_text,
                                                                        'can_view_admitted': can_view_admitted,
                                                                        'current_user': request.user,
                                                                        'Notifications': taskbar[1],
                                                                        'needs_to_be_viewed': taskbar[2],
                                                                        'user_type': taskbar[0]},
                              context_instance=RequestContext(request))


def health_admin_home(request):
    """
    View controlling home page access of Health Administrators
    :param request: Basic Server Access Info
    """
    taskbar = setup_taskbar(request)
    return render(request, "HealthNet/home_pages/healthAdmin_home.html", {'my_user': request.user,
                                                                          'id': request.user.id,
                                                                          'current_user': request.user,
                                                                          'Notifications': taskbar[1],
                                                                          'needs_to_be_viewed': taskbar[2],
                                                                          'user_type': taskbar[0]})


def sys_admin_home(request):
    """
    View controlling home page access of System Administrators
    :param request: Basic Server Access Info
    """
    taskbar = setup_taskbar(request)
    return render_to_response("HealthNet/home_pages/sys_admin_home.html", {'my_user': request.user,
                                                                           'id': request.user.id,
                                                                           'current_user': request.user,
                                                                           'Notifications': taskbar[1],
                                                                           'needs_to_be_viewed': taskbar[2],
                                                                           'user_type': taskbar[0]},
                              context_instance=RequestContext(request))


# #####################################################################################################################
# ########################################## Home Page End ############################################################
# #####################################################################################################################
