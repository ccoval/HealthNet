import collections

from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import user_not_authorized, setup_taskbar
from ..models import *


# #####################################################################################################################
# ##################################### Viewing System Statistics Start ###############################################
# #####################################################################################################################


def view_system_statistics(request):
    """
    View controlling the view of system statistics
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            # if user is a patient
            try:
                if user.patient is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a nurse
            try:
                if user.nurse is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a doctor
            try:
                if user.doctor is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
            # if user is a healthAdmin
            try:
                if user.healthAdmin is not None:
                    args = dict()
                    args['num_patients'] = Patient.objects.filter(hospital=user.healthAdmin.hospital).count()
                    args['current_user'] = request.user
                    args['num_doctors'] = Doctor.objects.count()
                    args['num_nurses'] = Nurse.objects.filter(hospital=user.healthAdmin.hospital).count()
                    ####################################################################################################
                    prescriptions = Prescription.objects.all()
                    lst = list()
                    for each in prescriptions.iterator():
                        lst.append(each.medicine)
                    counter = collections.Counter(lst)
                    counter = counter.most_common(5)
                    args['counter'] = counter
                    ####################################################################################################
                    stays = HospitalStay.objects.all()
                    reasons = list()
                    for each in stays:
                        reasons.append(each.reason)
                    ctr = collections.Counter(reasons)
                    args['reasons'] = ctr.most_common(5)
                    ####################################################################################################
                    stays = HospitalStay.objects.all().exclude(endTime=None, endDate=None)
                    dts = list()
                    for each in stays:
                        start = datetime.combine(each.startDate, each.startTime)
                        end = datetime.combine(each.endDate, each.endTime)
                        difference = end - start
                        dts.append(difference)
                    ####################################################################################################
                    #Average number of visits per patient
                    patients = Patient.objects.all()
                    averageAppointments = 0
                    for each in patients:
                        apts = Appointment.objects.filter(patient=each)
                        averageAppointments += apts.count()
                    args['averageAppointments'] = float(float(averageAppointments) / float(patients.count()))
                    args['averageAppointments'] = "%.2f" % args['averageAppointments']
                    taskbar = setup_taskbar(request)
                    args['Notifications'] = taskbar[1]
                    args['needs_to_be_viewed'] = taskbar[2]
                    args['user_type'] = taskbar[0]
                    return render(request, 'HealthNet/system_statistics/view_system_statistics.html', args)
                    ####################################################################################################

            except ObjectDoesNotExist:
                pass
            # if user is a sysAdmin
            try:
                if user.sysAdmin is not None:
                    return user_not_authorized(request)
                    # replace user_not_authorized with your desired view, other view does not need these checks
            except ObjectDoesNotExist:
                pass
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def avg_time(datetimes):
    """
    Returns an average time of the times passed into it
    :param datetimes: Times to Average
    :return: Average Time
    """
    total = sum(dt.hour * 3600 + dt.minute * 60 + dt.second for dt in datetimes)
    avg = total / len(datetimes)
    minutes, seconds = divmod(int(avg), 60)
    hours, minutes = divmod(minutes, 60)
    return datetime.combine(date(1900, 1, 1), time(hours, minutes, seconds))

# #####################################################################################################################
# ##################################### Viewing System Statistics End #################################################
# #####################################################################################################################
