
from django.contrib import auth
from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.db import IntegrityError
from django.http import HttpResponseRedirect
from django.shortcuts import render, render_to_response
from django.template import RequestContext
from django.template.context_processors import csrf
from django.forms.forms import ErrorList

from ..forms import MyPatientForm, MyRegistrationForm, MyMedicalRecordForm, MyInsuranceForm
from ..models import *

# #####################################################################################################################
# ########################################## Patient Registration Begin ###############################################
# #####################################################################################################################


def register_user(request):
    """
    View controlling the registration of a new user (Django User Model)
    :param request: Basic Server Access Info
    """
    if request.method == 'POST':
        uf = MyRegistrationForm(request.POST, prefix='user')

        if uf.is_valid():
            user = uf.save(commit=False)
            user.username = user.email
            try:
                user.save()
            except IntegrityError:
                errors = uf.errors.setdefault("email", ErrorList())
                errors.append(u"Email already exists in our system")
                return render_to_response('HealthNet/patient_registration/register.html',
                                          dict(userform=uf,),
                                          context_instance=RequestContext(request))
            return HttpResponseRedirect('/HealthNet/first_login/')
    else:
        uf = MyRegistrationForm(prefix='user')

    return render_to_response('HealthNet/patient_registration/register.html',
                              dict(userform=uf,
                                   ),
                              context_instance=RequestContext(request))


def first_log_in(request):
    """
    View controlling the redirect to first log in
    :param request: Basic Server Access Info
    """
    arg = {}
    arg.update(csrf(request))
    return render_to_response('HealthNet/patient_registration/first_login.html', arg)


def first_auth_view(request):
    """
    View controlling the actual logging in of a new user
    :param request: Basic Server Access Info
    """
    try:
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            iden = user.id
            request.session['user_id'] = iden
            return HttpResponseRedirect('/HealthNet/register_patient/')

        return render(request, 'HealthNet/patient_registration/first_wrong_user_or_password.html')

    except ValueError:
        return render(request, 'HealthNet/patient_registration/first_wrong_user_or_password.html')


def first_wrong_user_or_password(request):
    """
    View controlling the redirect to wrong user or password during registration log in
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/patient_registration/first_wrong_user_or_password.html')


def register_patient(request):
    """
    View controlling the registration of a new patient (Patient Model)
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            if request.method == 'POST':
                upf = MyPatientForm(request.POST, prefix='userprofile')
                if upf.is_valid():
                    user = request.user
                    userprofile = upf.save(commit=False)
                    userprofile.user = user
                    userprofile.fullName = user.first_name + " " + user.last_name
                    try:
                        e_contact = User.objects.get(email=userprofile.EmergContactEmail)
                        userprofile.healthNetEmergContact = e_contact
                    except User.DoesNotExist:
                        pass
                    userprofile.save()
                    LogEntry.objects.log_action(
                        user_id=request.user.id,
                        content_type_id=ContentType.objects.get_for_model(userprofile).pk,
                        object_id=request.user.id,
                        object_repr=user.username,
                        action_flag=CHANGE,
                        change_message="Patient, " + user.username + ", has been created.")
                    return HttpResponseRedirect('/HealthNet/register_insurance/')
            else:
                upf = MyPatientForm(prefix='userprofile')
            return render(request, 'HealthNet/patient_registration/register_patient.html', dict(userprofileform=upf, ))
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def register_insurance(request):
    """
    View controlling the registration of a new insurance info (InsuranceInfo Model)
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            if request.method == 'POST':
                ipf = MyInsuranceForm(request.POST, prefix='insurance')
                if ipf.is_valid():
                    patient = request.user.patient
                    insurance = ipf.save(commit=False)
                    insurance.patient = patient
                    insurance.save()
                    return HttpResponseRedirect('/HealthNet/register_medical_record/')
            else:
                ipf = MyInsuranceForm(prefix='insurance')
            return render(request, 'HealthNet/patient_registration/register_insurance.html', dict(insuranceform=ipf, ))
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def register_medical_record(request):
    """
    View controlling the registration of a new medical record (MedicalInfo Model)
    :param request: Basic Server Access Info
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            if request.method == 'POST':
                mrf = MyMedicalRecordForm(request.POST, prefix='medical_record')
                if mrf.is_valid():
                    patient = request.user.patient
                    medical_record = mrf.save(commit=False)
                    medical_record.patient = patient
                    medical_record.save()
                    return HttpResponseRedirect('/HealthNet/registration_success/')
            else:
                mrf = MyMedicalRecordForm(prefix='medical_record')
            return render(request, 'HealthNet/patient_registration/register_medical_record.html',
                          dict(medicalrecordform=mrf, ))
    return HttpResponseRedirect('/HealthNet/not_logged_in/')


def registration_success(request):
    """
    View controlling the success of registration of a new patient
    :param request: Basic Server Access Info
    """
    return render(request, 'HealthNet/patient_registration/registration_success.html')


# #####################################################################################################################
# ########################################## Patient Registration End #################################################
# #####################################################################################################################
