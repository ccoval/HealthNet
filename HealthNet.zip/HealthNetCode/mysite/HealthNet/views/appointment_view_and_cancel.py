from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .miscellaneous_functions import setup_taskbar
from ..models import *


# #####################################################################################################################
# ########################################## Appointment View/Cancel Begin ############################################
# #####################################################################################################################


def appointment(request, appointment_id):
    """
    View controlling viewing of appointments
    :param request: Basic Server Access Info
    :param appointment_id: ID of Appointment to be Viewed
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                appointmnt = Appointment.objects.get(pk=appointment_id)
                iden = appointment_id
            except ObjectDoesNotExist:
                raise Http404("This Appointment does not exist")
            try:
                if request.user.nurse is not None:
                    taskbar = setup_taskbar(request)
                    return render(request, 'HealthNet/appointments/nurse_appointment.html',
                                  {'Appointment': appointmnt,
                                   'ID': iden,
                                   'current_user': request.user,
                                   'Notifications': taskbar[1],
                                   'needs_to_be_viewed': taskbar[2],
                                   'user_type': taskbar[0]})
            except ObjectDoesNotExist:
                pass

            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/appointments/appointment.html', {'Appointment': appointmnt,
                                                                               'ID': iden,
                                                                               'current_user': request.user,
                                                                               'Notifications': taskbar[1],
                                                                               'needs_to_be_viewed': taskbar[2],
                                                                               'user_type': taskbar[0]})
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def cancel_appointment(request, appointment_id):
    """
    View controlling cancellation of appointments
    :param request: Basic Server Access Info
    :param appointment_id: ID of Appointment to be Cancelled
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            appt = Appointment.objects.get(id=appointment_id)
            LogEntry.objects.log_action(
                content_type_id=ContentType.objects.get_for_model(appt).pk,
                object_id=appt.id,
                object_repr=appt.title,
                user_id=request.user.id,
                action_flag=CHANGE,
                change_message="Appointment, " + appt.title + ", was deleted.")
            Appointment.objects.get(pk=appointment_id).delete()
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/appointments/cancelAppointment.html', {'current_user': request.user,
                                                                                     'Notifications': taskbar[1],
                                                                                     'needs_to_be_viewed': taskbar[2],
                                                                                     'user_type': taskbar[0]})
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


def delete_appointment_check(request, appointment_id):
    """
    View controlling check to make sure you want to cancel an appointment
    :param request: Basic Server Access Info
    :param appointment_id: ID of Appointment to be Cancelled
    """
    if 'user_id' in request.session:
        user = request.user
        if user.is_authenticated():
            try:
                appointmnt = Appointment.objects.get(pk=appointment_id)
                iden = appointment_id
            except ObjectDoesNotExist:
                raise Http404("This Appointment does not exist")
            taskbar = setup_taskbar(request)
            return render(request, 'HealthNet/appointments/delete_appointment_confirmation.html',
                          {'Appointment': appointmnt, 'ID': iden, 'current_user': request.user,
                           'Notifications': taskbar[1], 'needs_to_be_viewed': taskbar[2], 'user_type': taskbar[0]})
        else:
            return HttpResponseRedirect('/HealthNet/not_logged_in/')
    else:
        return HttpResponseRedirect('/HealthNet/not_logged_in/')


# #####################################################################################################################
# ########################################## Appointment View/Cancel End ##############################################
# #####################################################################################################################
