$(function(){

    $('#search').keyup(function() {
    
        $.ajax({
            type: "POST",
            url: "/HealthNet/doctor_patient_search/",
            data: { 
                'search_patient' : $('#search').val(),
                'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
            },
            success: searchSuccess,
            dataType: 'html'
        });
        
    });

});

function searchSuccess(data, textStatus, jqXHR)
{
    $('#search-results').html(data);
}